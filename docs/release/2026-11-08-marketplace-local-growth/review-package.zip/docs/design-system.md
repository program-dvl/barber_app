# ClipperDesk UI/UX standards and product design system

Status: Canonical standard; the ClipperDesk visual and component foundation is
implemented, while individual product surfaces may still require review against
this document.

Last standards review: 2026-10-15

Last verified foundation evidence: 2026-08-25

Related requirements: FR-01 through FR-20, especially FR-02, FR-06, FR-08,
FR-09, FR-18, FR-19, and PRD Sections 3, 4, 10, and 12.

## Purpose, authority, and scope

This is the central UI/UX standard for ClipperDesk. Developers, designers,
reviewers, and coding agents must use it before creating or modifying any page,
feature, form, dashboard, modal, drawer, workflow, or reusable component.

It applies to the authenticated shop application, public booking and secure
self-service, platform administration, authentication, billing, generated
documents, and user-facing messages. It defines product-experience and
interaction rules; `product-requirements.md`, accepted records in
`decisions.md`, and the relevant module document remain authoritative for
product scope and domain behavior. If a UI proposal conflicts with those
sources, resolve or record the product decision rather than silently changing
behavior in the interface.

The words **must**, **should**, and **may** are normative:

- **must** is required unless an accepted decision records an exception;
- **should** is the default and needs a documented reason to depart; and
- **may** is optional guidance.

Adding a rule here does not claim that every existing screen already complies.
Verified implementation facts remain in `project-status.md`.

## Prompt 01–09 adoption baseline

The 2026-08-15 implementation review applied this standard to every existing
user-facing Vue surface delivered by Prompts 01–09. The shared shop shell,
authentication, subscription and billing, business configuration, operational
calendar, walk-in queue, public booking and secure self-service, Client CRM,
forms, consent, privacy, and platform readiness surfaces now share the same
hierarchy, tokens, controls, state language, and responsive conventions.

Dashboard users may choose among **Appointment list**, **By staff**, and
**Now & next**. New users start with Now & next; urgent items precede reporting
and use a compact, expandable summary ahead of the schedule on smaller screens
(ADR-043). The preference is remembered per signed-in user on the current device. These are alternate presentations of the same tenant-scoped
calendar facts; they must not create separate operational truth or bypass
permission filtering.

The public booking journey remains a single focused step flow. Multiple public
views would add choice without helping the client complete the booking and are
therefore outside this pattern.

The public acquisition shell uses a white, lightly elevated sticky header over
the cool-gray product canvas. Navy establishes trust and structure, indigo is
reserved for primary actions, and cyan is a sparse identifying accent. The
footer uses a deep-navy closing frame. Authenticated navigation follows the
blue operational navigation contract below.

## Experience standard: premium through clarity

ClipperDesk aims to be one of the world's best service-business software
experiences. Here, “premium” means calm, deliberate, fast, dependable, and
beautifully resolved. It does not mean ornamental, fashion-led, visually loud,
or black-and-gold luxury. The product must feel credible while a receptionist
is handling a queue, an owner is reviewing money, a stylist is with a client,
or a client is booking on a phone.

Every surface must demonstrate:

- a clear purpose and information hierarchy;
- one obvious next action where the workflow has a natural next step;
- restrained typography, spacing, colour, and elevation;
- the least complexity needed for the user's goal;
- immediate, honest feedback for system activity and results;
- thoughtful loading, empty, error, success, disabled, and permission states;
- responsive, touch-friendly, keyboard-operable behavior; and
- consistent language and components across the product.

Do not ship raw admin panels, database-shaped forms, generic CRUD screens,
unstructured field walls, decorative dashboards, or developer-facing
terminology as finished product UI. A technically complete screen is not a
complete experience.

## Non-negotiable product principles

### Design around the user's job

Start with the person and outcome, not the table schema or controller payload.
Before proposing a surface, identify:

1. the user and the context in which they are working;
2. the result they need, not merely the record they need to edit;
3. the information required to make the next decision;
4. the primary action and the most likely follow-up;
5. secondary and rare actions that can be deferred;
6. what the system can infer, remember, prefill, or automate; and
7. the failure, interruption, permission, and recovery paths.

The visible interface may group, rename, summarize, derive, or progressively
reveal backend data when that creates a clearer and safer workflow. It must not
expose internal identifiers, implementation constraints, enum keys, or storage
shape unless the user genuinely needs them.

### Optimize for salon operations

Owners, branch managers, receptionists, stylists, beauticians, therapists,
cashiers, inventory managers, accountants, and platform operators have
different priorities and permissions. Many shop users will operate ClipperDesk
while speaking with a client or delivering a service. The most frequent
workflows—booking, finding availability, check-in, staff assignment, payment,
schedule review, client lookup, stock updates, and today's performance—should
require few interactions and little typing.

Prefer recognition over recall. Keep today's work and time-sensitive exceptions
prominent. Preserve useful context such as Business, Location, local date,
filters, selected Staff, and the record the user came from. Do not force users
to reconstruct context after every save, modal, or page transition.

### Reduce cognitive load

Every field, label, card, statistic, button, confirmation, modal, and page
transition must earn its place. Remove repeated information and secondary
controls before adding visual treatment. Use whitespace and grouping to
express relationships; do not use a card, divider, icon, badge, or colour merely
to make a screen look busy or “premium.”

Users should always be able to answer:

- Where am I?
- What am I looking at?
- What requires attention?
- What happens if I take this action?
- Was the action successful, and what should I do next?

### Prevent errors instead of cleaning them up

Prefer this path:

> Controlled input → contextual guidance → validation → normalization → storage

Do not default to:

> Free text → arbitrary input → invalid or inconsistent data → later cleanup

Make impossible states difficult or impossible to create, but do not hide a
real business consequence behind an unexplained constraint.

### Make consequential behavior explicit

Smart defaults should reduce work, not surprise the user. A default affecting
money, tax, client consent, public availability, communications, historical
records, or destructive behavior must be visible, understandable, and
reviewable before it takes effect. Never infer legal or financial policy.

## Information architecture and page composition

### Page hierarchy

A product page should normally contain, in order:

1. persistent shell and current Business/Location context;
2. one page title describing the user's destination or outcome;
3. concise supporting context only when it changes the user's decision;
4. primary and secondary page actions;
5. the main working area; and
6. supporting detail, history, or advanced controls.

There must be only one page-level `h1`. Keep the primary action visually
dominant and place it where the user will look when ready to act. Do not present
several unrelated primary buttons. Preserve route-relevant filters, date,
Location, view, and selection in the URL when practical so back/forward,
refresh, links, and recovery behave predictably.

### Choosing a complexity pattern

Long, unrelated forms are prohibited unless research or a documented workflow
shows that a single continuous view is materially better. Choose the smallest
pattern that matches the mental model:

| Pattern | Use when | Avoid when |
| --- | --- | --- |
| Sections in one page | A short task has a few strongly related groups | Groups are independent or the page becomes difficult to scan |
| Tabs | Users switch between peer categories and may work in any order | The task is sequential, errors would be hidden, or users must compare panels |
| Step flow | Steps depend on earlier answers or a safe review is required | Expert users repeatedly edit one isolated value |
| Accordion / Advanced | Optional or rare detail can stay collapsed | Content is required, contains unresolved errors, or must be compared |
| Card | One meaningful, bounded concept needs a visual group | It is purely decorative or creates deeply nested containers |
| Drawer | A short contextual task should preserve the underlying page | The task is complex, needs deep navigation, or has major consequences |
| Modal | A focused decision or confirmation blocks the current flow | It contains a long form, reference-heavy work, or another modal |
| Dedicated page | A task is complex, consequential, linkable, or benefits from focus | It is a tiny adjustment that can be completed in context |

Show common and required choices first. Put rare or technical options under a
clearly named advanced area. Never hide errors, required fields, destructive
consequences, or safety information inside a collapsed section.

### Navigation and continuity

Prioritize today's work and keep high-frequency actions within one or two
interactions, as required by PRD Section 10. Navigation labels must be stable,
plain-language, and permission-aware. Hiding an unauthorized destination is
presentation only; the server must still enforce access.

After a task, return the user to the most useful state rather than an arbitrary
index. Preserve filters and scroll position when it helps, show the changed
record, and provide a clear route to the likely next action. Warn before
discarding meaningful unsaved work.

## Forms and structured data entry

### Form structure

Each form must have one clear purpose and a save boundary users can understand.
Group fields by user goal, not database model. Required and optional fields must
be distinguishable in text; do not rely on colour or an unexplained asterisk.
Explain why sensitive or unusual information is needed at the point of entry.

For large configuration tasks:

- show the minimum viable path first;
- separate everyday settings from advanced settings;
- use steps only when order or review matters;
- keep save actions scoped to the visible concept;
- preserve entered data across validation and recoverable failures;
- show completion as facts or named blockers, never a vague percentage; and
- support safe interruption and resumption when the workflow is not brief.

### Input selection matrix

Text input is for genuinely free or user-authored content, not a universal
fallback. Use the nature and size of the value set to choose the control.

| Data or decision | Default control | Requirements |
| --- | --- | --- |
| Boolean setting | Toggle for immediate settings; checkbox for form agreement or batch selection | Use a positive label that states the enabled outcome; communicate immediate-save behavior |
| 2–4 exclusive choices | Radio group or segmented control | Show all meaningful options and a short consequence when needed |
| Small predefined list | Native select or accessible listbox | Use user-facing labels, not internal enum values |
| Large predefined list | Searchable combobox/autocomplete | Support keyboard search, no-result state, clear selection, and accessible announcements |
| Multiple options | Checkbox group, multi-select, or tokenized combobox | Show selected count and make removal clear; do not hide selection limits |
| Country | Searchable country selector | Show country name; store a normalized ISO code |
| State / region | Country-dependent selector, searchable when large | Load only valid regions and permit a documented free-text fallback where the source is incomplete |
| Language / locale | Searchable language or locale selector | Use human-readable names and regional variants; store a normalized code |
| Time zone | Searchable time-zone selector | Show recognizable city/region and current UTC offset; store an IANA identifier |
| Currency | Currency selector | Show name, ISO code, and symbol where helpful; store normalized ISO currency |
| Status | Controlled selector or workflow actions | Offer only valid transitions; do not expose a raw status enum |
| Date | Date picker with keyboard-editable fallback | Use locale-aware display and explicit bounds |
| Time | Time picker | State the governing Location time zone when ambiguity is possible |
| Date and time | Date-time picker or composed date/time controls | Preserve local intent and communicate time zone/DST consequences |
| Duration | Preset choices plus constrained custom option when needed | Display in human units, not raw minutes alone |
| Money | Currency-aware numeric input | Show currency, decimal expectations, and formatted review value; never ask for “minor units” |
| Percentage | Numeric input with `%` affordance | Define min/max, precision, and whether the value is inclusive |
| Quantity | Stepper or constrained numeric input | Use sensible bounds and unit labels |
| Phone number | International phone input | Support country code, input formatting, and normalized E.164 storage without blocking valid paste |
| Address | Address search plus editable structured fallback | Do not make third-party lookup a hard dependency |
| Colour | Accessible colour picker plus value/name when colour is meaningful | Never make colour the sole stored or communicated meaning |
| File / image | Purpose-built upload | State accepted types, size, privacy, progress, error, preview, replace, and remove behavior |

If a structured data source is temporarily unavailable, record the limitation
and provide a safe fallback. Do not permanently encode a free-text control
because the master data or reusable component has not yet been built.

### Central option sources and reusable controls

Countries, regions, locales, languages, time zones, currencies, service types,
statuses, categories, roles, and other shared option sets must come from
central, versioned sources. Do not copy option arrays into individual pages.
Domain-owned lists such as roles, service categories, and valid status
transitions must also be tenant-scoped and permission-aware where applicable.

Once ClipperDesk has a compliant selector or field pattern for a shared value,
reuse it everywhere. Variation is acceptable only when the user context changes
the interaction materially, not because a page was built separately.

### Smart defaults and inference

Provide sensible defaults when confidence is high and the consequence is low:

- suggest time zone from the selected Location or device and let the user
  verify it;
- suggest locale and currency from Business location without treating that as
  tax or legal policy;
- use common duration and interval presets;
- inherit Location or Business values when the relationship is visible;
- remember safe, user-specific working preferences such as last Location or
  calendar view; and
- normalize casing, whitespace, phone numbers, URLs, codes, and monetary
  formatting without changing meaning.

Never silently overwrite an intentional choice. Explain inherited values and
provide a clear override or reset-to-default action.

### Contextual validation

Validation belongs with the affected control. Every invalid field must have a
text error connected programmatically to that field, a visible invalid state,
and a message that explains how to fix the issue. Preserve the user's input and
focus the first invalid field or a linked summary after submission.

Use validation timing deliberately:

- prevent impossible characters or values where doing so does not block valid
  input methods or paste;
- validate format after blur or when enough input exists, not on every
  keystroke by default;
- validate cross-field and server-owned rules on submit or at the point a
  dependent decision is made;
- show asynchronous checks such as slug availability near the control and
  distinguish checking, available, unavailable, and failed-to-check states;
- clear an error when it has genuinely been resolved; and
- keep a page-level summary only as a complement for navigation, never as the
  only explanation.

Messages must use normal language and must not expose exception text, table or
column names, regex rules, internal codes, stack details, or private scheduling
reasons. Client-side prevention improves the experience; server-side
validation and authorization remain authoritative.

## Actions, feedback, and system states

### Action hierarchy

Use one primary action per working context. Secondary actions support the
primary task; quiet actions are low-emphasis; danger actions are reserved for
destructive or difficult-to-reverse consequences. Use verbs that describe the
result: “Save booking rules,” “Check in client,” or “Issue refund,” not generic
labels such as “Submit,” “OK,” or “Process.”

Do not disable an action without an understandable reason. If an action is
temporarily unavailable, explain what is missing and provide the next step when
possible. Prevent accidental duplicate submission and keep idempotent retries
safe.

### Destructive, financial, and high-impact actions

Require confirmation only when it protects against a meaningful consequence.
The confirmation must name the affected object, state what will happen, explain
whether it can be undone, and give initial focus to the safe action. Never use a
generic “Are you sure?” prompt.

For money, tax, availability, communication, consent, privacy, staff access, or
historical changes, provide an impact preview when the consequence is not
obvious. Never imply that hiding or deleting a UI row erased append-only or
audited history.

### Required states

Every important page and component must intentionally define the applicable
states below:

| State | Experience requirement |
| --- | --- |
| Default | Clear purpose, current value, and available action |
| Hover | Helpful visual affordance without carrying unique meaning |
| Focus | Strong visible focus; logical keyboard order |
| Active / selected | Text, shape, or icon cue in addition to colour |
| Disabled / unavailable | Reason and recovery path when not self-evident |
| Loading | Preserve layout, announce activity, and prevent unsafe duplicates |
| Empty | Explain why it is empty and offer a relevant first or recovery action |
| Error | State what failed, what remains safe, and how to retry or recover |
| Success | Confirm the completed outcome and surface the logical next step |
| Stale / conflict | Preserve work, explain the newer state, and support review rather than blind overwrite |
| Partial / offline | Distinguish saved, pending, and failed work; never claim completion early |

Use skeletons when the page shape is known, a compact progress indicator for a
short bounded action, and named step/progress detail for a long job such as an
import or export. Avoid layout jumps and indefinite spinners without context.
Do not use optimistic success for actions that can fail with a consequential
result.

### Notifications

Use inline feedback for input and workflow errors, banners for persistent or
page-wide conditions, toasts for brief confirmations that do not require a
decision, and dialogs only when the user's attention must block the current
flow. Notifications must be dismissible when safe, accessible to assistive
technology, and must not be the sole record of a consequential outcome.

### Customer-first recovery and notification composition (2026-10-15)

This contract applies to every product module and future prompt. Use the shared
`AppNotice` for persistent inline workflow feedback; legacy `Feedback/Alert*`
components delegate to it. `ToastRegion` uses the same visual language for brief,
dismissible confirmations. Shared workspace access, platform/support and flash
notices follow this pattern. Existing module-specific banners must adopt it when
touched; this rule is not evidence that every old surface has been migrated.

- Use a raised neutral surface, subtle border, 12px radius and 16–20px padding.
  A 19px semantic icon on a small, softly tinted field supplies status colour.
  Keep the body in normal readable text. Do not fill an entire failure banner
  with saturated/pale yellow or red or rely on colour alone.
- Write a short customer-oriented heading and one or two sentences explaining
  the outcome, what is saved and the next useful action. Never display provider
  diagnostics, payment-environment instructions or generic Server Error text.
- Combine the error and its recovery actions into one notice. Replace stale
  success/previous error states instead of stacking contradictory banners.
  Keep a concise original purchase summary when continuing has financial meaning.
- A payment return starts with “Checking your payment”, then shows the confirmed
  outcome automatically. Do not flash an unfinished-checkout warning while the
  first check is running. A verified open checkout offers continuation; a payment
  still processing says so. Follow-up checks are bounded, stop on errors and never
  create a new payment. A redirect flag alone is not proof of success. A saved
  checkout request alone is not proof that payment is unfinished: use the matching
  confirmed payment and subscription together, and clear obsolete payment actions.
- Place actions below the text in a wrapping flex row: at least 14px above it,
  at least 10px between controls, never touching. One primary action at most;
  use secondary for alternatives and quiet for status checks. Preserve 44px
  touch targets on mobile and visible keyboard focus; avoid narrow full-width
  decorative cards or excessive animation.
- Use `role=status` for information/success and `role=alert` for a new blocking
  failure. Countdown text is not a live announcement each second. Do not dismiss
  consequential unresolved feedback automatically or represent it only as a toast.
- Own platform failures. A customer must not repair server credentials or keep
  clicking a known dead end. Preserve input, stop background retries on persistent
  failure, honor Retry-After with a visible countdown, and provide a working
  support link plus a safe reference where self-recovery needs an operator.
  Never promise a payment failed unless provider evidence proves that outcome.
- Distinguish loading, a confirmed empty result and an unavailable result. An
  unavailable optional photo section must not imply missing customer work or
  offer a reload known to repeat a platform failure. Keep saved/selected previews,
  offer reachable support with a safe reference and leave other setup usable
  (ADR-075). Do not infer a quota failure from a provider authentication denial.

### Selecting and saving several images (2026-11-01)

For a bounded gallery, offer one multiple-file picker and optional drag and drop,
then show compact thumbnails, filenames, individual removal and remaining spaces.
Keep descriptions optional and collapsed until requested. One clearly labelled
save action applies the selection; do not upload merely because files were chosen.
Show textual batch progress and retain unfinished previews when saving stops.
Distinguish confirmed saves from an uncertain response, stop later requests on
failure, and offer recovery that preserves already-saved items without duplicates.
A known-invalid file must be removed or replaced before continuation; a stale
gallery must reload while retaining the selection. Preserve the shared notice,
focus and touch-target rules, with a mobile layout that keeps the save action and
individual removal easy to reach. See [booking presentation](modules/booking-presentation.md).

## Data-heavy and operational surfaces

### Dashboards

Dashboards must answer a defined operational question, not display every metric
available. Prioritize exceptions, next actions, and today's state. Every metric
must have a clear time range, Location/time-zone context, data-freshness state,
and a route to the records behind it when the PRD requires drill-down. Avoid
vanity metrics and decorative charts.

### Tables, lists, search, and filters

Choose tables for comparison across consistent columns and lists/cards for
scan-and-act workflows or narrow screens. Provide a meaningful default sort,
plain-language column names, an accessible caption, and explicit empty/no-match
states. Keep row actions discoverable without making every row visually noisy.

Search and filters must:

- use labels and user-visible selected values;
- distinguish no data from no matching results;
- support clearing individual filters and all filters;
- preserve useful state in the URL when practical;
- show the active-filter count on constrained screens; and
- avoid requiring exact internal identifiers for normal work.

Do not compress essential information below readable or touchable sizes. On
small screens, prioritize, stack, summarize, or provide a labelled internal
scroll region rather than creating page-level horizontal overflow.

### Calendars and queues

Time, Staff, Location, service, appointment/walk-in state, and conflicts must
not rely on colour alone. Preserve the current date and view during actions.
Drag, resize, and reorder interactions require an accessible non-pointer
alternative and a clear confirmation when a change affects scheduling.

## Responsive and touch-friendly behavior

Design from the user's task across widths, not from a desktop screenshot that
is later compressed. Core journeys must work from 360 CSS pixels through
desktop. Content should reflow before it shrinks; primary actions must remain
reachable; no essential control may depend on hover.

Touch targets must be at least 44 by 44 CSS pixels, with enough separation
for use at a busy front desk. Authenticated desktop workspaces may use 40px
standard controls, 32px quiet row actions and 36px menu options on fine-pointer
devices (ADR-037); mobile and coarse-pointer styles restore 44px targets. Respect safe areas and virtual keyboards. Keep
forms single-column where width or reading order demands it. Do not trap mobile
users in wide tables, nested scrolling containers, or full-screen keyboards
without a visible way to continue.

Desktop density may increase for expert operational workflows, but the order,
labels, permissions, and outcomes must remain consistent across form factors.

## Accessibility

WCAG 2.2 AA is the target for public booking and core shop workflows and the
default expectation for all new UI. Accessibility is part of implementation
quality, not a later polish pass.

Every UI change must consider:

- semantic HTML and correctly ordered headings and landmarks;
- visible labels and accessible names for all controls;
- complete keyboard navigation, logical focus order, and focus restoration;
- the implemented `:focus-visible` treatment;
- contrast for text, controls, boundaries, icons, and states;
- text/icon/shape cues so meaning never relies on colour alone;
- programmatically associated hints, errors, and status updates;
- screen-reader announcements for asynchronous results when appropriate;
- zoom, text resizing, reflow, and 360px behavior;
- reduced-motion preferences; and
- clear disabled, read-only, selected, current, expanded, and invalid states.

Placeholders are examples, not labels. Icons that trigger an action require an
accessible name. Tooltips cannot hold information needed to complete the task.

## Time, money, language, and location

ClipperDesk operates across Locations and potentially across time zones. Show
local dates and times using the governing Location's IANA time zone, and name
the time zone where ambiguity or consequence exists. Preserve original local
intent where the domain requires it and handle daylight-saving gaps and repeats
without asking users to reason in UTC.

Format dates, times, numbers, currency, percentages, names, addresses, and phone
numbers according to locale while storing normalized domain values. Do not
hard-code symbols, decimal assumptions, first-day-of-week rules, address shape,
name order, or string concatenation. UI copy and message templates must be
structured for translation and expansion.

The India/`en-IN` communications fallback accepted in ADR-019 does not remove
the need for Location time zones or grant permission to infer unresolved tax,
receipt, or privacy policy.

## Public acquisition shell and components

The Phase 1.5 marketing surface uses `MarketingLayout.vue`; it does not reuse
the authenticated sidebar or tenant `PublicBookingLayout`. The shell owns a
skip link, semantic header/primary navigation/main/footer landmarks, responsive
controlled mobile navigation and the global conversion action. Pages own their
single `h1`, metadata, content rhythm and contextual links.

Marketing components live in `resources/js/Components/Marketing/`:

| Component | Contract |
| --- | --- |
| `PublicContainer` | One centered 76rem maximum content boundary with a 1rem mobile gutter |
| `SectionHeading` | Optional eyebrow plus semantic configurable heading level; a page must not use it to create a second `h1` |
| `PublicCta` | Requires a privacy-safe context string; anonymous users reach registration, authenticated users reach Dashboard |
| `MarketingCard` | Calm raised content surface; never a substitute for semantic link/button behavior |
| `Breadcrumbs` | Visible ordered hierarchy using real links and `aria-current`; Prompt 23 derives matching JSON-LD |
| `FaqList` | Native `details`/`summary`; visible answers only; schema eligibility is separate |
| `ComparisonTable` | Semantic table in a labelled, keyboard-focusable horizontal region at narrow widths |
| `ProofFrame` | Reserved visual surface plus required factual caption; media must be synthetic/cleared and dimensioned |
| `ConversionBand` | One contextual close using `PublicCta`; never introduces a demo/contact/newsletter promise |

The mobile navigation exposes deterministic expanded state, closes on Escape,
outside pointer interaction and route change, returns focus on Escape, constrains
its viewport height and locks background scrolling while open. Global links are
filtered to named routes that currently exist so sequential delivery never
creates a public dead link. As approved hubs land, the same config exposes
Product, Solutions, Use cases, Pricing and Resources.

Public components use the ClipperDesk semantic palette and Manrope type system.
They do not introduce a second token set,
theme switcher, animation framework, social links, announcement, newsletter or
third-party tracker.

## Trust, privacy, permission, and auditability

Show only data and actions the current role needs, but never treat hidden UI as
authorization. Sensitive client, money, staff, consent, and support information
must follow least privilege and the tenant/access rules in the relevant module.

Collect the minimum information necessary. Explain why sensitive information is
requested, avoid exposing it in previews and notifications, and make private or
audited consequences clear. Access-denied states must not disclose whether a
cross-tenant record exists.

When a change is versioned, effective-dated, append-only, or audited, the UI
should communicate that model in user language. Show who/when/why history only
to authorized users, and never offer a visual “delete” that contradicts domain
retention rules.

## Performance and resilience

Performance is part of the experience. Follow the PRD target that typical
authenticated screens become usable within 2.5 seconds at p75 and common
calendar actions acknowledge within 500ms and commit within 2 seconds under
target load.

Render the most decision-relevant content first, avoid blocking a whole page
for a secondary panel, and use stable layout placeholders. Debounce expensive
search without making typing feel delayed. Paginate or virtualize only when the
data volume warrants it and preserve accessibility. On failure, state what was
and was not saved, keep safe user input, and provide an idempotent retry or
recovery route.

## Microcopy and content design

Write for the user, not the implementation. Labels, headings, hints, errors,
confirmations, and empty states must be short, concrete, consistent, and
action-oriented where appropriate.

- Use sentence case.
- Prefer familiar salon and service-business language from the glossary and
  PRD.
- Name the object and result: “Appointment cancelled” rather than “Success.”
- State local date, time, Location, money, and consequence when material.
- Explain recovery without blame: “Your appointment is unchanged. Try again.”
- Do not expose raw enum values, field names, IDs, provider codes, or backend
  exceptions.
- Avoid hype, beauty clichés, artificial urgency, vague reassurance, and
  unsupported claims.
- Avoid technical abbreviations such as ISO, IANA, E.164, TTL, UTC, or “minor
  units” in normal UI; translate them into user language.

## Brand posture

The product is **ClipperDesk**. Its acquisition brand promise is **Your whole
day. Beautifully run.** The product remains positioned around the reliable
booking-to-checkout operating loop. The identity should feel operational,
dependable, modern, energetic, and approachable. It is not barber-only,
childish, or coded to a single luxury tier.

The geometric mark is a restrained, interlocking **C** and **D** monogram with
no enclosing app tile. It remains legible in compact navigation and signals a
software product without relying on generic scissors, barber poles, or clip
art. Approved SVG assets live under
`public/images/brand/`; the source mark is
`resources/images/brand/clipperdesk-mark.svg`. Do not redraw, stretch, or
substitute the mark with a text glyph. Preserve clear space equal to at least
one quarter of the mark width. Use the horizontal lockup above 180px of
available width and the mark-only form where the product name is already
announced.

The voice is calm, capable, human, and clear:

- lead with the outcome or current state;
- use sentence case, short sentences, and concrete next steps;
- state local date, time, location, money, and consequences explicitly;
- reassure without hiding risk: “Your appointment is unchanged. Try again.”;
- never blame the user, create artificial urgency, or make unsupported claims;
- avoid beauty clichés, salon slang, “AI-powered”, and generic starter-kit copy.

Product language remains aligned with the PRD: Walk-in Queue, Checkout /
Sales, secure self-service, support access, and Subscription & Billing.

## Implemented tokens

Tokens live in `resources/css/app.css`. Components consume semantic names, not
raw palette names.

| Role | Token | Implemented value |
| --- | --- | --- |
| Brand primary | `--brand-primary` / `--brand-primary-strong` | `#172554` / `#0f172a` |
| Brand secondary | `--brand-secondary` / `--brand-secondary-hover` | `#4f46e5` / `#4338ca` |
| Brand accent | `--brand-accent` / `--brand-accent-soft` | `#0e7490` / `#cffafe` |
| Primary canvas | `--surface-canvas` | `#f5f7fb` |
| Subtle surface | `--surface-subtle` | `#eef2f7` |
| Raised surface | `--surface-raised` | `#ffffff` |
| Inverse surface | `--surface-inverse` | `#0f172a` |
| Strong text | `--text-strong` | `#0f172a` |
| Default text | `--text-default` | `#334155` |
| Muted text | `--text-muted` | `#64748b` |
| Accessible primary action | `--action-primary` | `#4338ca` |
| Primary hover / active | `--action-primary-hover` / `--action-primary-active` | `#3730a3` / `#312e81` |
| Focus ring | `--focus-ring` | `#0369a1` |
| Information | `--status-info` / `--status-info-soft` | `#0369a1` / `#e0f2fe` |
| Success | `--status-success` / `--status-success-soft` | `#047857` / `#d1fae5` |
| Warning | `--status-warning` / `--status-warning-soft` | `#a16207` / `#fef3c7` |
| Danger | `--status-danger` / `--status-danger-soft` | `#b91c1c` / `#fee2e2` |
| Disabled | `--surface-disabled` / `--text-disabled` | `#e2e8f0` / `#64748b` |
| Radius | `--radius-sm`, `--radius-md`, `--radius-lg`, `--radius-xl` | `6px`, `10px`, `14px`, `20px` |
| Raised elevation | `--shadow-raised` | two-layer cool-neutral shadow |
| Overlay elevation | `--shadow-overlay` | high-separation overlay shadow |

Typography uses self-hosted Manrope at 400, 500, 600, and 700 for display,
product UI, booking, tables, forms, and outbound messages. A single family
keeps the public and authenticated experiences related while weight, tracking,
size, and line height provide hierarchy. Font files and their SIL Open Font
License live under `public/fonts/clipperdesk/`. The operative scale is 12px for
eyebrows and supporting labels, 14-16px for product content and controls,
18px for lead copy, and a responsive 32-56px range for public section titles.
Authenticated page titles remain deliberately smaller. The shell uses a 4px
spacing base, 40px authenticated desktop controls (44px on touch devices),
and 48-64px primary mobile targets where the workflow benefits from them.

## Domain and message identity

Product name, company name, asset paths, public description, website URL,
booking host, support address, and the small server-to-client brand projection
live in `config/brand.php`. Environment-specific production domains and sender
addresses remain configuration, not component copy. The local booking-host
default is `book.clipperdesk.com`; it is a naming placeholder and does not
assert domain ownership. Do not publish links or send production mail until
trademark clearance, acquisition, DNS, SPF, DKIM, DMARC, return-path, bounce
handling, reply handling, and provider verification are complete.

## Shell rules

### Authenticated shop application

- Desktop uses a persistent 288px navigation rail and explicit working-shop
  context.
- Mobile and tablet use a top bar, focus-managed navigation drawer, and a
  five-destination quick-navigation bar.
- The required PRD destinations are always represented. A
  `navigationVisibility` map may remove presentation links after the server has
  evaluated permissions. It is never an authorization mechanism.
- Module URLs are stable and route-owned so later date, location, and filter
  context can be represented in the URL rather than hidden component state.
- Unimplemented modules render scoped placeholders with requirement IDs and
  explicit non-goals. They do not render sample appointments, clients, money,
  inventory, or reports.

### Public booking and self-service

- This is a separate mobile-first layout, not a reduced staff shell.
- Booking progress is textual and non-colour-dependent. At step zero it states
  that the client is ready to start; future steps use `aria-current="step"`.
- Secure self-service is visibly distinct from new booking and never asks for
  a raw reference while token verification is unimplemented.
- Public copy must state the governing local time zone when time becomes part
  of a workflow.

Under ADR-074, optional salon media uses a real-photo mosaic and accessible
gallery; no-photo pages use business information and initials. Public team
cards show only publishable profile fields. Selecting a professional preserves
the existing booking policy and qualified service/branch rules. The owner image
editors show saved/local previews and explicit saves, with per-photo editing
disclosed on demand. Avoid displaying every caption/order/removal control for
every gallery tile at once. Completed-visit feedback starts with concise visit
context, rating and optional text; public-display consent is a separate unchecked
choice. Private feedback, public review, loading, expiry and retry cooldown use
the shared notice/action contract. See [booking presentation](modules/booking-presentation.md)
and [client reviews](modules/client-reviews.md).

### Platform administration

- Deep navy navigation, cyan accent, and the persistent `Platform admin` label
  distinguish platform operations from tenant work without introducing a
  separate brand palette.
- The shell uses the existing global `admin` role gate. Ordinary users receive
  HTTP 403.
- Platform role does not grant tenant entry. The persistent warning states that
  support access is inactive until reasoned, scoped, expiring, visible, audited
  grants are implemented.

## Reusable component rules

| Component | Rule |
| --- | --- |
| `PageHeader` | One page-level `h1`, optional eyebrow/description, actions wrap rather than overflow. |
| `AppButton` | Primary, secondary, quiet, and danger variants; 40px workspace desktop / 44px touch height; disabled state uses native `disabled` plus `aria-disabled`. |
| `FormField` | Visible label is required; hint and error IDs are passed to the input through slot props; required and error meaning is textual. |
| `DataTable` | Requires a screen-reader caption and receives keyboard horizontal scrolling when content exceeds the container. |
| `SurfaceCard` | Raised grouped content with optional heading, description, and actions. Do not nest cards for decoration. |
| `AppDialog` | Native modal dialog, labelled title/description, cancel receives initial focus, Escape cancels, destructive confirmation uses danger language and styling. |
| `AppNotice` | Shared neutral inline notice with semantic icon, heading/body and a spaced wrapping action slot; colour never carries meaning alone. |
| `ToastRegion` | Polite live region by default; error messages use alert semantics; every message has a 44px dismiss action. |
| `SkeletonBlock` | Announces loading with `role="status"` and `aria-busy`; animation stops under reduced motion. |
| `StatePanel` | Shared empty, loading, information, error, and success structure with icon plus text so status never relies on colour alone. |

Destructive actions require an explicit dialog naming the affected object and
consequence. The safe action receives initial focus. Success toasts confirm the
result; error states explain recovery without removing the user's input.

## Accessibility and responsive rules

- WCAG 2.2 AA is the target for public booking and core shop work.
- Global `:focus-visible` uses a 3px blue ring with a 3px offset.
- Skip links target a focusable main landmark on all three shells.
- Mobile drawers use `role="dialog"`, `aria-modal`, an accessible name, focus
  entry, focus wrapping, Escape close, and focus return.
- Touch controls are at least 44 by 44 CSS pixels. The bottom shop navigation
  uses 64px rows plus safe-area padding.
- At 360px there must be no page-level horizontal overflow. Tables may scroll
  inside their labelled wrapper.
- Motion is optional. The reduced-motion media query collapses transitions and
  animations to 0.01ms, prevents repeats, and disables smooth scrolling.
- Every loading, empty, error, and success state has a textual title and may
  include a recovery action. Error and success states use live-region roles.

## Current Settings page: documented review example

The current Settings destination is served by the business-configuration setup
surface. It is an implementation baseline, not the approved final Settings
experience. This standards update intentionally makes no change to that page.

The current surface demonstrates problems these standards are intended to
prevent:

- many business identity, regional, contact, legal, booking, availability,
  import, preview, and publishing concerns appear in one long page;
- country code, locale, currency, and time zone are unrestricted text inputs
  even though ClipperDesk knows or can centrally source valid values;
- technical representations such as codes, minutes, and price in minor units
  are exposed directly to normal users;
- an aggregate “check the highlighted fields” notice is detached from the
  affected controls, while individual field errors are not presented
  contextually; and
- readiness information is useful for publishing but must not replace inline
  form guidance or make unrelated editing feel like one large launch task.

When the Settings experience is reviewed in a separate task, the team should
first map the settings jobs and frequency by role. It should then evaluate a
clear information architecture for concepts such as Business profile, regional
defaults, Locations and hours, services and resources, staff, booking rules,
communications, legal/privacy, imports, and publishing. That review must not
blindly turn this list into tabs; it must choose page, section, step, drawer, and
advanced patterns based on real workflows.

At minimum, the future Settings design must use shared structured selectors for
country, locale/language, currency, time zone, statuses, and other known option
sets; display human units rather than storage units; connect validation and
recovery to each affected control; use sensible and reviewable defaults; and
keep advanced or infrequent configuration out of the common path.

This example is a review benchmark, not a completed redesign or authorization
to modify Settings within the current documentation-only task.

## Mandatory workflow for every UI task

No significant UI implementation should begin from a list of backend fields.
Before code changes, the task owner must complete the following lightweight
experience brief in the task plan, design note, or pull-request description:

| Question | Required answer |
| --- | --- |
| User and context | Who is doing this, in which role, Location, device, and operational situation? |
| Outcome | What observable result must the user achieve? |
| Primary action | What is the single most important action or decision? |
| Supporting information | What must be visible before the user can act safely? |
| Secondary/advanced needs | What can be deferred, collapsed, moved, or omitted? |
| Data entry | Which values are known, inferred, inherited, selected, or genuinely free text? |
| Rules and permissions | Which requirement, domain rule, tenant boundary, and role govern the surface? |
| State model | What are the loading, empty, error, success, disabled, stale, partial, and permission states? |
| Responsive behavior | What changes at 360px, tablet, and desktop without changing the outcome? |
| Accessibility | How will keyboard, focus, labels, announcements, contrast, reflow, and motion work? |
| Trust and consequence | What affects money, time, consent, availability, privacy, history, or another person? |
| Reuse | Which tokens, components, option sources, and existing patterns should be reused or extended? |
| Simplification | What typing, click, field, confirmation, or page transition can the system remove? |

For a significant new page, multi-step workflow, or redesign, create or select
a visual target before production implementation. The target may be a reviewed
wireframe, mockup, prototype, or established ClipperDesk pattern. It must cover
the information hierarchy and primary responsive behavior; prose or a database
schema alone is not a visual target.

### Implementation review checklist

Before considering a UI task complete, confirm:

- [ ] The result matches an approved requirement and does not introduce Phase
  2 behavior.
- [ ] The page is organized around the user's outcome, not the persistence
  model.
- [ ] One primary action is clear and secondary actions do not compete with it.
- [ ] Known values use centralized structured inputs rather than free text.
- [ ] Defaults are helpful, visible when consequential, and safely reversible.
- [ ] Validation is contextual, understandable, programmatically associated,
  and preserves entered work.
- [ ] Default, focus, selected, disabled, loading, empty, error, success, stale,
  and permission states were handled where applicable.
- [ ] Dates, times, time zone, Location, currency, and units are explicit where
  they affect a decision.
- [ ] Authorization, tenant isolation, privacy, audit, and append-only history
  remain enforced beyond the visual layer.
- [ ] Existing semantic tokens and reusable components were used; any new
  pattern has a clear reuse case.
- [ ] The journey works without page-level horizontal overflow at 360px and is
  usable at tablet and desktop sizes.
- [ ] Touch targets, keyboard flow, focus behavior, labels, semantics,
  contrast, non-colour cues, zoom/reflow, and reduced motion were checked.
- [ ] Loading and interaction behavior meet the perceived and measured
  performance expectations.
- [ ] Microcopy uses ClipperDesk language and does not expose implementation
  terminology.
- [ ] Relevant automated, browser, and visual evidence is recorded before
  `project-status.md` claims the behavior verified.

### Evidence expectations

Verification should be proportional to the change, but significant journeys
must include representative real states rather than only an ideal populated
screen. Capture and review at least mobile, tablet, and desktop behavior when
layout changes materially. Exercise keyboard interaction, focus entry/return,
validation recovery, loading, empty, failure, success, and destructive or
stale-state behavior where relevant.

Automated accessibility checks are useful but do not replace keyboard,
screen-reader spot checks, responsive review, or visual comparison. A
screenshot alone is not proof that interaction, reading order, responsive
behavior, authorization, or state recovery works.

## Governance and exceptions

- Extend an existing pattern before creating a near-duplicate component.
- Add shared options to a central source; do not copy them into a page.
- Keep semantic component APIs and tokens independent of a single module.
- Do not change a global token to fix one local layout problem.
- Record a durable new pattern or product exception in this document or an
  accepted decision, and keep the relevant module document synchronized.
- A temporary exception must name the constraint, user impact, safe fallback,
  and follow-up. “Faster to implement” is not sufficient on its own.
- Review existing screens against these standards when they are materially
  changed; do not expand unrelated scope solely to make an untouched surface
  compliant.
- Do not mark a surface “premium,” accessible, responsive, or verified without
  evidence.

## Evidence

Browser screenshots are stored under `docs/evidence/product-shell/` for public
booking at 360px, the shop dashboard at 360px, 768px, and 1440px, and platform
administration plus the reusable interface-pattern reference at 1440px. The
ClipperDesk rebranding adds representative desktop and mobile evidence at the
same location. Exact automated and browser verification results are recorded in
`project-status.md` and the dated rebranding audit.


## Authenticated workspace refinement (2026-09-13)

ADR-037 establishes a compact operational layer in `resources/css/workspace.css`,
imported from `app.css`. Scope density rules to `.cd-workspace`; public booking
continues to use generous default control sizes. Preserve the existing navy,
indigo and cyan identity and readable 14–16px body text.

| Pattern | Workspace default |
| --- | --- |
| Spacing | 4px base; 12px related controls; 16–20px card padding; 20–24px major sections |
| Controls | 40px desktop, 44px mobile/coarse pointer; 8px corners |
| Row actions | Explicit small button variant, 32px desktop / 44px touch |
| Menus | 36px desktop / 44px touch options; 10px corners; restrained menu shadow |
| Surfaces | 12px panel corners; quiet border; avoid nested empty-state borders |
| Typography | 24px page heading; 15–18px section headings; 14px body; 12px supporting labels |
| Tables | 14px body; 12px column labels; approximately 11px vertical cell padding; accessible horizontal overflow |
| Shell | 240px desktop sidebar, 56px top bar, clearly separated navigation groups |
| Drawers | 576px maximum, full width on narrow screens, independent body scroll and reachable action footer |

Use `AppSelect` for authenticated single and multiple selection. It retains
native options, typed values, validation and change events; enhances them with
search for longer lists, bounded scrolling, selected indicators, keyboard
navigation, Escape and focus restoration. Keep dates/times native where that
preserves reliable regional entry. Use semantic labels and associate errors;
never remove the required reason or other audit inputs to achieve density.

Use shared `SurfaceCard`, `PageHeader`, `FormField`, `AppButton`, `AppDialog`,
`DataTable` and `StatePanel` before writing a local variant. Keep catalogues
readable at full width; open add/edit work in a drawer when it would otherwise
compete with the list. Prefer one searchable report selector over duplicate
navigation. Disclose secondary calendar filters while preserving visible
location/date and Day/Week/Team controls. Client section tabs have a tablist,
selected state, roving focus and keyboard-operable panel navigation.

The calendar details/attention panel starts collapsed so the schedule occupies
the available width. Its explicit toggle announces expanded state; selecting a
visit opens actions, and closing returns focus. On narrow screens the panel
appears above the schedule. Keep the first hour label inside the grid boundary;
do not move appointment positions to solve label clipping.

Reports display UTC source timestamps in the stated report time zone and use
human-readable column labels. Preserve the original data and export contracts;
provide full source references on demand rather than making them the primary
visual content.

Inventory is temporarily hidden from both navigation menus at the user's
request. This is menu visibility only; no domain implementation or entitlement
contract is removed or promoted to a new delivery phase.

Verified screen coverage and limitations: [workspace refinement audit](audits/2026-09-13-workspace-refinement/README.md).

## Operational density refinement

Use the presentation contract in `modules/product-experience.md`. Page headings
use 24px; section headings use 17px. Standard desktop controls use 40px and
touch controls at least 44px. Do not change root rem size or transform the UI.
Keep public/auth inputs at 16px. Remove redundant decorative subtitles; retain
point-of-action guidance for consent, payments, publishing and destructive acts.

## Record composition follow-up (2026-10-02)

The StepES-inspired follow-up uses light navigation, a pale canvas, 26px
workspace page headings and 10px panel corners. `workspace.css` owns density;
`workspace-records.css`, imported by authenticated layouts, owns breadcrumbs,
search/filter toolbars, record metadata and responsive table composition. Use
shared `SearchField` and `DataTable`; avoid shrinking action labels or splitting
amounts to force a table to fit. Mobile metadata and hidden columns share the
768px breakpoint; small icon buttons retain 44px width and height. Preserve
full business-entered text and essential payment/delivery guidance.

See [fresh verification and gaps](audits/2026-10-02-stepes-inspired-refinement/README.md).

### Workspace surface and text hierarchy

Use the shared workspace tokens to distinguish primary-blue navigation, canvas
(`#edf1f7`), filter toolbars (`#f8faff`), table headings (`#e9eef7`) and white
record surfaces. Use navy ink for primary information (`#17243d`), body text
(`#34435b`), secondary text (`#53627a`) and labels (`#40516d`). Keep indigo for
actions and identity accents; preserve semantic status colors.
Do not make every card colorful or use low-contrast gray to create hierarchy.
Mobile navigation uses the same surface token. Public surfaces keep their own
existing palette. [Fresh visual evidence](audits/2026-10-02-surface-hierarchy/README.md).

### Blue navigation and signed-in header

The owner's brand correction selects brand-primary navy (`#172554`) for
the desktop sidebar and mobile navigation drawer. Use the inverse brand mark,
light navigation text, a translucent selected surface and a small cyan selection
edge. Navigation has locally scoped inverse text/surface/border tokens so content
colors stay unchanged. White keyboard focus outlines remain visible on blue.

Signed-in headers use a restrained white-to-navy wash, compact business initial,
and a blue account avatar with a clear menu disclosure. Keep existing setup and
subscription states, touch targets, truncation and permissions. Collapse decorative
identity details on small screens; do not add unsupported search/notification
actions to make the header look busier.
[Fresh verification](audits/2026-10-02-brand-account-menu/README.md).

The public frontend distinguishes brand-primary navy from action-primary indigo
(`#4338ca`). Navigation and header identity use the brand token; primary actions
retain the action token. Do not substitute the action color for the brand color.

Account disclosures use 14px medium-weight icon rows, a 14px semibold account name
and 12px secondary email. Use sentence case and a divider before Sign out. For a
single permitted billing workspace, show a direct Subscription & billing action;
for several, group their unchanged names under Business billing. Preserve the
existing billing permission filter. Bound the panel to the viewport, wrap long
identity details, retain keyboard dismissal/focus restoration, and use 44px rows
on small screens or coarse pointers.

## Clients operational CRM (2026-10-03)

Clients retain the shared navy navigation, account header, buttons, accessible
selects and native dialogs. A scoped stylesheet owns the directory and profile:
64px desktop rows, one identity target, aligned visit columns, restrained
important-note markers, compact metrics and five profile sections. Explicit
preferences and historical service patterns have different labels. On phones,
next appointment and important service notes precede deeper history; history
tables scroll within their own positioned container. Profile editing uses a
drawer with visible audit reason, validation, focus restoration and unsaved-change
protection. No decorative count badge or unsupported benefit program is added.

[Clients evidence and practical limits](audits/2026-10-03-clients/README.md).

## Help Center and contextual guidance (2026-10-24)

Under FR-21 and ADR-070, Help reuses the public MarketingLayout and shared semantic
surface, typography, action and focus tokens. Its reading column, restrained topic
cards, labelled search, breadcrumbs, contents links and related guides are a
product surface rather than a second theme. Persistent search/feedback failures
use AppNotice with useful browse/support paths; suggestions stop on persistent
failures and honor Retry-After. Preserve query text and prevent duplicate votes.

Authenticated headers use one labelled Help disclosure with relevant guides and
all-help discovery. It remains reachable by keyboard and on phones. Article
screenshots use intrinsic dimensions, lazy loading, meaningful alternatives and
native modal expansion with Escape/focus restoration; enlargement scrolls inside
the dialog instead of overflowing the page. Minimum 44px actions, 10px wrapping
gaps and 14px text/action separation apply. No-JavaScript articles retain numbered
steps, real images and the public navigation. Verify actual notices and long text
at phone and desktop widths after changes. [Evidence and gaps](audits/2026-10-24-help-center/README.md).

### Recovery actions must advance the flow (2026-10-25)

For checkout verification failures, distinguish a safely restartable preparation,
a pending payment and a genuinely ambiguous result. Offer immediate Start again
only where the server permits it; an outstanding invoice gets Open invoices and
a visible wait for later status checks. Retain original purchase context separately
from edited estimates. Verify that restart unlocks review with those edits intact,
and that successful payment clears the unfinished state. Financial time handling
must be tested with fractional real-clock observations as well as signed events.
Use the same shared notice/action hierarchy above; do not expose test-mode or
server configuration instructions in customer copy. SDK tests and static screenshots
are insufficient evidence that a deployed customer can complete payment.

### Every word must serve the customer (2026-10-25)

Write for a busy, non-technical business owner. Each sentence must explain an
outcome, support a decision or identify a useful next action; remove repetition
and implementation narration. Use “Your subscription is active” after a first
payment, “Your subscription has been updated” after a paid change, and “Your
updated subscription starts on [date]” for a scheduled change. Avoid customer-facing
“capacity is verified”, “provider”, “reconciliation” and “request state”. A success
heading can stand alone; do not add a body that repeats it. Pending payments must
remain described as pending, never successful. Apply this review to labels,
notifications, loading/empty/error states, dialogs, public pricing and help copy.

Locations is a direct workspace navigation item alongside Services, sharing
settings permissions and the existing responsive menu. At the purchased limit,
the location action reads “Upgrade to add locations” and opens billing.

### Address fields with suggestion menus (2026-10-31)

Google address search retains its supported autocomplete widget. Its wrapper and
containing location form card must allow the dropdown to extend below the input;
rounded field styling must not be achieved by clipping the suggestions.
`SurfaceCard` offers the explicit `overflowVisible` opt-in for this use. Default
card clipping remains unchanged. Keep widget styling in the shared LocationEditor
so signup, guided setup and Locations have the same presentation. Verification
must include actual predictions at desktop and mobile widths; API responses or
mounted selection tests alone do not prove the list is visible.

### Business booking accents (2026-10-31)

Saved business accents apply only inside that business's public booking layout
and actual private preview. Preserve the exact accent for decorative progress;
derive readable action, hover and focus shades and a light selection tint. Keep
white button labels and accent text at least 4.5:1 against their light surfaces.
Do not recolour platform identity or success/warning/error meanings. Missing or
invalid values inherit the platform defaults; no global document-theme mutation.

## Subscription offer experience (2026-11-01)

Discount configuration uses the existing Filament admin forms under Payments →
Discounts & coupons. A Require a coupon code switch reveals manual entry, explicit
Generate code button and combination setting. Generating is an intentional action;
loading or editing never silently changes a shared code. Describe UTC date windows,
first-payment scope and the effect of disabling offers before saving.

Public and owner automatic offers are part of the price summary, using the
shared subscription-offers styling: a small decorative gift icon, concise campaign
name and a high-contrast percentage badge. Do not present an offer as a full-width
workflow notification. Keep 18px below the public estimate eyebrow, allow long
names to wrap and keep the badge readable. The discounted first payment leads;
the regular renewal and tax qualifier follow directly beneath. No expiry or
checkout-instruction paragraphs appear on public pricing. Coupon entry is a
44px disclosure inside the subscription summary, immediately before review;
its contents retain input through errors and review cancellation.

Persistent workflow feedback still uses AppNotice. Coupon errors say
Check your coupon code and retain input; do not label them payment outages. The
review lists named savings, first payment and full renewal, with explicit annual
or monthly cadence and before-tax wording. Use the existing shared dialog action
row; both review actions and generator/save controls remain at least 44px on mobile.

### Separate yearly and promotional savings (2026-11-01)

Yearly summaries show 12 monthly payments, the yearly saving, the regular yearly
subscription, then any named first-payment promotion separately. Total first-year
savings compare the actual first payment with 12 monthly payments; never add the
percentages. Without a promotion, show only the recurring yearly saving. Existing
retained-rate comparison guards remain. Pricing page signed-in owner actions,
including header/mobile CTA, open an authorized workspace's subscription Plan tab
with Manage subscription wording. Accounts without billing authority retain the
existing workspace fallback; no authorization is bypassed.

Offer-change recovery: the obsolete review closes and a single Review your
updated offer notice directs the owner back to Review subscription. Preserve the
selection/code and enable review immediately. An unchanged offer's JSON object
field order is never a reason to interrupt checkout.

### Checkout provider rejection classification (2026-11-01)

Trace nested provider exceptions through adapter wrappers. Confirmed provider
400/401/402/403/404/422 responses require platform recovery and the reachable
support reference, rather than describing them as a transient outage. Hide
Start again and Check again for support-required failures. Unknown transport
outcomes remain protected and cannot be discarded as failed payments. Production
reference 01M6B8F01JVY0G7BK4J67D3D9G still needs read-only diagnosis; a screenshot
of a submitted local request is not evidence of a paid or failed Stripe session.

## Optional analytics choice (2026-11-02)

Public marketing measurement uses a restrained AppNotice in a bounded bottom panel.
Explain the optional purpose and provide Accept analytics and Reject analytics
with equal visual weight, at least 44px targets and a wrapping action row with
10px gaps and 14px copy separation. Link the privacy notice. A persistent footer
Cookie settings control reopens the choice and permits withdrawal. Do not
block reading or make rejection require more steps. The saved/disabled state and
browser privacy signal must be understandable; analytics failures never block
navigation, sign-in or registration. Verify initial choice, rejection, reopening,
acceptance, withdrawal and phone wrapping, including a blocked Google script.

## Public legal publication metadata (2026-11-02)

Published policies show their version, last-updated date and effective date in
a compact responsive definition list. Do not retain review-only warnings, empty
review fields or proposed-contract wording on an owner-published document, and
do not replace them with a redundant success notice. Terms uses three metadata
items; the separate review-stage Refund Policy keeps its existing warning and
four metadata items. This visible publication state does not represent counsel
approval or an operational certification. Preserve readable wrapping, the shared
Print or save as PDF action and the policy links at desktop and mobile widths.
See ADR-080 and the public-website module.

## Article editing recovery (2026-11-04)

Within Filament Content → Articles, keep image-format/size guidance beside the
featured-image control. Upload validation must name the image and preserve the
article text, with draft saving available when the image is unavailable. Do not
repeat the raw component state path or imply a failed image was saved. Keep
native field feedback associated with its input and save confirmation brief;
do not add a second persistent banner for the same field failure. Draft and
publication choices must state their public outcome. Use one Status control,
Draft or Published, in Article; infer the named administrator and UTC review/
publication times when the action completes. Do not ask for a separate reviewer
or date when the platform can record it. Preserve the first publication date on
ordinary edits, and label displayed timestamps with UTC. Clear an old upload
error when its replacement upload succeeds, without clearing unrelated errors.
The native Status select itself has a 44px minimum hit area; the wrapper alone
does not establish the control's touch size. Retain the shared Filament mobile
button sizing and wrapping action spacing.
Verify long recovery copy, actual save controls and
upload/success states at desktop and phone widths before claiming UI completion.


## Visit email actions and issued receipts (2026-11-05)

Completed-visit review actions use a wrapping Send review email / Copy review
link row, with 10px gaps and 14px separation. Existing feedback replaces outreach
actions. Persistent email outcomes use AppNotice and direct staff to Client
notifications for delivery evidence. No generate/preview/send sequence is required.
Receipt actions distinguish View receipt, Download PDF and Send receipt; native
PDF links download rather than requesting an Inertia page. The issued document
shares a restrained navy heading, local issue metadata, paid/outstanding label,
itemized table and right-aligned summary between online and A4 output. Print
repeats item headings and keeps summary totals together. No toast announces inbox
delivery merely because a request was queued.

## Email-led setup and migration assistance — 2026-11-06

Owner-approved FR-02 acquisition refinement: promote personal account setup and
reviewed migration help on Home, Pricing, industry solution pages, feature detail
pages and the product walkthrough. Shared SetupSupport uses existing marketing
tokens, a wrapping action row and the configured support email. Requirements are
gathered manually by email; no intake form, upload, migration engine or in-app
workflow is added. Describe clients and upcoming appointments/bookings explicitly;
other records depend on review. Agree scope, timing and any costs before work;
never promise universal compatibility, free service or a fixed turnaround. Ask
for no client files in the initial email. Owner review precedes going live.

The receipt refinement uses the existing ClipperDesk monogram embedded locally,
a thin indigo top rule, subdued metadata panel and small Powered by ClipperDesk
footer. Business identity remains primary; status is aligned beside it and issue
metadata is separate from customer details. Mobile metadata stacks naturally.


## Focused audience resources — 2026-11-07

Existing salon/barbershop pages add server-selected editorial links using the
normal Article publishable scope. Hidden, future and draft articles remain
excluded. Reviewed client-profile and walk-in-queue media supplement existing
screens. Five existing articles offer blank printable worksheets and links to
relevant walkthrough anchors and industry pages. Templates collect no input.
Reuse shared typography, cards, focus styles and wrapping 44px actions. Print
shows the worksheet alone. Preserve stable article URLs, metadata and dates;
no database publication, fabricated review or ranking guarantee is introduced.


## Three-month account trial — 2026-11-07

Owner-approved FR-01 change: newly verified accounts receive three calendar months,
clamping month-end dates without overflow. Existing saved trial dates and paid
subscriptions are unchanged. Public pricing uses “Three months to make it yours”
and “3-month free trial”, without launch/urgency claims. No card is required;
a paid subscription requires separate confirmation. Actual saved end dates remain
authoritative in the subscription workspace.

Pricing trial CTA refinement: “Start your free trial” carries a compact, static
lightning badge reading “3 months free” at the top right. The contrasting lime
badge has no animation or urgency claim. Visual verification remains pending.

Trial badge palette refinement: pricing and signed-out desktop/mobile header
trial actions use pale indigo, navy text and a gold lightning icon. Authenticated
subscription/dashboard actions omit the badge. Supersedes the lime palette above.


### Seeded demonstration readiness — 2026-11-07

Demonstration fixtures must save actual guided-completion state and pass the same
readiness projection as operational businesses. Keep demo provenance separate
from generated starter provenance, so an established demo shows its current
configuration rather than introduction prompts or claims that no client activity
exists. The Canadian demo was checked at desktop1440 and phone390×844; see
[the evidence](audits/2026-11-07-canadian-demo/README.md). No shared layout, notice
component or ordinary customer onboarding branch changed.

## Marketplace foundation — 2026-11-08

The customer marketplace uses a scoped ivory/forest/sage palette, editorial serif
accents, real inspirational salon imagery and separate customer navigation. Keep
Business links explicit and preserve public salon media/consent gates. Scope class
names to avoid framework hero-layout collisions. Empty/no-match feedback reuses
AppNotice with useful direct-booking management and broader-search actions.
Customer accounts and messaging must not be advertised until implemented. Manual
payment copy must not promise pay-later booking when a salon requires a deposit.

### Connected marketplace journeys — 2026-11-08

Shared MarketplaceLayout extends the approved discovery identity through salon,
customer sign-in, bookings, favourites and conversation pages. Business retains
its existing workspace shell and adds explicit Business identity/acquisition links.
Use canonical SalonShowcase, ProfessionalCards, LocationCard and consented review
presentation inside the customer theme. Never substitute stock imagery for a
real salon's missing photos. The discovery hero/category imagery remains labelled
inspiration; no fictional listings are inserted into the ordinary database.

Keep the monogram/wordmark from shrinking or wrapping at phone widths. Customer
navigation wraps with at least 44px touch targets; action groups wrap with gaps.
Use restrained AppNotice for saved/failed/paused states. A blocked map offers Show
salon list; expired sign-in offers Get a new sign-in link; a stale listing offers
Refresh listing details. Cooldowns count down before mutations re-enable; persistent
failures preserve entered text and expose support, not repeated retries. The final
filter/map/navigation refinements still need visual recheck after browser access
was disabled; earlier local booking/messaging observations do not certify those.

### Marketplace search and account refinement — 2026-11-08

Use one aligned service/location/date search bar, contextual panels and a single
Search action. Optional Today/Top rated choices use compact pills; no currency
selector appears in customer discovery. Panels close on outside click/Escape,
remain keyboard reachable and stack within the phone viewport. Suggestions label
their actual scope (current result page); never invent recent searches or ratings.
Profile has dedicated account navigation, clear verified email, name/mobile edit
and logout. Successful saves return to profile with the shared restrained notice.
Marketplace email uses the standard transactional message/header/footer structure
with forest/sage overrides, not an independently maintained HTML layout.

### Unified Marketplace booking and map — 2026-11-08

Reuse the established booking page instead of adding a second service/time selector
before it. Retain salon photos/accent, canonical booking steps and customer account/
favourite actions. Discovery suggestions show real named services and categories,
not broad editorial chips masquerading as services. Category cards have selected
feedback and bring results into view, respecting reduced-motion preference.

Google location suggestions use the supported attributed widget without shadow-DOM
patches. Map view pairs numbered pins with selectable salon cards and a clear
Explore & book action. Selection highlights a card without immediately navigating
away. Show all pins resets the view. Keep explicit page scope, no-pin cards, Google
attribution and a working list fallback on provider failure. At phone widths stack
the map and list; controls retain44px targets. Final visual/provider confirmation
is pending because browser control was disabled during this continuation.

### Business brand and customer account workspace — 2026-11-08

The owner's follow-up replaces the detached Business qualifier with a compact,
vertically aligned mark/name/Business lockup. The shared Business header offers
Find a salon as a quiet sage Marketplace entry within navigation. Remove the large
appointment-prompt strip above the Home hero; it repeats that action and competes
with the acquisition message. Use the navigation drawer below1280px rather than
squeezing the full navigation, brand and trial controls into a narrow row. The
existing trial badge, primary CTA and Business root/acquisition intent remain.

Customer bookings, inbox, profile and conversation share MarketplaceAccountLayout:
1440px outer alignment,210px identity/navigation rail, restrained40px page headings,
consistent48px controls,14px card radii and24px section rhythm. At850px the rail
becomes a four-item horizontal account navigation; secondary columns stack before
form fields become cramped. Sidebar groups use a shared20px gap. The optional phone
control and name/email inputs share a48px baseline. Long names/addresses must wrap.
Persistent confirmations/errors continue to use AppNotice; validation stays by its
field. Global notices align to the same outer width as the customer header.

Booking cards separate the local-date tile, salon/services, full zoned time/address,
status, booking reference and wrapping action footer. Do not replace an awaiting-
approval status with a confirmed claim. Favourites retain real saved salon links.
The inbox uses a single list surface and consistent rows; it does not invent last-
message previews or presence. Refresh is explicit and disabled while loading.
Conversations use a labelled scrollable message history, distinct sender/own bubbles,
explicit timestamps/read state, a dedicated composer, and adjacent booking/control
cards. Pause/report, replay keys, saved drafts and tenant authorization remain.
The mobile icon-only refresh retains its accessible name. No realtime status or
chat-delivery promise is introduced. Business-side conversation wording reflects
the customer recipient and remains inside the existing Business shell.

Current source/build/mounted-test evidence is in
[the refinement audit](audits/2026-11-08-marketplace-account-design/README.md).
Browser access was disabled; this is not desktop/mobile visual certification.

Profile refinement: omit the redundant right-hand email/sign-in information cards.
Use a single profile surface across the account content width; keep logout in the
shared navigation instead of repeating it inside an informational card.

Marketplace identity refinement: reuse the Business interlocking CD path geometry
in the forest/lime rounded badge, retaining the small lime sparkle. The customer
wordmark reads “Clipperdesk” with a capital C in header/footer. Reuse the canonical
vector geometry; do not substitute a typed letter for the monogram.

Marketplace email identity: reuse `emails/partials/marketplace-brand.blade.php` in the
Marketplace account mail shell and client appointment/service renderer. Use the
192px PNG CD/sparkle export at44px, capital-C Clipperdesk, letter-spaced Marketplace
and the forest/sage/ivory palette. Keep existing table/inline-style email structure
and salon details; Business operator streams retain their existing identity. Local
PNG was inspected, and rendered HTML/SES mocks checked; no real inbox rendering or
external message was observed in this refinement.

### Marketplace customer picture and cookie choices — 2026-11-09

The profile avatar is a real keyboard-accessible picture-picker button with a
small camera badge; the native file input is hidden. Keep its 56px target, visible
focus and Add/Change profile picture accessible label. Preview locally, then offer
explicit Save photo / Cancel inside the identity header only while a draft exists.
A saved picture offers a small corner × with a Remove photo tooltip. Reveal it on
hover/focus and keep it available on touch. Use a 44px hit target around the small
visible icon. Open AppDialog before removal, focus Keep photo first and preserve
the saved photo on cancellation/failure. There is no
separate photo section or always-visible format/privacy paragraph. Put format/size
help in the accessible avatar description. Failures
retain the draft/current image and use AppNotice. Header and account rail reuse
the saved private image; initials remain the fallback. The account chevron is a
centred 14px SVG, not a baseline-sensitive text glyph. Cookie notices distinguish
essential cookies from optional measurement and use equal-weight Accept optional
cookies / Reject optional cookies controls, 44px targets and wrapping gaps.

Signed-in Marketplace pages share the compact account shell, action hierarchy and
44px targets. Remove decorative overlines, the repeated discovery promotion and
sidebar cards that repeat navigation/help already on the page. Desktop buttons
use 36px height and restrained 7px/12px padding; fields use 40px. Mobile buttons
and fields retain 44px targets, 16px input text and visible focus. Keep functional
saved businesses, visit details, conversation controls and actionable errors.
Use appointment/business wording so every supported audience feels included.

### Marketplace discovery → business booking continuity — 2026-11-09

Use MarketplaceLayout itself for Marketplace booking, rather than adding a
Marketplace label beside ProductMark in the operational/public-booking shell.
Keep the same header/logo, customer navigation, ivory canvas, forest/sage surfaces
and footer at every booking step. Place the existing progress indicator and
business catalogue within this shell. Business logo/photos/name and configured
accent remain local to the inner booking content. Provide one shared success/
recovery notice and one account navigation, with existing booking-specific errors
remaining beside their workflow. Keep direct booking/private preview unchanged.

### Business Messages workspace — 2026-11-09

Messages is an operational Business workspace. Reuse AppLayout/PageHeader and
Business tokens for white raised surfaces, slate dividers, compact text and primary
actions. Keep listing/publication/report cards in Business setup, outside the inbox.
Use a two-pane inbox and conversation on desktop, a single selected pane with an
All conversations return on mobile. Provide name/reference search, All/Unread,
explicit disabled-while-loading Refresh, short plain previews and unread counts.
Do not invent presence, delivery immediacy or message content. Use a compact recipient
header, collapsed booking details, readable escaped bubbles, timestamps and one
labelled composer. Preserve drafts/replay keys across refresh, navigation and failed
sends. Paused/read-only/recovery states retain useful history and AppNotice controls.
Mobile controls keep 44px targets and inputs use 16px text. Keep keyboard focus visible.

Private customer Manage booking/actions, waitlist and existing forms/completion
reuse the Marketplace header/logo/canvas/footer with focused inner content widths.
The optional account navigation never makes a secure link require customer login.
Customer receipt HTML uses the same palette and raster mark while remaining a
printable issued document. Business print/PDF identity stays unchanged.

Marketplace mail uses a packaged CID raster logo with adjacent real text, one ivory
surround, restrained white content and forest/sage controls. Remove the redundant
account pill and repeated brand kicker. Use table/inline styles and useful text
alternatives. Synthetic HTML/MIME checks are not inbox-client or visual certification.


### Automatic listing visibility — 2026-11-11

The Business Marketplace listing page explains that published booking setup makes
the business searchable. Use the existing setup editors and one optional visibility
checkbox with Save visibility. The individual SEO request form, repeated consent
checkbox and approval/pilot notices are removed. Show a compact update/failure notice
only when it explains an actual saved change or recovery action. Booking activity
and its outcome report retain operational definitions. This refines MP-04’s owner
workflow without introducing another setup form.
