# Decision log

Use this file for durable product and architecture decisions. A decision is not
accepted until its status says `Accepted`. Pending entries are questions, not
permission to assume an answer.

## Decision record template

```text
### ADR-NNN: Short title

- Status: Proposed | Accepted | Superseded | Rejected
- Date: YYYY-MM-DD
- Owners: Product | Engineering | Design | Operations
- Related requirements: FR-NN

Context:
Decision:
Consequences:
Evidence or follow-up:
```

## Accepted decisions

### ADR-001: Markdown documentation is project memory

- Status: Accepted
- Date: 2026-07-27
- Owners: Product and Engineering
- Related requirements: All

Context: The product will be built through multiple Codex threads and by human
developers. Both need a durable shared source of truth.

Decision: Maintain the PRD, module specifications, architecture, quality gates,
status, roadmap, prompts, and decisions in `docs/`. Root `AGENTS.md` requires
agents to read and update them.

Consequences: A behavior-changing implementation is incomplete until its
documentation and verified status are updated. Chat history alone is not an
authoritative product record.

### ADR-002: Build a modular monolith first

- Status: Accepted
- Date: 2026-07-27
- Owners: Engineering
- Related requirements: All

Context: The Phase 1 workflow is highly transactional across booking, capacity,
payments, inventory, commissions, and audit history.

Decision: Build Phase 1 as a Laravel modular monolith with explicit domain
boundaries, services, policies, events, and jobs. Do not introduce distributed
services unless measured scale or isolation needs justify the added failure
modes.

Consequences: Cross-module writes can use database transactions where
appropriate. Boundaries must still be clear enough to extract later.

### ADR-003: The model is location-aware from the first migration

- Status: Accepted
- Date: 2026-07-27
- Owners: Product and Engineering
- Related requirements: FR-03 and FR-18

Context: Initial plans may expose one active location, but later plans require
multiple locations.

Decision: Entities, uniqueness rules, policies, availability, reporting, and
time handling must include location ownership where the domain requires it.

Consequences: The first UI may hide multi-location controls, but the data model
must not hard-code a global single-location assumption.

### ADR-004: Preserve history through versioning and compensating records

- Status: Accepted
- Date: 2026-07-27
- Owners: Product and Engineering
- Related requirements: FR-06, FR-12, FR-14 through FR-19

Decision: Financial, inventory, commission, consent, policy, and significant
appointment corrections must preserve the original event. Use immutable
snapshots, versioned rules, status history, or compensating entries rather than
destructive rewriting.

### ADR-005: Entitlements are independent of plan names

- Status: Accepted
- Date: 2026-07-27
- Owners: Product and Engineering
- Related requirements: FR-01

Decision: Capabilities and limits are represented as server-enforced
entitlements. UI visibility is not authorization. Pricing and plan names may
change without spreading plan-name conditionals through application code.

### ADR-010: Use a brand-neutral semantic shell until identity is approved

- Status: Superseded by ADR-011
- Date: 2026-08-10
- Owners: Product, Design, and Engineering
- Related requirements: PRD Sections 3, 4, 10, and 12

Context: OPEN-01 does not yet supply an approved product name, logo, palette,
typeface, or voice. The reusable shell cannot safely make those choices, but it
still needs concrete accessible tokens and product language.

Decision: Use semantic design tokens and the explicitly temporary label
`Salon operations`. Use a neutral text-first mark, system fonts, and direct
operational language from the PRD. Do not encode a permanent identity in
component names or APIs. OPEN-01 remains open and must be resolved before
production branding, domains, outbound messages, or documents are approved.

Consequences: The three shells and shared components can be implemented and
tested now. Final identity work should replace token values, label, logo assets,
and voice guidance without restructuring navigation or component behavior.

Evidence or follow-up: Implemented tokens and component rules are recorded in
`design-system.md`; browser evidence is under `evidence/product-shell/`.

### ADR-011: Adopt Good Hours as the product identity

- Status: Superseded by ADR-027
- Date: 2026-08-11
- Owners: Product, Design, and Engineering
- Related requirements: PRD Sections 3, 4, 10, and 12

Context: OPEN-01 required a permanent product name, logo, voice, palette,
typography, domain direction, and outbound-message identity before the neutral
shell could become a production brand. Three complete visual directions were
reviewed, and the Good Hours direction was selected.

Decision: The product name is **Good Hours** and the brand promise is **Make
every hour count.** The generated mark combines an open doorway, sunrise, and
clock arc to express welcome, useful time, and a well-run service business. The
identity deliberately avoids scissors, barber poles, moustaches, script
lettering, black-and-gold luxury, and AI positioning so it can credibly serve
barbers, salons, spas, independents, and multi-location teams.

The permanent foundation uses deep pine `#173F3A`, accessible action poppy
`#C13F28`, expressive poppy `#E56A4D`, apricot `#F2B880`, oat `#F6F1E8`, and
ink `#19201F`. Manrope is the product and message typeface; Newsreader is
reserved for selected editorial display headings. Both are self-hosted under
the SIL Open Font License.

The preferred public domain is `getgoodhours.com`, with
`app.getgoodhours.com` for authenticated work and `book.getgoodhours.com` for
public booking. An RDAP check on 2026-08-11 returned no registration record for
`getgoodhours.com`; this is a point-in-time availability signal, not ownership.
`goodhours.com` and `goodhours.app` were already registered and are not launch
assumptions.

Outbound identities are:

- account and billing: `Good Hours <account@getgoodhours.com>`;
- appointment and client messages: `[Business name] via Good Hours
  <appointments@getgoodhours.com>` with a verified tenant reply-to where
  available;
- human support: `Good Hours Support <support@getgoodhours.com>`; and
- security-sensitive mail: `Good Hours Security <security@getgoodhours.com>`.

No production sender may use these addresses until the domain is acquired and
SPF, DKIM, DMARC, return-path, reply handling, and provider verification pass.

The voice is calm, capable, human, and clear. Use sentence case, concrete next
steps, local date/time context, and reassuring recovery language. Avoid hype,
beauty clichés, blame, artificial urgency, and unsupported business claims.

Consequences: OPEN-01 is resolved and ADR-010 is superseded. Existing semantic
component APIs remain stable while their values, product mark, page titles,
booking language, and auth identity adopt Good Hours. Formal trademark
clearance and domain acquisition remain launch-readiness work under OPEN-11;
selection of this identity does not represent a legal clearance opinion.

Evidence or follow-up: Concrete rules are in `design-system.md`. The selected
visual reference and post-build browser evidence are recorded by the product
shell design-QA workflow.

## Foundation decisions

### ADR-006: Use an explicit Business as the canonical tenant

- Status: Accepted
- Date: 2026-08-11
- Owners: Product and Engineering
- Related requirements: FR-01, FR-02, FR-03, FR-05, FR-19, FR-20

Context: Larafast contains Jetstream Team models, pivots, invitations, actions,
and pages, but Team support is disabled. Registration still creates a personal
Team. Team provides collaboration-workspace semantics and no Business
lifecycle, location ownership, support-access model, or safe tenant context for
jobs, files, exports, and provider events.

Decision: Introduce `Business` as the canonical tenant aggregate. Do not adapt
Jetstream Team as the domain tenant. Business owns locations and all tenant
records. Resolve tenant context explicitly for HTTP, jobs, commands, webhooks,
files, caches, search, imports, and exports. Retire Team coupling only through a
separately approved, evidence-backed migration/cleanup slice.

Consequences: The first tenancy slice has more application-owned schema and
actions than simply enabling Team. It avoids a later migration of Team foreign
keys and personal-team assumptions after salon data exists. Jetstream/Fortify
account-security components may still be adapted independently.

Evidence or follow-up: See
`audits/2026-08-10-larafast-adoption-audit.md`. Prompt 02 approved this
direction and resolves OPEN-03. Existing Jetstream Team tables remain legacy
boilerplate data and are not silently repurposed.

### ADR-007: Business owns SaaS billing behind one provider adapter

- Status: Superseded in provider selection by ADR-021
- Date: 2026-08-11
- Owners: Product and Engineering
- Related requirements: FR-01, FR-19, FR-20

Context: The boilerplate currently makes User billable through Cashier/Stripe,
also carries Lemon Squeezy customer/subscription/order/license tables, and
exposes Paddle routes despite the Paddle package being absent. The PRD requires
one launch SaaS billing provider and reusable entitlements.

Decision: Make Business the SaaS customer, subscription, invoice, and
entitlement owner. Stripe is the single launch SaaS subscription provider and
is integrated through an application-owned `SubscriptionProvider` contract and
normalized lifecycle. Stripe Checkout, customer portal, subscription schedules,
promotion codes, invoices, payments, and signed webhooks are provider-edge
capabilities; Stripe payloads are not the domain model. Keep SaaS billing
separate from appointment deposits and checkout payments even if Stripe is
later selected for both.

Provider selection is superseded by ADR-021. The Business ownership boundary,
adapter contract, normalized lifecycle, and separation from salon-client
payments remain accepted.

Consequences: Provider-specific identifiers and payload evidence remain behind
the adapter. User-owned Cashier behavior is disabled, as are Lemon Squeezy and
Paddle runtime routes/listeners. Their legacy tables, models, resources,
commands, and installed dependencies remain quarantined rather than being
deleted without data/backfill evidence. OPEN-04 is resolved. OPEN-02 still
blocks publication of currency, prices, tax, and receipt settings.

Evidence or follow-up: See
`audits/2026-08-11-subscription-provider-audit.md`. Local contract tests cover
the installed Stripe signature verifier, renewal/failure/grace/cancellation,
deduplication, out-of-order events, invoices, payments, and replay. A live
Stripe sandbox/test-clock run remains a pre-launch requirement because no
sandbox credentials are present.

### ADR-008: Separate User, Membership, and StaffProfile authorization

- Status: Accepted
- Date: 2026-08-11
- Owners: Product and Engineering
- Related requirements: FR-05, FR-19, FR-20

Context: A login is not necessarily a schedulable staff member. Current
Jetstream membership is a pivot with a role string, while Spatie permissions
are global because team scoping is disabled. Neither represents staff history,
location assignments, invitation lifecycle, or a clean separation between
platform and business roles.

Decision: `User` authenticates. A first-class `Membership` grants a User access
to one Business and owns membership status and business role. `StaffProfile`
belongs to Business and may link to a User. Invitations are expiring,
revocable, hashed, business-bound, and may bind a StaffProfile and location
assignments. Platform roles are global and separate; business permissions are
Business-scoped and optionally Location-scoped.

Consequences: Staff may exist without login, and deactivating login/membership
does not erase historical staff attribution. Authorization must be enforced by
policies/actions and tenant-scoped queries independently of navigation.

Evidence or follow-up: Prompt 02 implements and verifies the starter-role
permission matrix. Spatie business roles and direct permissions attach to the
tenant-bound Membership, never to the global User identity. This permits a
single User to have different access in different businesses without relying
on a hidden current-team field.

### ADR-009: Separate platform administration from audited support access

- Status: Accepted
- Date: 2026-08-11
- Owners: Product, Engineering, and Operations
- Related requirements: FR-19 and FR-20

Context: Filament currently grants the entire admin panel to a global `admin`
role or a stale `is_admin` fallback. No support grant, tenant-visible banner,
reason/ticket, expiry, scoped permission, or entry/exit audit record exists.

Decision: Retain Filament as a platform-operations surface, protected by
platform-specific roles and stronger authentication. Platform role alone does
not grant ordinary tenant data access. Tenant support access uses a separate,
time-limited grant with reason/ticket, approved scope, visible banner, explicit
entry/exit, and immutable audit evidence.

Consequences: Platform resources require explicit policies. Bulk/cross-tenant
operations are separately authorized and monitored. Invisible impersonation is
not permitted.

Evidence: Prompt 02 implements separate expiring platform-role assignments and
prevents those roles from entering tenant routes. Prompt 12 implements the
distinct tenant-visible support-grant workflow and proves reason, scope,
expiry, banner, revocation, and entry/exit behavior before support entry is
accepted.

### ADR-012: Use MySQL 8/InnoDB as the production transactional baseline

- Status: Accepted
- Date: 2026-08-11
- Owners: Engineering and Operations
- Related requirements: FR-05, FR-19, FR-20

Context: OPEN-07 blocked irreversible tenancy schema work because the local
environment used MySQL but no production database or hosting topology had been
selected. Locking and constraint behavior will later be central to scheduling
and payments.

Decision: MySQL 8.0 or a wire-compatible managed MySQL service with InnoDB is
the Phase 1 transactional database baseline. Migrations use portable Laravel
schema operations where practical but production concurrency evidence must run
against MySQL. SQLite `:memory:` is allowed only for fast isolated unit and
authorization tests. Production hosting vendor, replica topology, cache, queue,
backup provider, and regional placement remain bounded operational choices;
they may not weaken tenant isolation, durable asynchronous work, RPO/RTO, or
restore testing.

Consequences: OPEN-07 no longer blocks the ownership schema. Sync queues and
file cache remain local-development facts, not accepted production topology.
Before scheduling or payment concurrency is claimed verified, MySQL integration
tests and the remaining hosting/backup choices are required.

### ADR-013: Launch authentication uses verified password identities and TOTP

- Status: Accepted
- Scoped amendment: ADR-059 removes mandatory MFA from the internal `/admin`
  panel; the separate `/platform` support policy remains in force.
- Date: 2026-08-11
- Owners: Product, Engineering, and Operations
- Related requirements: FR-05, FR-19, FR-20

Context: OPEN-08 covered unsafe boilerplate magic-link account creation,
unrestricted Socialite drivers and email linking, an unverified `User` model,
and the stronger controls required for owners and platform operators.

Decision: Phase 1 staff authentication retains Fortify/Jetstream email and
password login, password reset, email verification, browser-session management,
and TOTP two-factor authentication with recovery codes. Staff tenancy access is
created only by a business-bound invitation or an approved owner-onboarding
flow. Boilerplate magic-link and social-login routes are disabled. Platform
administration requires a verified email, confirmed TOTP, and a separate active
platform-role assignment. Sanctum remains installed for first-party session
authentication and future scoped API use, but user-created API tokens remain
disabled; any future tenant token must bind to a Business and Membership and be
revocable with that membership.

Consequences: OPEN-08 is resolved for launch. Adding a social provider,
passwordless login, or service token later requires a new decision and explicit
account-linking, verification, expiry, tenant binding, and revocation tests.

### ADR-014: Publish explicit readiness and expose one availability-configuration contract

- Status: Accepted
- Date: 2026-08-11
- Owners: Product and Engineering
- Related requirements: FR-02, FR-03, FR-04, FR-05, FR-06, FR-07

Context: A percentage can claim progress while a shop still has no deliverable
service path. Prompt 05 also needs configuration without coupling its booking
engine to onboarding controllers or raw tables.

Decision: Readiness is an ordered set of blocking facts and optional
improvements. Publishing requires a complete business/rules profile, an active
Location with hours, active scheduled Staff, an online Service with a qualified
staff/location/resource path, and a reviewed preview. Import and branding are
improvements. Availability consumers use the application-owned
`AvailabilityConfiguration` contract for local Location windows, effective
service resolution, and resource quantities. Booking search/commit remains out
of this module. Published availability-reducing changes require an expiring
Appointment impact preview and explicit resolution when affected records exist.

Consequences: Prompt 05 must bind `AppointmentImpactSource` to its Appointment
store and use the same read contract during search and commit. Resolved values
are captured as immutable snapshots, so future configuration edits cannot
rewrite historical Appointment decisions. OPEN-02 remains unresolved; country,
currency, locale, and tax posture are explicit inputs.

### ADR-015: Serialize booking capacity with deterministic InnoDB root locks

- Status: Accepted
- Date: 2026-08-11
- Owners: Engineering and Product
- Related requirements: FR-03 through FR-07

Context: Advisory search cannot prevent two online/reception requests from
selecting the same staff or pooled physical capacity. MySQL has no portable
exclusion constraint for arbitrary time-range overlap, and a unique key on an
Appointment start would neither model resource quantity nor processing
segments. Capacity Holds and idempotent replay must also share the same rule.

Decision: Use one application-owned `BookingRuleEngine` for search, Hold,
direct commit, and Hold confirmation. Writes run in a MySQL 8/InnoDB transaction
and acquire rows in this order: Business/scope command key, shared Location,
shared sorted Services, sorted explicit/eligible Staff, and sorted required
Resources. Staff/Resource roots are pessimistically locked before indexed overlap reads.
Intervals are half-open. Pooled resource claims sum overlapping quantities.
Active unexpired Holds participate exactly like Appointments; confirmation
excludes its own Hold, revalidates, writes the entire Appointment aggregate,
and marks the Hold confirmed atomically. Laravel transaction deadlock retry is
limited to five attempts.

Idempotency uses a unique command-key row plus normalized request digest. Exact
replay returns the original result. Reusing the key for different input fails.
Search never returns private schedule reasons, and write errors expose stable
safe rule codes. No manager integrity override exists in this slice.

Consequences: This is intentionally a conservative correctness-first lock
scheme. Any-qualified requests lock all eligible candidates and may serialize
popular broad services. Availability reads remain bounded and advisory; their
current repeated rule reads need a batched/cached projection before peak public
traffic. Optimization may narrow read and lock scope only if the MySQL parallel
acceptance suite continues to prove identical atomicity. Controllers,
Filament, Vue, jobs, and later drag/drop behavior must call the use-case
contracts and may not write Appointment timestamps.

Candidate-assignment and resource-requirement discovery are shared locking reads
so no consistent snapshot is established before an exclusive-root wait.

Evidence or follow-up: MySQL 8.0.42 process-level tests use independent PDO
connections behind a fork barrier for online/online, online/reception,
staff/resource, quantity, multi-segment, expiry, duplicate, and stale-search
races. The measured local 20-slot search was 210.52 ms/746 SQL statements and
direct commit was 15.53 ms/55 statements. ADR-016 defines the lifecycle and
narrow manager policy override without bypassing this boundary.

### ADR-016: Preserve schedule history with linked replacements and narrow policy overrides

- Status: Accepted
- Date: 2026-08-12
- Owners: Product, Engineering, and Operations
- Related requirements: FR-06, FR-07, FR-08, FR-19

Context: Calendar edits must be safe under concurrent front-desk use and must
not erase the schedule/commercial evidence that existed before a move, duration
change, provider change, or service change. Managers also need limited
discretion for policy warnings without gaining a way to create impossible
capacity.

Decision: Appointment lifecycle mutations require an expected version and a
Business-scoped idempotency key. Reschedule, resize, reassign, and service-list
changes create a new Appointment through the authoritative booking engine,
link it bidirectionally to the original, and make the original `rescheduled`
and terminal. Selected `NOTICE_WINDOW` and `ADVANCE_WINDOW` policy failures may
be overridden only by an authorized manager/owner after explicit warning
acknowledgement and a non-empty reason. Hours, closure, staff qualification or
availability, block, travel, Appointment overlap, and physical-resource
capacity failures cannot be overridden. Every override and lifecycle change
retains actor/source/reason/change evidence.

Consequences: Historical reporting can distinguish what was originally booked
from what replaced it; stale tabs fail safely; command retries do not duplicate
work; and a manager cannot silently manufacture capacity. Queries must treat
linked terminal records consistently, and later communications/payments must
follow the active replacement while retaining the original reference chain.

### ADR-017: Use hashed purpose links and atomic waitlist offer batches

- Status: Accepted
- Date: 2026-08-12
- Owners: Product, Engineering, Security, and Operations
- Related requirements: FR-07, FR-09, FR-10, FR-19, FR-20

Context: Passwordless clients need to manage one Appointment without an account,
but a human-readable reference is guessable and must not authorize access.
Waitlist openings may also be offered to more than one client, creating a race
that ordinary first-come application checks cannot resolve safely.

Decision: Public booking sessions and Appointment actions use cryptographically
random opaque secrets whose SHA-256 digests alone are persisted. Appointment
links bind one purpose, Appointment, Business, and UTC expiry. Mutating action
links are single-use; contact, cancellation, and replacement changes revoke
older links, and the client receives a newly issued view link. References remain
display identifiers only. Public endpoints are throttled and reject malformed,
unknown, wrong-purpose, expired, used, and revoked tokens without tenant
enumeration.

Waitlist requests use a nullable active fingerprint to converge exact duplicate
preferences while retaining completed history. A released opening may be
offered to a Business-configured small batch. Claim locks every match in that
batch in deterministic order and commits through the authoritative booking
engine; one claimant becomes booked and every sibling offer becomes lost.

Consequences: Raw links must never appear in audit metadata, logs, analytics, or
support search. Prompt 09 delivers temporary signed bridge links from revocable
action records without weakening purpose/expiry rules. Prompt 10 must coordinate deposit Holds through the same
booking session rather than adding a second token or capacity model. Offer
delivery and expiry cleanup may be asynchronous, but delayed work cannot create
capacity or revive an invalid claim.

### ADR-018: Bound destructive Client privacy work until retention policy is approved

- Status: Accepted
- Date: 2026-08-12
- Owners: Product, Engineering, Security, Privacy, and Operations
- Related requirements: FR-11, FR-12, FR-19, FR-20

Context: Prompt 08 must make export, correction, consent withdrawal, and
deletion/anonymisation requests operational. OPEN-02 does not yet select the
launch jurisdiction and OPEN-10 does not yet define record-specific retention
periods. Guessing either could destroy evidence that must be retained or keep
personal data longer than permitted. Financial and audit ledgers also cannot be
rewritten to simulate erasure.

Decision: Implement the complete tracked privacy-case lifecycle, data
classification, deadline, reviewer, export artifact, correction, withdrawal,
and retained-data preview now. Export produces a private, content-hashed,
30-day artifact and a minimized manifest. Correction uses optimistic Client
versions and rotates vulnerable Appointment links. Withdrawal appends a Consent
event and changes current marketing eligibility without rewriting history.

Deletion/anonymisation is reviewable but has no destructive executor. Until
OPEN-02 and OPEN-10 are accepted, review must set `blocked_policy`, record the
counts/classes that would be retained, state that no destructive change ran,
and preserve the Client. There is no scheduled hard-delete job, cascade path,
or UI/API bypass. Consent submissions remain immutable; financial and audit
history will remain append-only under the final policy.

Consequences: The product can intake and evidence every privacy request without
ad hoc database changes, but cannot claim that a deletion/anonymisation request
has completed. Counsel and product must approve the jurisdiction-specific
schedule, identity-verification standard, attachment treatment, export window,
and anonymisation map before a destructive executor is designed or enabled.
Prompt 13 must treat that approval and executor certification as a paid-launch
gate.

### ADR-019: Launch communications use India/en-IN, Resend email, and Twilio WhatsApp

- Status: Superseded by ADR-039 for launch region, mobile-channel, and sender-ownership direction; retained as historical implementation context
- Date: 2026-08-14
- Owners: Product, Engineering, Security, Privacy, Operations, and Support
- Related requirements: FR-13, FR-19, FR-20

Context: OPEN-06 required one approved mobile launch channel, and the
locale/consent portion of OPEN-02 had to be resolved before choosing it. The
implemented and demo configuration already uses India, `en-IN`, INR, E.164
Indian mobile numbers, and `Asia/Kolkata`; a mobile provider must also support
approved business-initiated templates, explicit channel opt-in, delivery
callbacks, stable provider identifiers, and safe failure handling. The
repository already includes Resend support for email.

Decision: The communications launch profile is India with `en-IN` as the safe
template fallback locale. Location IANA time zones continue to govern
appointment and reminder wall time, so this decision does not hard-code
`Asia/Kolkata` into delivery calculations. Email uses Resend and the approved
mobile channel is WhatsApp through Twilio Programmable Messaging, both behind
separate application-owned contracts. WhatsApp templates cannot be published
until their Twilio Content SID reports `approved`; SMS, browser push, and in-app
delivery remain contract-compatible later channels, not launch surfaces.
Twilio's standard Messages create API has no documented provider-idempotency
input. Application uniqueness and send locking prevent duplicate creates; only
a definite 429 rejection is automatically retried. Ambiguous WhatsApp
transport/5xx or missing-SID outcomes are terminal until provider reconciliation,
so the application never claims an unsupported provider guarantee.

Transactional appointment, queue, waitlist, deposit, and receipt messages are
recorded with contract performance, user-requested service, or legal-obligation
basis as applicable; this never grants marketing permission. Marketing requires
an active explicit marketing consent, the selected channel preference, no
active suppression, and an unsubscribe path. WhatsApp additionally requires an
explicit channel opt-in for every outbound category. Selecting WhatsApp for a
specific waitlist request is retained as request-scoped opt-in evidence; linked
Clients receive append-only WhatsApp consent evidence. Consent and suppression
are rechecked immediately before delivery, not only when queued.

Consequences: OPEN-06 is resolved. The locale/mobile-format/communication-
consent portion of OPEN-02 is resolved for implementation. India-specific tax,
receipt wording, broader privacy obligations, and final retention execution
still require counsel/accounting approval through the launch checklist and
OPEN-10; this ADR is not legal advice. Production sending remains disabled
until Resend domain authentication, Twilio WhatsApp sender onboarding, approved
Content SIDs, callback secrets, and the OPEN-11 sender-identity controls pass.
Content-free diagnostics and safe replay remain tenant-authorized settings
operations. A platform role does not bypass Business ownership; support staff
must wait for the distinct ADR-009 grant before using those tenant surfaces.

### ADR-020: India commerce profile and compliant appointment-payment boundary

- Status: Superseded by ADR-039 for target-market direction; retained as the currently implemented legacy commerce profile pending regionalisation
- Date: 2026-08-15
- Owners: Product, Engineering, Finance, Operations
- Related requirements: FR-14, FR-15, FR-18, FR-19

Context: OPEN-02 left tax, receipt, and launch-market behavior unspecified;
OPEN-05 left appointment deposits and local tenders without a gateway. A request
to use Paddle for every payment surface conflicts with Paddle's public
merchant-of-record positioning for SaaS and digital products, while salon
services and retail are local, physical commerce.

Decision: India, INR, and `en-IN` are the commerce implementation profile.
Each business owns an explicit tax-inclusive/exclusive flag and tax rate; the
safe default rate is zero, so the system never silently asserts GST liability.
Receipts show the tenant identity, currency, line values, tax, deposit applied,
payments, and immutable issue time. Stripe is the launch appointment-card
adapter behind `AppointmentPaymentProvider`; cash, card, UPI, bank transfer,
payment link, custom, and pay-later are normalized tender methods. Paddle is
not used for salon-client deposits, checkout, retail, refunds, or cash close.
The SaaS-subscription provider remains separate from appointment payments.
ADR-021 records the subsequent, independently implemented Paddle provider,
entitlement, invoice, webhook, backfill, and contractual boundary.

Consequences: OPEN-02 and OPEN-05 are resolved as product/engineering choices.
Legal/accounting confirmation of a specific shop's GST registration, tax rate,
receipt wording, provider account approval, UPI/acquirer setup, and live
webhook certification are release controls, not open implementation choices.
Paddle API credentials supplied outside a secret manager must be rotated and
must not be committed.

Evidence or follow-up: `MoneyCommerceTest` proves calculation, deposit/split
tender/reconciliation, duplicate and out-of-order event handling, receipt
reproduction, and cash variance locally. Before live collection, run Stripe
test-mode Payment Intent/refund/webhook tests with the configured endpoint,
reconcile a provider settlement, and have Indian counsel/accounting approve the
tenant receipt and tax profile.

### ADR-021: Paddle is the Good Hours SaaS subscription provider

- Status: Superseded by ADR-029
- Date: 2026-08-15
- Owners: Product and Engineering
- Related requirements: FR-01, FR-19, FR-20

Context: Good Hours earns its platform revenue through salon subscriptions.
The former Stripe launch choice did not use the provided Paddle sandbox
configuration, and no Paddle price IDs had been linked to the billing catalog.

Decision: Paddle Billing is the selectable provider for Good Hours business
subscriptions only. The application keeps its Business-owned subscription,
entitlement, invoice, payment and immutable provider-event model, while the
Paddle adapter creates subscription checkout transactions and consumes
signed, deduplicated, ordering-safe webhook events. Salon-to-client deposits,
retail and appointment checkout remain manual/local tender records until a
separate customer-payment provider is approved.

Consequences: `BILLING_PROVIDER=paddle` selects the Paddle adapter when the
Paddle API key is configured. A real Paddle `pri_…` ID must be attached to each
monthly and annual `billing_plan_prices` row before a price can be shown. The
Paddle notification-destination signing secret is required as
`PADDLE_WEBHOOK_SECRET`; an API key, client-side token, Retain key, or old
Cashier webhook setting is not a valid webhook secret. Existing Stripe evidence
is retained and is never deleted.

Operational check: `PADDLE_API_KEY` must contain a valid Sandbox API key—not
the tracked `your-paddle-api-key` placeholder—and configuration cache must be
cleared after it changes. The app never exposes Paddle's raw provider error to
a salon owner: it records the status for support and returns a safe retryable
checkout message beside the selected plan.
Every configured `pri_…` ID must be retrievable by that same Paddle account in
the configured environment. Sandbox and Live catalogs are isolated; a Sandbox
API key cannot use a Live price ID (or one from another Sandbox account). The
adapter verifies the price before it creates a Paddle customer.

Checkout presentation: Good Hours uses Paddle.js inline checkout inside a
dedicated application-owned review page. The owner remains on the Good Hours
page; no overlay/popup or hosted payment-page redirect is used. Paddle's frame
continues to collect card, billing, tax, and payment data so Good Hours does not
handle card data. Browser completion is only progress feedback; paid access
requires either a signed Paddle webhook or an authenticated server-to-server
Paddle API confirmation of the stored checkout attempt. API confirmation must
match the transaction, customer, Business public ID, application marker, local
price, currency, and active provider subscription; a browser event alone can
never activate access. The eventual signed webhook remains idempotent after API
recovery and must not duplicate invoices or payments.

Lifecycle presentation: billing-capable owners see the current plan and status
in the application header. A Starter-to-Pro upgrade (and monthly-to-annual
change) is confirmed in-app, sent to Paddle with immediate proration, and
audited. Same-interval downgrades retain current access and are recorded for the
renewal boundary; an annual-to-monthly change is not silently applied mid-term.
Cancellation defaults to the end of the paid period, states the exact access
date, preserves records/export recovery, and requires consequence-first
confirmation. Undoing a scheduled Paddle cancellation clears
`scheduled_change`; Paddle's paused-subscription resume endpoint is not used.

Shared-account boundary: one Paddle account may contain more than one SaaS
catalog. Every Good Hours customer and transaction includes
`application=good_hours` plus the Business public ID. Webhooks explicitly
marked for another application are acknowledged and discarded before storage,
preventing the second SaaS's customer payloads from entering Good Hours logs or
provider-event records. Good Hours retains distinct products/prices and does
not infer application ownership from the shared seller account.

Paddle's seller legal/display identity is account-wide, not a per-product
Paddle.js setting. Consequently, the seller name, marketing-consent copy, and
checkout footer cannot be changed from QRxpress to Stylnexa for Good Hours in
application code without affecting the other SaaS in the same Paddle account.
The shared account must use an approved neutral seller identity such as
Stylnexa, or Good Hours must use a separate Paddle seller account. Product and
Engineering may not hide or rewrite Paddle's hosted compliance footer.

Domain posture: sandbox checkout may run before a public domain is purchased;
Paddle does not require sandbox website approval. Live checkout remains blocked
until the eventual production domain/default payment link is approved and live
credentials/catalog mappings are separately certified.

Configured catalog: Product approved a two-plan Paddle sandbox catalog on
2026-08-15. Starter is USD 50/month or USD 500/year with one location and two
staff. Pro is USD 100/month or USD 1,000/year with three locations, twenty
staff, 1,000 included messages, and the currently implemented paid
capabilities. These are entitlement values, not plan-name conditionals; a later
commercial change must create a new effective-dated entitlement record rather
than rewrite subscription history.

Catalog operation: the versioned `billing:sync-paddle-catalog` command is the
only approved catalog writer. It previews by default and requires `--apply` to
write Paddle or local mappings. Its central catalog is two products (Starter
and Pro) with monthly and annual prices. A re-run refreshes product and
non-financial price metadata; changing an amount creates a new Paddle price,
ends the previous local mapping, and preserves the old provider price and all
historical subscription evidence. The command must run against the same
Sandbox or Live account that will serve checkout.

### ADR-029: Stripe is the sole ClipperDesk SaaS subscription provider

- Status: Accepted
- Date: 2026-08-29
- Owners: Product and Engineering
- Related requirements: FR-01, FR-19, FR-20

Context: ClipperDesk requires Business-owned billing for a multi-user salon,
while the inherited LaraFast/Cashier schema is User-owned. ADR-021 selected
Paddle at the provider edge, but Product has now directed a complete move to
Stripe and removal of the Paddle runtime.

Decision: Stripe is the only selectable provider for new ClipperDesk SaaS
subscriptions. The existing application-owned `BusinessSubscription`, invoice,
payment, checkout-attempt, provider-event and entitlement aggregates remain the
authoritative local domain. The Stripe SDK/Cashier dependency supplies the
provider primitives, but the inherited User-owned Cashier tables and routes do
not own salon access. Checkout uses Stripe-hosted Checkout, payment method and
invoice management use the Stripe Customer Portal, and signed Stripe webhooks
are the authority for paid state.

The approved catalog is centralized in `config/billing.php`; checkout and plan
changes require an active command-managed local mapping that matches the plan
code, interval, amount and currency. `billing:sync-stripe-catalog` previews by
default. `--apply` verifies explicitly configured Price IDs without remote
mutation. `--provision` follows LaraFast's product/price command workflow but
targets the Business-owned catalog: it manages Stripe objects with stable
lookup keys and metadata, creates immutable replacements for amount changes,
commits effective-dated local mappings, and only then archives prior managed
Prices. Live-mode mutations require `--force`. Browser redirects never activate
access.

Business plan entitlements and Membership permissions remain independent and
both must pass. Trial expiry and exhausted dunning move the account to a
read-only state while billing, profile, data viewing and eligible exports remain
available. Downgrades that exceed a numeric limit never delete resources; they
are scheduled and retain a usage/limit snapshot for remediation.

Consequences: Paddle routes, handlers, provider adapter, frontend components,
catalog command and JavaScript package are removed. Historical Paddle rows and
already-applied migrations are retained as financial evidence. Any Business
with a paid Paddle external ID requires an explicit migration/reconciliation
runbook; only clean trials without external IDs are automatically relabeled.
Live launch requires a provisioned or explicitly mapped Stripe catalog and
webhook secret, verified catalog sync, webhook delivery/replay evidence,
Customer Portal configuration, and Finance/Legal ownership of taxes, refunds
and customer communications.

### ADR-030: Resolve workspace access from one membership, billing, and location decision

- Status: Accepted
- Date: 2026-08-30
- Owners: Product, Engineering, Security, and Operations
- Related requirements: FR-01 through FR-08, FR-14, FR-16, FR-18, and FR-19

Context: A successfully paid owner could see Calendar, Walk-in Queue and Reports
in navigation but receive a raw 403 or missing-report-location error. Owner
onboarding had not created a default Location, a completed Stripe Checkout had
not reached the local projection because webhook verification was unconfigured,
and navigation did not consume the backend's permission and entitlement state.

Decision: Verified owner onboarding must idempotently create or reuse one active
default Location and assign the Owner Membership. Existing Businesses receive a
forward-only corrective backfill without deleting or merging tenant data.
Authenticated feature entry and navigation consume `WorkspaceAccessService`,
which evaluates Membership permission, capability entitlement, and accessible
Location as separate gates. Role-denied entries are hidden; plan and setup gates
remain explainable. Expected denials render a product-owned unavailable state
with the appropriate status code instead of raw framework output.

Signed Stripe webhooks remain the primary external state authority. A stored,
tenant-owned pending Checkout Session may be recovered from authenticated
Stripe API evidence in the status endpoint or scheduled reconciler. Browser
parameters never supply provider status or identifiers. New Checkout fails
closed when the Stripe server credential or subscription webhook signing secret
is absent.

Consequences: Plan entitlements never grant a user role, owner role never
bypasses plan state, and a Location belonging to the Business does not grant an
unassigned employee Location access. Configuration completes the provisioned
Location rather than exceeding plan limits with a duplicate. Operators can
recover a dropped webhook without direct database edits, while deployed and
local environments must still configure and certify signed webhook delivery.

### ADR-031: Treat Salon setup and regional context as shared operating data

- Status: Accepted
- Date: 2026-08-30
- Owners: Product, Design, Engineering, Finance, and Operations
- Related requirements: FR-02 through FR-05, FR-11, FR-14, FR-15, and FR-19

Context: The inherited Settings form mixed Business identity, booking policy,
Staff, Availability, and launch status in one surface. A small hard-coded
country list and repeated raw phone inputs made regional behavior inconsistent.
Currency and tax posture could be stored without reliably updating the commerce
defaults that use them.

Decision: The owner-facing surface is **Salon setup**, a guided view of connected
operating configuration rather than a generic settings dump. It groups Business
details, bookable foundation, booking experience, import, and preview under an
explicit readiness overview. Readiness names required blockers and optional
improvements; it does not claim a vague percentage. Staff and Availability
remain owned by their dedicated workflows and are summarized, not duplicated.

Business country is the defaulting context for phone country, suggested
currency, locale, time zones, and address expectations. `CountryCatalog`
provides the complete ISO country set and derived suggestions; those suggestions
remain editable and are validated server-side. Phone values use one E.164
contract across staff-assisted and public workflows. Business currency and tax
posture synchronize transactionally to commerce currency, tax inclusivity, and
default tax rate. Historical monetary records retain their captured currencies;
an owner cannot casually change Business currency after services or appointments
exist.

Consequences: Regional choices affect booking display, checkout, inventory,
communications locale, phone entry, and future invoice/receipt adapters through
shared Business or commerce state. They are not legal or tax determinations.
Launch-market accounting, address, invoicing, privacy, and receipt rules still
require accountable review. New regional adapters must consume the shared state
instead of introducing new country or currency constants.

### ADR-022: Project inventory, payroll inputs, and reports from completed commerce events

- Status: Accepted
- Date: 2026-08-15
- Owners: Product, Engineering, Finance, and Operations
- Related requirements: FR-16, FR-17, FR-18, FR-19

Context: Inventory, commission, dashboard, and export totals can disagree if
each feature owns an editable copy of Sale value. Multi-Location permission and
local-day rules also make a global stock/report cache unsafe. Refunds require a
durable physical-product outcome, while Tip offsets need one predictable Phase
1 policy.

Decision: A Sale becomes the projection trigger only when its final tender
commits `completed`; the same transaction creates deterministic inventory,
commission, Tip, usage, and report-visible effects. Product quantity is held at
Location level with a cross-Location Product aggregate. Sale completion deducts
each inventory-backed line once. Product refunds/voids require a retained
`restock`, `write_off`, or `customer_keeps` disposition. Commission rules are
immutable/effective-dated; the most-specific Staff/Service and latest effective
rule wins, with fixed Service ahead of Service percentage at equal specificity.
Commission uses the discounted line value. Refund commission offsets follow
the affected line; Tip offsets are proportional to refund divided by completed
Sale total and capped by earned Tip.

Metric definitions live in one versioned executable catalog. Reports query
completed Sale/Payment evidence (plus explicitly filtered open Sales for
expected/outstanding work), return source IDs/drills, and use the governing
Location time zone. A report spanning different Location time zones must run
per Location. Core exports always queue with Business, Membership, normalized
filter, and scope snapshots, then re-authorize before producing a private,
hashed artifact. Instrumentation is allow-listed and idempotent; only approved
segmentation dimensions and optional HMAC subject hashes are stored.

Consequences: Current totals remain explainable without rewriting prior
evidence, and permission scope is shared by screens, print, and CSV. Phase 1
does not implement procurement, purchase orders, suppliers, payroll execution,
or a warehouse transfer workflow. The proportional Tip-offset rule must remain
visible on statements; changing it requires a new effective metric/commission
version rather than rewriting entries.

Evidence: `InventoryCommissionReportingTest` passes on SQLite and MySQL 8,
including exact replay, dispositions, effective rule change, discount/refund
effects, local-midnight boundary, role/cross-tenant exports, filter/drill/CSV/
print reconciliation, all catalog keys, and a 2,000-Sale/8-query local
benchmark.

### ADR-023: Separate safe platform summaries from scoped support sessions

- Status: Accepted
- Scoped amendment: ADR-059 removes mandatory MFA from the internal `/admin`
  panel; support-workspace MFA, session limits and authorization remain in force.
- Date: 2026-08-15
- Owners: Product, Engineering, Security, and Operations
- Related requirements: FR-19 and FR-20

Context: ADR-009 required attributable support access but left approval,
session, scope, export, replay, and alert mechanics to Prompt 12. The retained
Larafast Filament User/Role editors could also expose or mutate authentication
and legacy authorization data outside the approved tenant model.

Decision: Platform administration uses three application roles with an
explicit capability matrix. Every role requires verified email, confirmed
TOTP, and 15-minute idle/eight-hour absolute platform sessions. Cross-tenant
search returns only safe account/commerce/volume summaries. Tenant support
requires approval by a different platform administrator, one Business, ticket,
reason, explicit enumerated scopes, and expiry within four hours. Entry never
changes identity and is accepted only by separate support endpoints. Tenant
shop routes continue to require Membership. Active entry is tenant-visible.

Safe replay is allow-listed by application-owned processor, reasoned, and
deduplicated in a replay ledger. Generic failed jobs remain inspection-only.
Platform export initiation is administrator-only and single-Business; bulk
input is rejected and alerted. Rapid access to three Businesses in fifteen
minutes is also alerted. Legacy Filament identity, role, permission, billing,
price, product, and discovered widget surfaces are quarantined rather than
reused.

Consequences: Support can resolve representative notification and provider
failures without SQL edits while operator identity and tenant lineage remain
visible. Dual approval adds operational friction by design. Backup health stays
explicitly `not_configured` until a production adapter and restore evidence
exist. New replay types, grant scopes, or bulk operations require a reviewed
adapter/capability and new isolation/idempotency evidence.

Evidence: `PlatformOperationsTest` covers role/MFA/session separation, safe
summaries, scoped/expired/revoked grants, tenant banner, identifier denial,
bulk-export alerting, immutable audit/notes, duplicate replay, provider
recovery, rapid cross-tenant alerts, and Filament quarantine.

### ADR-024: Separate the curated acquisition site from tenant booking and private tasks

- Status: Accepted
- Date: 2026-08-16
- Owners: Product, Design, Engineering, Security, and Privacy
- Related requirements: PRD Sections 3, 4, 12, 15, and 17; FR-01, FR-09, FR-10, FR-19

Context: The public root remained a generic Larafast starter page. Its global
navigation mixed unsupported marketing, roadmap, newsletter, blog and test
surfaces with valid account and tenant-booking routes. The dynamic sitemap
crawler had no durable distinction between acquisition pages, tenant booking,
secure token actions, authentication, administration and utilities.

Decision: Phase 1.5 uses one curated acquisition information architecture and
an explicit indexable route registry. Marketing pages are stable, SSR-readable
and eligible for sitemap inclusion only after their content, claims, metadata,
links and owner pass review. Tenant booking is a distinct task family under
`/book/{slug}` and is never part of marketing navigation or sitemap. Secure
appointment, waitlist, form, file and communication URLs plus authentication,
application, platform, admin, webhook and utility routes are non-indexable.

The global anonymous primary action is **Start your trial** and points to the
real owner registration flow. Authenticated visitors receive **Open dashboard**.
No demo, contact, newsletter, social, integration, testimonial or customer
logo surface is published without an owned workflow and evidence. The detailed
route/indexation/claim contract is in `docs/frontsite/`.

Consequences: Prompts 15–27 may replace visible boilerplate and implement the
approved page set without treating OPEN-09 as permission to delete unknown
legacy data. Canonicals and schema use the configured application origin until
OPEN-11 is resolved. Legal pages remain noindex placeholders until named
counsel/DPO approval; provider, security, accessibility and operational gaps
remain launch blockers even when local front-site checks pass.

Evidence: `audits/2026-08-16-frontsite-discovery-seo-audit.md`,
`frontsite/README.md`, and `frontsite/content-and-claims.md`.

### ADR-025: Launch one reviewed `en-IN` public experience before locale expansion

- Status: Superseded by ADR-039 for target-market direction; retained as the currently implemented public-site profile pending regionalisation
- Date: 2026-08-16
- Owners: Product, Engineering, Design, Privacy, and Legal
- Related requirements: PRD Sections 13, 15, and 17

Decision: Phase 1.5 declares one English-for-India public experience as
`en-IN`, with server-owned USD subscription prices under ADR-021 and
jurisdiction-qualified legal/provider content. It publishes no locale selector,
country routes, `hreflang` or global-availability claim. A second locale must
have equivalent reviewed content, commercial/legal/provider approval and
reciprocal path-prefixed metadata before it can be indexed.

Consequences: application message lookup remains `en`; public display uses
locale-aware browser formatting. Missing content never machine-translates or
falls back to an unrelated homepage. Entity IDs remain stable, while offer
currency, language and availability must match visible regional content.

### ADR-026: Separate front-site technical readiness from production launch authority

- Status: Accepted
- Date: 2026-08-16
- Owners: Product, Engineering, Design, Security, Privacy, Legal, Finance, and Operations
- Related requirements: PRD Sections 12, 13, 15, and 17; FR-01, FR-19, FR-20

Decision: Prompts 14–27 satisfy the local Phase 1.5 technical gate for a
controlled staging review: the curated public routes, claims, registration
preference, publication safety, crawl/indexation, structured data, internal
links, accessibility foundations, build budgets, and regression suite pass.
This is not authority to expose the site for production acquisition or permit
search indexing. Production public launch remains NO-GO until OPEN-10,
OPEN-11, and the applicable legal, provider, security, operations,
accessibility/browser, and target-load evidence in the Prompt 27 audit close.
The overall product remains NO-GO under Prompt 13.

Consequences: Staging must remain access-controlled or otherwise non-publicly
indexable while named owners review it. No team may reinterpret a local build,
test, crawl, budget, or Chromium screenshot as counsel approval, domain
ownership, provider certification, independent WCAG/security assurance,
production reliability, or field-performance evidence. The final gate and
owner/evidence matrix are in
`docs/audits/2026-08-16-frontsite-final-launch-audit.md`.

### ADR-027: Adopt ClipperDesk and one semantic enterprise design system

- Status: Accepted
- Date: 2026-08-25
- Owners: Product, Design, and Engineering
- Related requirements: PRD Sections 3, 4, 10, and 12; FR-01 through FR-20
- Supersedes: ADR-011 for current product identity, palette, typography, assets,
  domain direction, and message identity

Context: The product has been renamed from Good Hours to ClipperDesk. The prior
cream, pine, poppy, and editorial-serif identity no longer represents the
desired operational, premium SaaS position. The repository already had a useful
semantic CSS layer, but the implementation still mixed legacy palette utilities,
duplicated Jetstream controls, component-local colors, and repeated brand copy.

Decision: The current product name is **ClipperDesk** and the brand promise is
**Run the day. Grow the business.** The approved identity uses deep navy for
trust and structure, indigo for primary action, restrained cyan for recognition,
cool gray canvases, white working surfaces, and Manrope throughout. The mark is
a restrained interlocking C/D monogram without a heavy enclosing app tile. It
communicates software identity without generic salon clip art.

`config/brand.php` is the server-side source of truth for product/company names,
description, asset paths, public URLs, support identity, and the small public
palette projection. `resources/css/app.css` is the source of truth for semantic
color, typography, spacing, radius, elevation, focus, status, navigation, and
control tokens. Vue, Blade, Filament, PDFs, email, and SEO adapters consume those
sources rather than defining an independent theme.

Historical database columns, integration metadata, event identities, schema
versions, migration history, cache keys, and durable provider contracts that
contain `good_hours` or equivalent values are compatibility identifiers, not
visible brand. They remain stable unless a separately reviewed migration or
provider transition requires a change. Visible billing plan display names are
migrated with an exact-match, forward-only data migration so financial history
and external provider identifiers are not rewritten.

Consequences: Public acquisition, authentication, public booking, tenant work,
platform administration, billing, generated documents, email, browser metadata,
and icons share one ClipperDesk identity while retaining layouts appropriate to
their jobs. Production domain ownership, trademark clearance, sender
authentication, and formal legal operator approval remain external launch gates;
the configurable local defaults are not evidence those gates are closed.

Evidence or follow-up: The normative token and component rules are in
`docs/design-system.md`. The implementation and residual-identifier audit are in
`docs/audits/2026-08-25-clipperdesk-design-system-rebrand.md`; browser evidence
is stored under `docs/evidence/product-shell/`.

### ADR-028: Permit one verified, stateful Google authentication path

- Status: Accepted
- Date: 2026-08-25
- Owners: Product, Engineering, and Security
- Related requirements: FR-01, FR-05, FR-19, and FR-20
- Supersedes: ADR-013 only for the reviewed Google authentication path; magic
  links, generic Socialite drivers, and every other social provider remain disabled

Context: ClipperDesk needs lower-friction owner signup and returning-user access,
but the Larafast Socialite controller accepted an arbitrary provider, linked by
unverified email, created incomplete accounts, and retained provider access
tokens. A Google identity also cannot supply the Business name and legal
acceptance required by the approved owner-onboarding flow.

Decision: ClipperDesk exposes explicit, guest-only, rate-limited Google redirect,
callback, and signup-completion routes. Socialite remains stateful so its OAuth
state is validated. The callback accepts only a non-empty Google subject and a
Google-asserted verified email. An existing provider subject authenticates its
linked User; an unlinked subject may attach to an exact normalized email only
when that User has no different Google identity. Database constraints enforce
one User per provider and one User per provider subject. ClipperDesk stores the
provider subject but no OAuth access or refresh token.

A new identity receives a server-side, ten-minute registration continuation.
Only display name and verified email are shared with the page; provider subject
and selection evidence remain in the session. The owner must still provide a
Business name and accept the current terms. Completion creates the User,
registration intent, provider link, verified-email evidence, Business, Owner
Membership, and trial through the existing idempotent onboarding path. The
account receives an unguessable local password so the existing verified-email
password-reset path remains an independent recovery option. Google sign-in does
not bypass an already configured Fortify TOTP challenge.

Consequences: Google can be used for both sign-in and owner signup without
reintroducing generic drivers, silent tenant creation, provider-token retention,
or a two-factor bypass. A Google account already linked to another local identity
is rejected with a recovery-safe message. Provider-console consent-screen,
redirect-domain, key-rotation, outage, and production security review remain
operational launch responsibilities; enabled local credentials are not evidence
those controls are complete.

Evidence: `GoogleAuthenticationTest` covers the explicit redirect, existing
identity linking, token minimisation, verified-email enforcement, short owner
completion, exactly-once tenant bootstrap, conflicting-link rejection, and TOTP
challenge preservation. `TenantIsolationTest` proves generic Socialite and
magic-link route names remain absent while the three reviewed Google routes exist.

### ADR-032: Treat business activation as one guided journey across canonical workspaces

- Status: Accepted
- Date: 2026-08-31
- Owners: Product, Design, Engineering, Security, and Operations
- Related requirements: FR-02, FR-03, FR-04, FR-05, FR-06, FR-09, and ADR-014

Context: The configuration domain could already atomically create a complete
first bookable path, but its UI combined Location, hours, provider, availability,
Service, price, and capacity into one oversized form. The main Staff and Services
navigation still opened placeholders. This made onboarding appear complete in
the backend while the durable operating workspaces were unavailable.

Decision: Salon setup is the resumable launch task centre; Location, Team &
availability, and Services are canonical focused workspaces used both during
activation and after launch. Their write orchestration lives in one
`BusinessActivationManager` so retries, row locking, tenant validation,
entitlement limits, onboarding progress, and audit evidence remain consistent.
StaffProfile represents a schedulable provider independently from login-bearing
Membership. ReadinessEvaluator remains the only publish authority, and public
booking remains the only evidence that the assembled delivery path is usable.

The legacy all-in-one endpoint is retained as a compatibility bridge, not linked
from the owner experience. Service edits update reusable segment identities
rather than deleting rows referenced by historical appointments. Archive is a
status change and never deletes financial or booking history.

Consequences: A solo owner moves through a calm sequence and continues managing
the same records in the same workspaces after launch. New service/team/location
features must extend these domain contracts rather than reintroduce forms under
Settings. Bulk operations, templates, sophisticated schedule exceptions and
provider invitations remain separate follow-up increments and must preserve the
same tenant, impact-preview, and history rules.

Evidence: `BusinessActivationJourneyTest` proves the focused HTTP journey,
idempotent retries, tenant/role isolation, readiness/publish, real slot search,
hold, confirmation, Appointment creation, and Client creation.

### ADR-033: Use a visual, industry-led acquisition system without expanding clinical scope

- Status: Accepted
- Date: 2026-09-11
- Owners: Product, Design, Engineering, Security, and Privacy
- Related requirements: PRD Sections 1-4, FR-01 through FR-19, ADR-024, and ADR-027

Context: The verified public site accurately described the operating system but
presented it with abstract software diagrams and only four industry pages. The
result read as an enterprise software specification rather than an aspirational
brand for owner-operated service businesses. The approved Phase 1 capability
model already supports configurable services, staff, rooms, stations,
equipment, forms, booking, client context, checkout, and reporting across
several appointment-led operating patterns. Some adjacent audiences, however,
also have regulated clinical, health, age, consent, or animal-record needs that
ClipperDesk does not implement.

Decision: The public acquisition identity uses the promise **Your whole day.
Beautifully run.**, an editorial photography-led visual system, and distinct
indexable pages for barbershops, salons, independent stylists, spa and sauna,
nail salons, medspas, massage, fitness and recovery, physical therapy, health
practices, tattooing and piercing, pet grooming, and tanning studios. Each page
must describe a genuinely distinct scheduling, capacity, client-service, or
commercial operating pattern; it may reuse the common product capability set
but may not imply a vertical-specific module, customer relationship, guaranteed
outcome, certification, or regulatory approval.

Umbrella acquisition pages define ClipperDesk as appointment scheduling and
service-business management software for appointment-led beauty, wellness,
personal-care, fitness, recovery, health and pet-service teams. Salon and barber
language remains valid on their dedicated industry pages and as representative
examples, but must not present those two industries as the product's only
market. Search titles, descriptions, visible answers, image descriptions and
structured data must stay aligned with that broader, evidence-backed position.

Medspa, physical-therapy, health-practice, massage, tanning, tattoo/piercing,
and pet-grooming pages must state the relevant boundary. ClipperDesk is not an
EMR/EHR, clinical chart, diagnosis, prescribing, insurance, veterinary, or
healthcare-compliance product. Local licensing, consent, age, exposure,
retention, and care obligations remain the Business's independently reviewed
responsibility. Publishing these acquisition pages does not promote deferred
clinical, classes, memberships, marketplace, campaign, or medical-compliance
capabilities into Phase 1.

Consequences: ADR-024's curated solution set is expanded, while its
indexability, canonical, SSR, sitemap, claim-evidence, and conversion rules stay
in force. Realistic generated editorial imagery may represent an industry, but
alt text and nearby copy must not imply that the people or premises are actual
ClipperDesk customers. Product scope remains the shared booking-to-checkout
operating system; regulated vertical fit is explicitly non-clinical.

### ADR-034: Use a focused Stripe-hosted confirmation for owner plan changes

- **Status:** Accepted on 2026-09-13.
- **Context:** The former owner flow sent an immediate Subscription update with
  `pending_if_incomplete`, created local pending state first, and returned only
  a processing message. A card decline or required customer authentication had
  no completion surface, leaving the account displaying “Change pending.”
- **Decision:** ClipperDesk remains the plan-selection and entitlement policy
  boundary, but owner upgrades and interval switches finish in Stripe's focused
  Customer Portal `subscription_update_confirm` flow. Stripe previews and
  applies proration, handles authentication/payment failure, and redirects back
  only after completion. Signed webhooks remain authoritative, with an
  authenticated provider snapshot as the delayed-webhook recovery path. Owner
  self-service does not expose or accept lower-plan changes. Support retains the
  existing audited period-end downgrade capability required by the PRD.
- **Consequences:** No local access state changes before provider confirmation;
  annual-to-monthly switches preserve the paid term; duplicate clicks reuse an
  idempotent Portal session; generic billing management cannot become a hidden
  downgrade path; and Stripe credentials need Billing Portal configuration and
  session permissions in addition to Subscription/Product/Price access.

### ADR-035: Prepare new businesses from four reviewed decisions

- **Status:** Accepted on 2026-09-13.
- **2026-10-05 clarification:** ADR-053 supersedes the implicit preview/publication behavior below. Starter preparation now stays private until explicit owner review and go-live.
- **Owners:** Product, Design, Engineering, Security, and Privacy.
- **Related requirements:** FR-02 through FR-05, FR-09, ADR-030, ADR-032, and
  ADR-033.

Context: The canonical Location, Staff, Service, readiness and booking models
were already strong, but the first owner experience exposed their configuration
as work. New trial users could enter an empty product or face a large setup
form before experiencing a calendar or client booking page. “Salon setup” also
misrepresented the wider appointment-led business scope accepted in ADR-033.

Decision: New onboarding sessions use schema version 2 and collect four small,
resumable groups: business type, operating shape, first-location region and
starter services. Confirming those recommendations invokes one retry-safe,
audited provisioner that writes only to the existing Business, CommerceSetting,
Location, LocationHour, Membership, StaffProfile, StaffAvailabilityRule,
ServiceCategory, Service, ServiceSegment and assignment models. Generated
records and defaults are ordinary editable records, not a second configuration
system. ReadinessEvaluator remains the only publish authority.

The public owner surface is named Business setup. Setup state remains available
through a lightweight header drawer that separates essentials from recommended
refinements. If the reviewed starter workspace is valid, onboarding records the
preview and publishes it immediately so the completion state can show a live
booking page and calendar. If the owner is not bookable or another blocker
remains, the workspace stays usable and the drawer presents the next task.

Existing onboarding sessions are backfilled as guided-complete and receive no
starter data, configuration overwrite or automatic publish. Brand images remain
private tenant files and are exposed publicly only through an active, published
booking slug. An industry image is a labeled fallback, never evidence that a
pictured business or person is a ClipperDesk customer.

Consequences: Trial time-to-value becomes a prepared workspace instead of an
administrative checklist; owners can still change type, services, hours, team,
booking URL, policies and branding afterward. New business profiles remain
config-driven until a future scale decision justifies relational taxonomy.
Multi-location expansion, invitations, payments and advanced preferences stay
progressive tasks and continue to enforce their existing authorization and plan
limits.

Evidence: `GuidedOnboardingExperienceTest` covers persistence, generated
records, slug uniqueness, publishability, retry idempotency, regional validation,
tenant isolation, backward compatibility and private public-media delivery. The
2026-09-13 combined UX/accessibility audit captures the workspace entry,
readiness drawer, guided decisions and public booking entry.

### ADR-036: Keep front-desk work canonical, progressive and locally timed

- **Status:** Accepted on 2026-09-13.
- **Owners:** Product, Design, Engineering, Security, Privacy and Operations.
- **Related requirements:** FR-02 through FR-08 and FR-11 through FR-18.

Context: The underlying Appointment, Client, Location, Sale, communication and
reporting domains were already capable, but several owner/front-desk surfaces
made those capabilities hard to discover. Calendar views repeated one layout,
time placement was not proportional, actions looked fragmented, walk-ins could
remain detached from CRM, checkout exposed an implementation-oriented surface,
and report navigation advertised inventory records before the corresponding
user workflow was ready.

Decision: Calendar navigation exposes Day, Week and Team as separate models,
with Today as a date shortcut. All render from the Location's time zone on a
continuous proportional grid; simultaneous visits receive deterministic visual
lanes. Appointment mutation continues through the existing append-only
replacement and lifecycle services. Cancelled appointments and superseded
versions are excluded from the default active view but remain queryable through
explicit status filters and history.

A walk-in must reference an existing tenant Client or create one as part of the
same queue-entry transaction. Location setup creates separate canonical
Location rows only within the entitlement allowance. Suggested team titles are
editable descriptive vocabulary and never replace Membership roles or
permissions.

The current checkout UI records only money received externally and does not
imply card or online payment processing. It opens/reuses the canonical Sale,
records an idempotent full-balance tender, issues the existing receipt, queues a
transactional receipt email and drives the same reporting sources. Reports are
shown only when their source workflow is part of the visible product; inventory
report keys remain implemented internally but are hidden for this release.

Transactional appointment and receipt email is on when an email destination
exists unless the Appointment or Client has explicitly disabled email.
WhatsApp/SMS delivery is not surfaced until its product, consent and provider
release is deliberately enabled.

Consequences: Reception work is faster without creating parallel records or
weakening tenant, permission, capacity, audit, idempotency or time-zone rules.
The interface can later add online tenders, mobile messaging and inventory
reports without replacing the canonical Appointment, Client, Sale,
CommunicationIntent or report contracts.

### ADR-037: Refine authenticated workspace density and shared interactions

- **Status:** Accepted on 2026-09-13, per the product owner's refinement request.
- **Related requirements:** FR-02 through FR-09, FR-11 through FR-19; PRD usability and accessibility requirements.

Decision: Use an authenticated workspace density layer with 40px standard
fine-pointer desktop controls, 32px optional row actions and 36px menu options.
Restore at least 44px targets on mobile/coarse-pointer devices. Preserve body
readability and the existing brand; reduce excess spacing and duplicate
navigation before reducing typography. This clarifies the previous universal
44px rule for daily desktop operations, without reducing touch targets.

Shared native-option select enhancement owns search, selected/disabled states,
keyboard navigation, validation focus and viewport-aware popovers. Shared
dialogs own scrolling and stable action footers. Services and provider creation
use drawers; reports use a single searchable picker. Existing server endpoints,
permissions, audit reasons, money and scheduling rules remain authoritative.

At the user's explicit follow-up request, hide Inventory from the shared
navigation source used by desktop and mobile. Retain the underlying module,
routes and entitlements for later work; this does not authorize deletion or
expand the current phase. ADR-036's report visibility decision remains intact.

Evidence: [workspace refinement audit](audits/2026-09-13-workspace-refinement/README.md),
client/SSR builds, six menu boundary tests and the existing application suite.

Follow-up refinement: The user requested a collapsible calendar side panel.
It starts closed, yields its width to the schedule, and opens through a toggle
or appointment selection; mobile places it above the grid. The first hour label
stays within the grid boundary. Report presentation uses readable labels and
the report's time zone, with optional full source references; three additional
frontend tests verify UTC/offset/DST formatting and labels.

### ADR-038: Treat team access as a secure invitation attached to a canonical team seat

- **Status:** Accepted on 2026-09-14, per the product owner's team-access request.
- **Owners:** Product, Engineering and Security.
- **Related requirements:** FR-01, FR-05 and FR-19; ADR-008 and ADR-013.

Context: The tenant access foundation already separated User, Membership and
StaffProfile and supported secure invitations, starter/custom permissions,
revocation and audit evidence. The owner-facing Team workspace created only a
bookable StaffProfile, however, and explicitly deferred login access. Invitees
without an existing account also landed behind authenticated middleware, so
the secure token could not complete their account setup.

Decision: Team setup may create or update the canonical StaffProfile and issue
its Business-bound Membership invitation in the same owner action. Login access
remains optional because a schedulable person is not always a software user.
The existing `staff.max` entitlement remains the operational team-seat limit;
connecting a login to that profile does not create or charge a duplicate seat.

Invitation links remain hashed, single-use, expiring and bound to the exact
email, Business, role, locations and optional StaffProfile. Existing Users
authenticate normally. A new invited identity chooses its own password on the
invitation surface; possession of the emailed one-time token verifies that
email before the Membership is activated. ClipperDesk does not generate or
email temporary passwords.

Owners choose a reviewed starter role or an exact Business-scoped permission
set. A manager with staff-management access may grant only capabilities already
held by that manager and may never grant or remove Owner access. No member may
change or revoke their own access through Team management. Membership role,
permission and location changes are audited; revocation requires a reason,
invalidates sessions/tokens promptly and preserves StaffProfile and historical
actor attribution.

Owners and other `audit.view` roles receive a tenant-scoped Activity workspace
over append-only AuditEvent records. The UI presents searchable, categorized
summaries; ordinary users cannot edit/delete evidence and the existing audit
writer continues to redact credentials and tokens.

Owners may explicitly restore revoked Membership access with a new reason; the
person then signs in with their existing password rather than receiving a
second identity or an administrator-known credential.

Consequences: The owner experiences one coherent people-and-access workflow,
invitees can join without an administrator distributing credentials, and seat
pricing can rely on the existing team limit without double-counting login
identity. Production invitation delivery still requires the approved sender
domain and live transport certification.

### ADR-039: Multi-region messaging uses safe transport promotion and optional business-owned senders

- **Status:** Accepted on 2026-09-20, per the product owner's messaging and target-market direction.
- **Owners:** Product, Engineering, Security, Privacy, Operations and Support.
- **Related requirements:** FR-01, FR-13, FR-19 and FR-20; supersedes ADR-019 for communications direction and ADR-020/ADR-025 for target-market direction.

Context: ClipperDesk's initial target businesses are in the United States,
Canada, the United Kingdom and selected European markets, not India. Customers
need useful appointment communication before completing their own provider
onboarding, while established businesses need messages and replies to appear
from their approved business identity. Provider tests must not accidentally
send or spend, and a shared inbound number cannot safely infer a tenant from a
reply in production.

Decision: Email remains a separate application-owned channel. SMS and WhatsApp
share an application-owned mobile contract with two sender modes:

- **ClipperDesk messaging** is the default platform sender for consented,
  business-labelled outbound notifications. It does not offer a shared
  production inbox because replies cannot be assigned to a tenant reliably.
- **Your branded client line** is an entitled capability using an approved
  business sender identity. It may support direct replies and a tenant-scoped
  inbox only after provider and country-specific verification is active.

Every plan may include an explicit mobile-message allowance; the current
Starter and Pro values are 100 and 1,000 per billing period. Additional-credit
purchasing is intentionally deferred until the core delivery, callback and
reply workflow is externally certified. Branded sender ownership and two-way
messaging are separate entitlements from usage credits.

SMS and WhatsApp require channel-specific opt-in evidence for outbound traffic.
Transactional purpose never grants marketing consent. Recognised STOP and START
keywords update suppression and append consent evidence immediately. The
preferred mobile channel is queued first; a different configured fallback is
held and released only after a definitive failure, following a fresh consent,
template and sender-readiness check.

Transport promotion is explicit and configuration-driven: `fake` performs no
network request; `twilio_test` uses Twilio test credentials for zero-charge SMS
API simulation; `whatsapp_sandbox` can create real, potentially billable
Sandbox traffic only when its independent enable switch is true; and `live`
requires its own production-send switch. Production authentication prefers a
restricted Twilio API key, while the Auth Token or dedicated webhook token is
retained for request-signature verification. Credentials remain server-side
and encrypted when stored for a business sender.

Consequences: booking, queue, waitlist and payment events can select email plus
one consented mobile path without duplicate outreach. A provider-owned sender
can be introduced without changing the appointment workflow or rewriting
history. Sandbox is a controlled integration step, not a free or production
environment. Live launch remains blocked until the exact countries are chosen
and the relevant sender registrations, WhatsApp business/display-name/template
approvals, public HTTPS callbacks, legal wording, privacy/retention rules,
quiet-hour policy and end-to-end provider certification are complete.

The existing India/INR/`en-IN` commerce and public-site implementation is not
silently treated as suitable for the new market direction. It must be
regionalised and reviewed under OPEN-15 before a paid regional launch.

Evidence: `docs/modules/communications.md`, the FR-13 reliable communications
feature suite, client/SSR production builds, and the transport-lock tests.

### ADR-040: Use Amazon SES for ClipperDesk business-account email

- **Status:** Accepted on 2026-09-20, per the product owner's configured provider direction.
- **Owners:** Product, Engineering, Security and Operations.
- **Related requirements:** FR-01, FR-05, FR-13, FR-19 and FR-20; complements ADR-039 without changing the client mobile-channel contract.

Context: Owner and login-bearing team journeys need professional transactional
email for identity verification, security changes, workspace access and SaaS
billing. The repository had mixed boilerplate templates, no installed SES
runtime, no coherent trigger catalogue and no privacy-safe delivery evidence.
Client appointment messaging already has a different consent and tenant-brand
boundary that must not be weakened by account-email implementation choices.

Decision: Amazon SES is the production transport for ClipperDesk business-
account email through Laravel's application-owned notification layer and the
official AWS SDK. Account, Security and Billing are distinct configured sender
streams, even if they initially share one verified address. Critical state-
change notifications queue after transaction commit with bounded retries;
verification and password-reset links remain synchronous. Successful sign-in
email defaults to a new-browser/device alert rather than one email for every
routine session, with explicit `always` and `off` deployment modes.

Every mail-channel attempt writes a metadata-only delivery record with masked/
hashed recipient evidence and provider message ID. Message bodies and plain
recipient addresses are not copied into the ledger. A transport acceptance is
not represented as inbox delivery. Client appointment and receipt email remains
in the FR-13 Communications outbox with its existing consent, template,
idempotency and fallback rules.

Consequences: AWS credentials can be rotated without changing product code;
local/test environments remain non-sending by default; workers must consume the
`emails` queue; and support can distinguish sending, accepted and failed
attempts without exposing message contents. OPEN-11 continues to block real
production-domain sending. SES sandbox exit, SPF/DKIM/DMARC, custom MAIL FROM,
bounce/complaint event destinations, alarms, suppression handling and a live
deliverability rehearsal remain Operations launch gates.

Evidence: `docs/modules/business-email-notifications.md` and the focused
business-email journey feature suite.

### ADR-041: Launch client mobile notifications as essential SMS only

- **Status:** Accepted on 2026-10-01, per the product owner's direction to defer WhatsApp and focus on text notifications.
- **Owners:** Product, Engineering, Security, Privacy and Operations.
- **Related requirements:** FR-13 and FR-20; narrows the initial user-facing scope of ADR-039 without deleting its provider abstraction or historical evidence.

Context: The multi-channel foundation proved sender, consent, fallback and inbox
boundaries, but its Sandbox and channel choices made the first owner and booking
experience harder to understand. The immediate product need is dependable text
notification for important appointment events, with minimal client fatigue and
a straightforward path from local simulation to registered live sending.

Decision: The initial client-facing mobile channel is SMS. Owner and public
surfaces expose email and SMS only. SMS requires explicit channel consent and
every message identifies the business. The default cadence is a booking/status
message when needed, material changes/cancellation, payment or deposit actions,
requested waitlist/queue alerts, and one reminder normally 24 hours before the
appointment. Promotional feedback and rebooking texts, cross-channel fallback,
free-form replies and the client inbox are disabled.

The shared ClipperDesk sender remains the default. An entitled business may
prepare an approved branded SMS line, but it cannot be selected until active.
Inbound SMS remains enabled for STOP/START compliance. The application keeps
dormant provider adapters and historical records, while a server-side enabled-
channel allow-list prevents new deferred-channel messages and suppresses old
queued work before any provider call. No historical consent or delivery evidence
is deleted.

Consequences: The booking and owner journeys become simpler, delivery costs and
client interruptions are predictable, and live promotion requires only SMS
sender registration for the chosen launch country. Reintroducing another mobile
channel, fallback or conversational inbox requires a later accepted decision,
updated consent wording, provider certification and renewed UI/test coverage.

Evidence: `docs/modules/communications.md`, the FR-13 focused suite, public
booking coverage, the SMS-only data migration and client/SSR production builds.

### ADR-042: Compact, plain-language presentation across existing capabilities

- **Status:** Accepted on 2026-10-02, at the product owner's request.
- **Related requirements:** FR-01–FR-20; PRD sections 3, 4, 10 and 12.

Use shared semantic typography, density and interaction components across shop,
public booking, account and platform administration. Use “appointment” for a
scheduled visit and “booking” for reserving it or the public booking page.
Dashboard view names describe their layout: Appointment list, By staff, Now &
next. Keep compatible stored preference keys and all user-entered business data.

UI state must match implemented payment, delivery and publishing behavior.
Readable audit summaries are read-only projections of whitelisted changes;
they never modify historical payloads. The refinement does not add deferred
features, enable quarantined routes, or waive production launch gates.

Evidence: `docs/modules/product-experience.md` and the dated platform refinement
audit; individual verification claims belong in project-status.md.

The owner's 2026-10-02 StepES reference follow-up refines this contract with
light operational navigation, a pale canvas, shared breadcrumbs, 26px workspace
headings, restrained statistics cards and aligned searchable records. Public
controls retain their existing touch-friendly sizing. Reusable authenticated
record composition is loaded separately from the public core stylesheet. This
changes presentation only; it does not alter reporting calculations or the
release scope. Evidence: the StepES-inspired follow-up audit.

The subsequent owner-requested surface refinement distinguishes light navigation,
canvas, toolbar and table-heading surfaces, with navy ink and selective existing
indigo accents. These are shared presentation tokens, without a new product mode.
Evidence: the 2026-10-02 surface-hierarchy audit.

The owner's next request keeps content surfaces and selects primary-action blue
for left navigation and mobile drawers, with inverse brand/text and a cyan
selection edge. Signed-in headers receive a subtle blue wash and clearer identity
and account controls. This supersedes the light-navigation color choice only;
navigation structure, permissions and workflows remain unchanged. Evidence:
the 2026-10-02 blue-shell audit.

The owner's brand correction replaces that action-color navigation with the
public frontend's brand-primary navy (`#172554`); action-primary indigo remains
the CTA color. Account disclosures use compact icon rows, an account identity
section, sentence-case multi-workspace billing grouping and a separated Sign out
action. Existing permission-filtered billing destinations and native disclosure
keyboard behavior are preserved. Evidence: the 2026-10-02 brand-account-menu audit.

### ADR-043: The dashboard is a permission-aware daily workspace

- **Status:** Accepted on 2026-10-02, under the product owner's explicit dashboard redesign authorization.
- **Related requirements:** FR-03, FR-05–FR-08, FR-11–FR-12, FR-15–FR-18; PRD sections 10 and 12.

Prioritize live operational work and resolvable exceptions before supporting
financial information. Use capabilities rather than title/role-name layouts.
Calendar-own visibility fails closed without a linked StaffProfile. Location,
contact, appointment-note, checkout, revenue and inventory access are enforced
before serializing dashboard data. Existing calendar/lifecycle/checkout/report
services remain authoritative; no duplicate scheduler or advice engine is added.

FR-18's staff availability is presented as **Staff scheduled**: working windows
after breaks/leave, intersected with opening hours. This avoids implying attendance
or bookable resource capacity. Expected revenue is labelled **Sale value** with
its open/completed-sale definition. Reporting formulas and append-only money
history are unchanged. Queue counts include waiting, notified and assigned
entries that have not started service. Historical/future dates never claim that
appointments are occurring now or overdue relative to today's clock.

Dashboard appointment details are bounded to 100, prioritizing active visits
before finished history, with an explicit completeness warning and exact status
aggregates. Tablet/phone attention uses a compact summary with explicit disclosure. The visible idle page refreshes every minute;
mutations and open drawers pause it. Existing per-user device view keys remain
compatible, with Now & next as the default for users without a saved preference.
Financial comparisons remain in Reports; the known previous-period defect is
not used to invent a dashboard trend. Attendance, general tasks, client
memberships, subscription performance and generated insights remain outside this
slice because they have no approved/implemented operational data source.

Consequences: operational actions reuse version/idempotency, authorization, audit
and notification rules. Exact appointment links preserve date/location. Checkout
links to older unpaid visits require a complete, location-scoped lookup, so the
checkout entry and record operations now enforce that same location boundary.
The linked calendar applies the same contact/note redaction, preserves unreadable
fields during schedule changes and restricts note edits; its print path checks
location assignment. Inventory remains outside the visible operations release
under ADR-036; this redesign does not promote it.
This does not waive live-provider or production release gates.

Specification: [daily workspace](modules/dashboard.md). Evidence:
[audit and verification](audits/2026-10-02-daily-workspace/README.md).

### ADR-044: Calendar is the staff-first operational schedule

- **Status:** Accepted on 2026-10-03 under the product owner's explicit full Calendar redesign authorization.
- **Requirements:** FR-03–FR-08, FR-11, FR-15, FR-19; complements ADR-015/016/037/043.

Default to a dense Team day with time vertically and staff horizontally. Retain
Day and Week and add a deliberate Agenda/mobile presentation. Month and recurring
series generation are not promoted. One toolbar, restrained status cards, working
windows, unavailable periods and contextual drawers replace the stacked controls.

Selected-range appointment filters never alter capacity. Project unfiltered staff
segments, blocks, active holds and other-location commitments; released processing
time is distinct. A gap means free staff time, with service qualifications, duration,
resource capacity and booking policies revalidated by the existing atomic commands.
Drag/reassignment/resize opens a review with an explicit reason before committing.
Current-day operational status follows persisted lifecycle state, not inferred attendance.

Explicit dated closures and full-day leave take precedence over overnight carry.
Timed unavailable rules are checked as real intervals in both the projection and
booking validator. Clock-change dates pause wall-grid drag/slot creation and direct
users to the booking drawer; UTC capacity remains authoritative. Historical visits
remain visible when staff are inactive or no longer assigned to the location;
only active assigned staff are offered for booking.

Existing-client lookup is bounded and tenant/own-history scoped; contact fields
require contact permission. Explicit client identity participates in new-command
hashes; null identity preserves existing hashes. Replacements retain the original
canonical client, including inactive client records, without creating duplicates.
Existing-client booking resolves saved contacts before form validation and removes
international mobile display formatting without guessing a country code. A valid
saved number is reused automatically. Contact-authorized operators may supply an
optional appointment-only number when the saved mobile is missing or invalid;
permanent profile corrections remain in the existing authorized/audited client
workflow. The drawer shows the saved number or the editable fallback, clears stale
contact errors on selection, and retains contact redaction for restricted roles.
New selected-client bookings/copies require an active client. Checkout readiness
comes from canonical sales and is serialized only with checkout permission.

View/filter device preferences are per user/business, contain no client data and
never override explicit URL state or authorization. The visible idle page refreshes
once per minute; input, open disclosures/drawers and mutations pause it. Navigation
preserves browser history and filtering preserves schedule scroll.

Specifications: [scheduling operations](modules/scheduling-operations.md),
[calendar client linkage](modules/client-records.md). Evidence:
[Calendar review and verification](audits/2026-10-03-calendar/README.md).

### ADR-045: Walk-ins are a live front-desk operations board

- **Status:** Accepted on 2026-10-03 under the product owner's explicit end-to-end Walk-in Queue redesign authorization.
- **Requirements:** FR-03–FR-08, FR-11, FR-15, FR-19; complements ADR-015/016/037/044.

Keep waiting clients primary, with permanent real positions, a NEXT marker,
elapsed waits, requested services and staff preferences/assignments. A compact
team panel exposes available gaps and upcoming reservations; in-service and
recently finished visits connect to authorized completion and canonical checkout.
Search and filters preserve actual order. Use the existing statuses; introduce no
priority, VIP, hold or automatic-assignment policy. Reasoned queue overrides
require both queue management and schedule-override access in the assigned branch.

Share Calendar's authoritative availability projection for an ordered, conservative
qualified-staff forecast, including variants, closures, breaks, bookings, blocks,
holds and cross-location work. Arrival and refreshed estimates use this same
method. Forecasts are advisory ranges; full staff/resource rules are checked on
selection and commit. Do not invent an end time for a service running over its
planned finish. Reception may save a qualified assignment without reserving time.
A configured booking interval still governs appointment time. Expired fit checks
must be repeated before a new service starts.

Minimal canonical client intake stays in the drawer; saved contacts are reused
and normalized without editing the profile. Protect contact/note permissions.
Queue-add replay is idempotent. Conversion/start/lifecycle/history commit together,
and Calendar starts/terminal transitions/replacements synchronize linked queue
records. Once converted, Calendar owns reservation changes and cancellation.
Completion hands off to the existing Sale checkout; no new payment behavior.

Use one elapsed-time clock and 30-second visible idle polling. Keep the board
visible during refresh; pause for user input, filter/recent disclosures, dialogs
and mutations, but not the expanded team panel. Replace stale forecast precision
with a refresh cue. Reuse the compact Calendar shell and native contextual drawers;
phones use cards and a collapsible team strip. Plain operational messages such as
“Walk-in added to the queue.” replace internal estimation terminology.

Specifications: [scheduling operations](modules/scheduling-operations.md),
[client linkage](modules/client-records.md). Evidence:
[Walk-in audit](audits/2026-10-03-walk-in-queue/README.md).

### ADR-046: Clients is an operational salon CRM over governed records

- **Status:** Accepted
- **Date:** 2026-10-03
- **Requirements:** FR-11/12/13/15/19; complements ADR-018/043/044/045.
- **Basis:** Owner's explicit end-to-end Clients improvement request.

Directory prioritizes identity, last/next visit, completed visits and explicit staff
preference. Default profile is a readable overview; editing, notes and supporting
form/file/privacy tools are deliberate actions. Authorized appointment summaries
and server-paginated history share staff/location scopes. Financial summaries read
the canonical sale ledger with currency groups and separate net receipts, open
balance and awaiting-checkout counts; they never combine currencies or treat a
booking quote as a payment. Contact-redacted edits preserve canonical contacts.
Manual intake warns before creating a different name with a matching contact;
existing conservative matching and previewed/versioned/reasoned merge remain.
Calendar and Queue receive server-authorized active identities and reviewable
current defaults. No Phase 2 client benefit instruments or new messaging flow is
promoted. The client-records specification is restored before these changes.

### ADR-047: Checkout is a reviewed basket followed by received-payment recording

- **Status:** Accepted
- **Date:** 2026-10-03
- **Requirements:** FR-14/15/16/17/18/19; complements ADR-020/039/044/045/046.
- **Basis:** Owner's explicit end-to-end Checkout & Sales improvement request.

Restore `modules/checkout-sales.md` before changing checkout. Completed appointments
and converted walk-ins remain the checkout aggregate. A server preview resolves
booked snapshots, eligible current service variants and location retail stock.
Saving binds to the exact quote and freezes sale lines; reasons accompany removal,
price and booked-performer changes. Owner/manager authority is required for price
or booked-performer overrides and discounts above the configured limit. Ordinary
discounts require `discounts.apply`; browser approval flags are not authority.

Same-appointment, same-currency deposits must have succeeded payment evidence.
Application is capped, idempotent and distinct from new tender. A fully prepaid or
zero-value sale completes without a fabricated payment. Stock and commission/tip
entries follow existing completion and reversal rules. Partial and split receipts
use Sale-root serialization; a split commits all ledger/audit/stock/commission
changes together. Pay later leaves an open balance and creates no tender.

Manual cash, external card, UPI, transfer, link and custom method entries only
record money already received; they never initiate a charge. Persist uncertain
payment/refund payloads and their keys per user, business and sale, recover with
exact replay, and reject changed-key payloads. Refund/void records remain append-only
and require original tender, reason, confirmation, cumulative item bounds and
explicit product disposition. Provider-managed payments remain blocked from this
manual refund flow under OPEN-13/16. Later adjustments do not rewrite receipts or
reopen settled sales for collection. Separate Revenue permission gates paginated
business history; Checkout permission retains specific operational visit detail
and receipt access. Accountants can inspect history without checkout authority.

Use compact desktop context with a bounded sticky summary and a phone payment
shortcut that keeps the due visible. Preserve Calendar, Clients and Queue handoffs.
No standalone unlinked sale model, Phase 2 benefit instruments, online payment
certification, new receipt-delivery consent bypass or financial allocation-transfer
UI is inferred. Existing cash-close/report services remain available; the bounded
screen does not claim a new till-close or tax-configuration console.

## ADR-048 — One workforce workspace with shared capacity and reviewed edits

- Date: 2026-10-03
- Status: Accepted
- Requirements: FR-03–FR-06, FR-08, FR-17–FR-19

Team & availability is one workspace with Team, Weekly coverage, Time off and
manager-only Access. A compact staff drawer contains Overview, Schedule, Services
and permissioned Access. The existing Calendar capacity projection is the single
source for effective windows, unavailable bands and reservations. The weekly view
shows staffing coverage; free staff time is not a guarantee of service/resource
fit. Overdue in-service work cannot be labelled available. Reserved-time ratios
are operational capacity context, not attendance or employee performance scores.

Calendar-all operators may read assigned-branch coverage; calendar-own operators
see only their linked staff profile. No self-service schedule writes or leave
approval model is inferred. Managers may edit only within every assigned work
branch, and may grant only capabilities/branches they themselves control. Work
locations and Membership login-access locations stay separate. Owner and current
account protections, tenant binding and existing notification/audit behavior stay
in force. Login-only accounts remain reachable without inventing booking profiles.

Schedule edits require a stored revision and an exact normalized-content hash,
15-minute impact preview, and staff/location locks compatible with atomic booking.
Every future occupying visit outside the proposed windows is reviewed, including
existing exceptions; changed appointment versions invalidate review. Conflicts
must be resolved in Calendar or explicitly retained with a reason. Active affected
holds block reductions until resolved or expired. Dates/times, split shifts,
recurring/dated blocks and cross-zone branch overlap are validated on the server.
Business closures/special hours affect capacity, while outside-hours warnings
preserve entered hours. Schedule writes audit before/after and exact applied
replays create no additional changes. The legacy staff-availability endpoint uses
the same contract. Expired dated exceptions remain intact and are excluded from
current editing. New exceptions need a current/future end date. Coverage shows
seven days, with four upcoming shift days and two weeks of reservation context.

Current service qualifications, duration, price and online visibility are versioned;
existing appointment/sale snapshots and commission/tip entries remain unchanged.
Future-effective variants are preserved and cannot be silently overwritten by the
current-only editor. Qualification removals used by future visits require a reason;
active holds protect affected qualification and bookability changes. Minimal
creation may omit hours, services and login; exact create retries do not rewrite
existing profiles. Permissions use existing business starter/custom roles rather
than professional titles. Commission statements add balances per recorded currency.

No HR payroll fields, leave approval, attendance tracking, external calendar sync,
travel policy, schedule notifications, or Phase 2 scope is inferred. OPEN-19 records
the remaining dated/overnight/travel editing contract. See the
[workforce specification](modules/team-availability.md) and
[local review evidence](audits/2026-10-03-team/README.md).

## ADR-049 — One reviewed salon catalogue preserves booked and financial truth

- Date: 2026-10-04
- Status: Accepted
- Requirements: FR-03–FR-09, FR-14–FR-19

Services owns one dense catalogue with inline categories/add-ons and an explicit
three-section drawer. Existing settings.manage and full work-branch scope govern
configuration. Reception consumes this truth through booking/Queue/Checkout.
Staff > branch > base pricing, effective staff variants, canonical segments,
resources and historical snapshots remain the shared operational contract.

Current changes require configuration/upcoming revisions, booking-compatible locks,
live-hold protection and reasoned impact review for future high-impact work. Retire
and version assignments; preserve segment/resource identities and effective dates.
Exact UUID/payload saves commit idempotency with the change and audit. Recover
uncertain requests with exact replay; protect meaningful unsaved changes. No edit
silently publishes/reactivates or rewrites existing appointments, sales or ledgers.

Categories reorder accessibly and cannot archive active children. Copies start
inactive/internal with new identities and remapped resource segments, without
historical records. Import is a new-service setup path: existing rows are skipped
and changed through the reviewed catalogue, never an unreviewed bulk pricing/status
update. Imported duration/currency/name/price and older previews are validated.

Calendar displays eligible dated variants, selected-professional duration and
estimated current price; booking commit remains authoritative. Public add-ons need
attached selected parents; checkout enforces parent eligibility for added add-ons.
Service deposit none inherits global policy. Tax category is a reference; actual
tax remains CommerceSetting/recorded booked tax. No tax exemption, Phase 2 benefits,
new image-upload contract or paid online confirmation is inferred. OPEN-19/20 and
OPEN-16 bound unsupported dated editing, service-rule extensions and deposits.

See [Services specification](modules/services.md) and
[browser/automated evidence](audits/2026-10-03-services/README.md).

## ADR-050 — Prepare editable categories with business-type starter services

- Status: Accepted on 2026-10-04 following the product owner's request.
- Requirements: FR-02, FR-04; clarifies ADR-035 and ADR-049.

New-business onboarding shows a small configured category set alongside the
existing selectable starter services. The chosen business type determines the
set, rather than seeding every business with unrelated salon categories.
Confirmation creates all suggested categories, including empty groups, and only
the selected services with their correct category references. These are ordinary
business-owned categories, freely renamed, reordered or archived in Services.

The existing starter transaction and completed-session guard remain authoritative.
Reuse tenant categories case-insensitively and preserve existing names, order and
archive preferences; append missing groups without restoring archived ones.
Starter services in an archived group remain inactive/internal. Record newly
created category IDs/count alongside service evidence. Existing service catalogues
and completed sessions receive no automatic seed, overwrite or backfill; later
changes of business type never regenerate the catalogue.

Category definitions stay in the same configuration as the service templates.
The combined haircut/beard appointment belongs to Combined services; it does not
introduce Phase 2 package instruments. The change is additive to schema version 2
and requires no migration or new shared/global category table.

Evidence: [starter-category review](audits/2026-10-04-starter-categories/README.md)
and `GuidedOnboardingExperienceTest` cover all supported profiles, selected-service
mapping, empty groups, reuse/archive/order preservation, tenant isolation, ordinary
category edits, retry safety and existing-catalogue protection.

## ADR-051 — Reports shares operational truth with explicit analytical bases

- Date: 2026-10-04
- Status: Accepted; implemented directly in `/Applications/AMPPS/www/barber_app`
- Requirements: FR-18, FR-14–17, FR-19

Reports defaults to a historical Business overview with searchable report groups,
compact metrics, period comparisons and record investigation. It reuses shared
product controls and operational source links. SQL aggregates cover the complete
filtered scope independently of detail pagination. CSV generation streams the
same projection with requester/location/own-staff permission checks at request,
generation and retrieval; print is a bounded summary with complete totals.

Sale-cohort receipts preserve Dashboard/Checkout's recorded paid + applied deposit
− all returns basis. Transaction-date payment activity is a separate report and
excludes deposit collections. Immutable line values retain their original tax
basis; return allocations, tax and compensation are never reconstructed from
current catalogue prices or newly inferred rules. Reports selects one recorded
currency and independently enforces own-calendar and own-compensation scope.

Location-local calendar boundaries and comparisons use UTC half-open bounds;
mixed-zone aggregate scope requires a branch selection. Paying-client
classification counts distinct clients from first completed sales across permitted
branches/currencies. It does not claim appointment retention. Capacity reuses
Calendar windows, breaks, leave, closures and blocks, unions occupied segments,
and discloses that retained configuration is not historic attendance. Prior-period
capacity comparison is unavailable without historical schedule snapshots.

Membership/package/gift-card/recurring-billing analytics remains Phase 2. Inventory
navigation remains hidden under ADR-036. No forecast, external benchmark,
composite staff score, scheduled reporting or accounting liability is inferred.
OPEN-14 is further narrowed by the restored Reports specification; existing
launch, regionalisation and operational decisions remain unchanged.

See [Reports specification](modules/reports.md) and
[review evidence](audits/2026-10-04-reports/README.md).

## ADR-052 — Client notifications is an operational workspace with SES and Twilio

- Date: 2026-10-04
- Status: Accepted following the product owner's end-to-end redesign and explicit provider instruction.
- Requirements: FR-13, FR-06, FR-08, FR-14, FR-19; clarifies ADR-039/041.

Client notifications combines searchable automations, safe versioned template
editing, scoped delivery investigation and separately saved channels/timing.
Ten event rules are connected; two deposit templates remain visibly prepared
because no upstream deposit events invoke them. Neither a per-rule toggle nor
test-send infrastructure is inferred. One 24-hour reminder, essential SMS consent,
quiet hours, STOP/START and release locks retain ADR-041. Multiple reminders,
marketing, deferred mobile channels, inbox and Phase 2 benefit messages are not
promoted by this redesign.

Client email now uses AWS SES with existing environment credentials and configured
mail sender; SMS uses Twilio. This replaces the client Resend adapter for new
attempts while retaining historical callbacks. Account/security email stays a
separate ledger. SES SendEmail has no native idempotency parameter, so SDK retries
are disabled, explicit throttling alone permits automatic retry and unknown
acceptance requires investigation. Uncertain retained attempts cannot silently
switch providers. Configured-topic SNS signatures provide callback evidence;
credential presence is not a live delivery certificate.

Manager writes use row locks, current revisions and reasoned retry. Publication
cannot change queued snapshots. History omits message bodies, secure links and
credentials; tenant, assigned-branch, own-calendar and financial read boundaries
apply to projections and commands. Client and Calendar handoffs share the same
scope. Explicit client preference withdrawals survive profile edits and are
rechecked before delivery. Receipt actions view issued immutable receipts rather
than implying another payment or generating financial history.

No real provider send or launch waiver was performed. See
[Communications specification](modules/communications.md) and
[review evidence](audits/2026-10-04-client-notifications/README.md).

## ADR-053 — Business setup separates operational readiness from online publication

- Date: 2026-10-05
- Status: Accepted following the product owner's complete onboarding review and explicit instruction to avoid publishing unfinished businesses.
- Requirements: FR-01–FR-05, FR-09, FR-13–FR-15, FR-19; clarifies FR-02 and supersedes ADR-035's automatic preview/publication clause.

Preserve the four resumable decisions and versioned, transactionally prepared
starter workspace. Owners review and personalize ordinary tenant records rather
than entering a blank product. Generated service IDs retain provenance; keeping,
editing or deactivating suggestions never rewrites operational history. Empty
starter selection is valid. Completed sessions cannot reseed, and businesses
with publication, appointments or sales cannot restore starter defaults.

Business setup becomes a persistent readiness center. One backend projection
checks six operational essentials against current configuration: profile/region,
active location with opening hours, valid current services, active team, a
qualified service/staff/branch combination with usable overlapping hours, and
booking interval/cancellation window. The four-week configuration horizon is
explicit and does not promise an unoccupied slot. Date-effective assignments,
branch membership, resource eligibility and current working rules apply. Internal
operation does not require online visibility, publication, a logo, another staff
member, imports or connected payment/communication providers.

Preparing a workspace never marks the private preview reviewed or publishes.
Online publication additionally checks public contacts/policies/slug, online
service/staff paths and explicit review. The owner chooses Go live. Existing
published businesses retain their state; pause/resume remains explicit. A preview
shows only services with valid online paths and describes base-price variants.
Live delivery/provider or legal approval is not inferred from configuration.

Focused profile, weekly hours, service and team edits reuse canonical domain
commands. Hours changes bind a short-lived impact review to exact windows,
revision and upcoming appointment versions, recheck holds, retain booked visits
and audit once on replay. Business profile and commerce save atomically with
slug changes. Settings-capable branch managers cannot edit business-wide setup
unless assigned every location; Owners retain business authority. Advanced
Services and Team workspaces keep their existing scopes.

No Phase 2 promotion, real provider send or launch waiver is approved. Existing
OPEN-13/15/16/19/20/21 remain applicable. See [Business setup specification](modules/business-setup.md)
and [screenshots, six-perspective review and verification](audits/2026-10-04-business-setup/README.md).

## ADR-054 — One plan priced by locations and bookable staff, with local rates and SMS credits

- Status: Accepted direction; commercial rates and live certification pending.
- Date: 2026-10-05.
- Integration authorization: on 2026-10-05 the user supplied
  `subscription-billing-update.zip` and requested its subscription/billing code
  be integrated into this source checkout. The package records this capacity
  direction, Twilio/SES cost accounting and country-local pricing. This import
  authorizes the source integration; it does not approve draft commercial amounts
  or activate paid provider operations.
- Decision: one base plus additional-location/additional-bookable-staff quantities.
  Count global active StaffProfiles once; do not charge login-only administrators.
  Use immutable country/currency/cadence rate cards. Preserve old subscriptions
  until explicit migration. Verified provider quantities own purchased limits.
- SMS: pooled monthly allowance, actual rendered segments and approved destination
  multipliers, optional prepaid packs, no automatic purchases. Include routine
  operational SES email. Keep ADR-041's SMS-only client channels and marketing/
  branded-sender/inbox exclusions. This supersedes the extra-credit implementation
  deferral, while retaining all external provider/refund/paid-launch gates.
- Billing: actor/version/expiry-bound review; pending paid upgrades, renewal
  reductions, fixed proration date, signed or authenticated provider verification,
  stable idempotency and append-only credit history. No payment success from URLs.
- Prices: USD 29 base/19 extra location/9 extra staff and illustrative text packs
  are draft examples only. Country rates must be separately approved and verified.
- Consequence: production stays disabled by default. Additional countries need
  explicit local cards and verified Stripe prices; no currency conversion guess.
- Evidence and contract: `modules/subscription-billing.md`, capacity/lifecycle/
  webhook/communications tests. Real provider, tax, refund/dispute and MySQL
  concurrency certification remain required before release.

## ADR-055 — Shared public booking origins and private contact-based eligibility

- Status: Accepted; source and local validation only, external production gates retained.
- Date: 2026-10-10. Authorization: the user requested the end-to-end booking audit, primary subdomain plus publicly available fallback, and removal of the previous-visit question with smarter contact handling.
- Requirements: FR-01, FR-03, FR-06/07, FR-09/10, FR-19/20.
- One `BookingBusinessController`, catalog, scheduling engine and Vue journey serve configured `BOOKING_HOST/{slug}` and `/book/{slug}`. Current fallback links render 200; historical aliases redirect to the primary current URL. All promoted links and canonical metadata use `BookingUrl`; tenant booking retains its existing noindex policy. No duplicate app, CORS exemption or weakened CSRF protection is introduced.
- Readable starter slugs and owner customization share one unique reservation table with historical aliases. Deleted-business reservations remain unavailable; links must never silently resolve to another business. Legacy collisions require explicit operator resolution before migration completion. Migration retry is safe after MySQL nontransactional DDL.
- Services, staff/time and essential details with inline review are the three active stages, followed by confirmation. Location and staff controls appear only when useful/permitted. The raw flow secret stays in the browser and its database digest; hold state contains an allowlist of public selections. Refresh restores holds and confirmed appointments without retaining customer contacts in browser storage. Hold replacement/release and confirmation lock business/flow and reuse the authoritative scheduling transactions.
- Known-client eligibility is inferred at details review using active same-business normalized name and contact candidates, rejecting contradictory saved contacts and ambiguous matches. Matching is classification, not authenticated identity or proof of a completed visit. No public contact lookup, profile disclosure, history display or saved-profile autofill is offered. First-visit restrictions and actual deposit rules are rechecked before confirmation. A keyed details digest binds the reviewed quote without storing raw contacts in flow state.
- Household/shared numbers, changed names or conflicting contacts can remain classified as new. The error offers another service or business contact; no guest profile merge is authorized. A future verified-contact recovery mechanism requires a separately reviewed privacy/identity contract.
- The source refinement does not promote Phase 2, certify WCAG compliance, configure live infrastructure or waive OPEN-13/15/16/19/20/21/22. Required-deposit self-service payment remains blocked by OPEN-16, with an accurate contact path and no paid-confirmation bypass.
- Evidence: [booking audit](audits/2026-10-10-public-booking/README.md), [journey](public-booking-journey.md), [deployment](deployment/public-booking.md).

## ADR-056 — Approved USD subscriptions and focused billing workspace

- Status: Accepted; deployed live certification remains pending.
- Date: 2026-10-11.
- Authorization: the owner requested usable Stripe billing, allowed USD-only
  subscriptions, and explicitly answered “Use these USD prices”: monthly USD
  29/19/9 and yearly USD 290/190/90 for base/extra location/extra bookable staff.
- Decision: offer only verified USD capacity rates to new businesses, including
  Canadian businesses. Software subscription currency is independent of operating
  country/currency; neither sales nor business settings are converted. Existing
  paid currencies and immutable purchased cards require reviewed migration.
  This supersedes ADR-054's USD draft/unapproved status and initial country-bound
  selection for the approved USD rollout. Other markets are not approved.
- UX: Overview, Plan and Invoices are separate tasks. Show current status/date,
  recurring total, essential usage, saved billing management and actionable debt.
  New trials receive one subscription calculator; unfinished countries/drafts and
  empty invoice panels are absent from Overview. Existing plan choices are folded
  under a disclosure for retained subscribers (superseded by ADR-057). Zero allowance means “Not included,”
  and merely using the purchased location capacity is not a billing warning.
- Reuse: keep ADR-029's Business-owned Stripe provider, signed webhook journal,
  scoped invoices, portal and reconcilers. Larafast Cashier's Team/User examples
  are not this app's ledger. Do not reactivate its disabled routes/listener.
- Setup: idempotent capacity provisioning verifies six licensed recurring prices
  before immutable local mapping. Managed webhook setup targets only
  `/billing/webhooks/stripe`, selects handled events, saves new secrets privately,
  and requires explicit live mutation flags. Credentials/delivery certification
  remain deployment duties. No charges are made by setup commands.
- Boundaries: included SMS retains the implemented allowance; new paid packs are
  removed from the approved catalog and stay off. USD software price approval does
  not approve destination economics, SMS refunds/disputes, tax policy, independent
  accessibility or live payment certification. No Phase 2 scope is promoted.
- Evidence: `modules/subscription-billing.md`,
  `deployment/subscription-billing-stripe.md`, and the 2026-10-11 billing audit.


## ADR-057 — Capacity-only selection in Subscription & billing

- Status: Accepted on 2026-10-11 following the owner's explicit prelaunch request.
- Requirements: FR-01, PRD §9; supersedes ADR-056's retained-tier disclosure.
- Decision: the owner billing workspace offers one plan based on purchased locations
  and bookable staff, monthly or yearly. Remove Starter/Pro cards, their comparison,
  tier-change dialog and server offer payload. No alternate tier is offered when
  capacity pricing is unavailable; use the existing support state.
- Old tier checkout GET links redirect to the Plan tab. Tier checkout and change
  POST requests return 410 after tenant/permission checks, without creating provider
  sessions or changing subscription terms. Capacity review/confirmation remains
  the only purchase/change path in this workspace.
- Retain financial records, provider-event processing, authenticated reconciliation,
  invoices, payment management, cancellation and reactivation. This UI/action cleanup
  does not purge local test data or automatically migrate a Stripe subscription.
- Evidence: billing workspace/lifecycle/capacity tests and the billing audit.

## ADR-058 — Internal admin login completes security setup within the panel

- Status: Accepted; internal admin MFA superseded by ADR-059
- Date: 2026-10-11
- Owners: Engineering
- Requirements: FR-19/20; implements ADR-013/023 without relaxing operational MFA.

Context: The product owner confirmed `/admin/login` is the ClipperDesk internal
staff entry point and requested repair. `make:admin` created the correct separate
role, but the panel rejected unverified/unenrolled accounts before offering setup.

Decision: Separate administrator identity admission from operational readiness.
`canAccessPanel` admits only active administrator roles; persistent panel middleware
allows pending identities only email verification, authenticator setup and logout.
Every operational page still requires verified email, confirmed TOTP and existing
platform session limits. Filament's required authenticator flow shares Fortify's
encrypted secret/recovery codes, including single-use recovery consumption and
security notifications. New credentials, automatic verification or fake enrollment
are not prerequisites for repairing an existing account.

Consequences: Internal staff complete setup entirely under `/admin`; salon login,
Business membership and `/platform` are not onboarding prerequisites. Signed email
links return to the panel; later logins challenge TOTP or recovery. Legacy resource
quarantine and tenant-isolation rules remain in force. Installation needs no schema
or dependency change; production deployment/delivery require separate evidence.

## ADR-059 — Internal admin login proceeds directly after email verification

- Status: Accepted
- Date: 2026-10-11
- Owners: Product and Engineering
- Requirements: FR-19/20; approved clarification recorded in the PRD.
- Supersedes: mandatory internal `/admin` MFA portions of ADR-013/023/058.

Context: After completing email verification, the product owner explicitly
requested disabling the internal admin 2FA step and allowing direct login.

Decision: `/admin/login` accepts password credentials for an active, unexpired,
unrevoked platform administrator role. Operational access requires verified email
and the existing 15-minute idle/eight-hour absolute session limits. Remove the
panel's MFA provider and enrollment gate; no second-factor setup or login challenge
is required, including for identities with existing Fortify enrollment. Preserve
stored secrets/recovery codes. The retired admin enrollment URL redirects to
`/admin`, subject to the same verification and session controls.

The separate `/platform` support workspace retains its verified-email, confirmed
MFA and role requirements. Share session-limit enforcement between both entry
points without applying the support workspace's MFA gate to internal admin pages.
Salon login, tenant membership, support approval/audit and legacy-resource
quarantine retain their existing contracts.

Consequences: Verified internal administrators enter the dashboard directly.
`make:admin` documents email verification as the remaining first-login step.
No schema migration, account recreation or credential reset is required. The
change is verified locally; source changes do not establish live deployment.

## ADR-060 — Restore retained admin menus for platform administrators

- Status: Accepted
- Date: 2026-10-11
- Owners: Product and Engineering
- Requirements: FR-19/20; approved clarification recorded in the PRD.
- Supersedes: ADR-023's blanket Filament menu quarantine for active verified
  platform administrators only. Tenant and financial invariants remain in force.

Context: The product owner requested full admin access for
`platform_administrator` and selected enabling all existing LaraFast menus after
reviewing the difference from exposing the separate ClipperDesk support workspace.

Decision: Restore Users, Roles, Permissions and all seven retained provider
billing resources under `/admin`, guarded by verified email and the existing
active platform administrator assignment. Retain persistent panel/session
middleware and ADR-059's direct login. Add user/business/canonical active
subscription counts and user growth to the dashboard.

User creation/editing requires a reason and writes audit evidence atomically.
Email changes clear verification; password changes remain hashed and are only
recorded as a boolean in the audit. User deletion is disabled to preserve account
lineage. The user's Platform roles tab grants/revokes the actual platform role
assignments through audited services, preserves revoked rows and prevents self
revocation. No global Spatie User trait or tenant authorization bypass is added.

Roles displays the actual Business-owned roles. Administrators may create/update
custom roles using MembershipAccessManager with a business, enumerated permissions
and reason. Starter roles and business bindings cannot be overwritten through the
generic editor. Permissions displays the canonical permission catalog read-only.
Legacy financial/provider records are readable, including invoice viewing and
downloads, while direct create/edit/delete and invoice-status-changing email
actions remain disabled. Their widgets cannot represent canonical Business
revenue, so dashboard metrics use canonical aggregates and order money widgets
are not registered on the restored list pages.

Consequences: All retained menus are available to the requested platform role.
Ordinary users, support operators, auditors and inactive/unverified administrators
do not gain these menus. This selection does not consolidate `/platform`, change
its MFA requirement, complete its placeholder pages, or migrate legacy billing.
No account reset or schema change is needed.


## ADR-061 — Public capacity pricing and reviewed signup preferences

- Status: Accepted on 2026-10-12 following the owner's public pricing page request.
- Requirements: FR-01, FR-13, PRD §9; extends ADR-056/057 to acquisition.
- Decision: public pricing uses the same verified USD capacity catalog as owner
  billing. One calculator publishes base/additional-location/additional-staff
  rates and complete monthly/yearly totals. Annual upfront total is primary;
  monthly equivalent and savings are secondary. Input examples are not plan tiers.
- Remove public Starter/Pro offers, comparison, registration selections and schema
  offers. Unavailable capacity pricing keeps a free-trial/support path and never
  displays drafts or a legacy fallback. Ordinary visits make no provider calls.
- Persist validated cadence and quantity preferences through email/Google signup
  in the business's registration intent. This is an estimate handoff, not a
  purchased rate card or billing commitment. Existing paid terms and resource
  provisioning stay separate; payment requires a fresh reviewed confirmation.
- Present implemented core tools and concise commercial questions. Do not promote
  deferred features, unlimited SMS, automatic top-ups, unapproved currencies,
  live client payment acceptance or unsupported certifications.
- Preserve public metadata/indexation and describe verified component prices in
  structured data. Additional fields are private operator/owner preferences;
  no provider identifiers or financial authority reach the public payload.
- Evidence and deployment: [public pricing specification](modules/public-pricing.md)
  and [review](audits/2026-10-12-public-pricing/README.md); additive signup-preference
  migration, no new Stripe configuration or provider mutation.

## ADR-062 — Evidence-backed privacy notice with resilient public rendering

- Status: Accepted implementation decision; legal/publication approval remains pending.
- Date: 2026-10-12
- Requirements: FR-01, FR-05, FR-09–14, FR-19/20 and PRD privacy/accessibility attributes.

The business owner supplied Clipperdesk as operator name, the postal contact
111 Galileo Dr, Stoney Creek, ON L8E 0B5, Canada, and support@clipperdesk.com.
These replace unidentified-operator/contact placeholders; they do not establish
incorporation, a DPO appointment or completion of a rights-handling workflow.

The privacy notice describes verified Google openid/profile/email behavior,
actual data categories and the limits of deletion, export, payment and provider
operations. No OAuth credential, scope or authentication behavior is changed.
Interactive visits reuse the existing public MarketingLayout/Header/Footer.
A Blade-rendered fallback supplies the same policy body and matching public shell
when Vue SSR is unavailable, avoiding a JavaScript-only legal notice.

At the owner's request the public review banner and privacy footer's preview
line are removed, and the sidebar becomes a compact native contents disclosure.
This presentation change does not approve the notice or waive a launch gate.
Publication requires the explicit config/privacy.php approval/operations checks,
verified provider/location fields, review reference and a reached effective date.
Only that state enables indexing, the sitemap entry and effective-date display.
Terms/refund retain their separate contract and financial approval requirements.

OPEN-10, remaining OPEN-13 items and OPEN-15 are retained. The notice candidly
discloses that customer-record deletion execution and full exports are incomplete.
See [the audit and resubmission checklist](audits/2026-10-12-privacy-policy/README.md).

## ADR-063 — Progressive staff pricing and pricing discovery before configuration

- Status: Accepted; owner direction on 2026-10-12.
- Requirements: FR-01, FR-13, PRD §9; supersedes flat staff pricing in ADR-056
  and the calculator-led presentation in ADR-061. Release gates remain in force.
- One plan: USD 29 base includes one location/person, USD 19 per extra location,
  progressive bookable staff positions 2–5 at USD 9, 6–10 at USD 6, 11+ at USD 4.
  Count active bookable staff once across all branches. Annual charges ten months.
- Config owns integer amounts, included counts and cumulative additional-staff
  bounds. Derive annual terms by multiplying every component by ten. Trial
  duration remains owned by billing config. Public and authenticated estimates
  read server terms; no client amount authorizes billing.
- Reuse the three-item Stripe architecture. Staff quantity remains total staff
  minus one; the staff Price becomes licensed recurring `tiered`/`graduated`
  with cumulative additional quantities 4, 9, infinity. Base and location remain
  per-unit. Publish new immutable base and component Prices for this revision;
  verify expanded Stripe tiers, tax behavior, currency and cadence before mapping.
  Signed subscription objects may omit expanded tiers but must match verified IDs
  and tiered/graduated mode. Retained flat cards continue to reconcile unchanged.
- No bulk or automatic customer migration. Owners can opt into current verified
  prices in the existing review/confirm flow; any rate-card switch is scheduled
  at renewal with no immediate charge. Normal retained-card quantity increases
  continue to use the old rates and established pending-payment/proration rules.
- Reuse the public SEO-page hero, breadcrumbs, typography and marketing shell.
  The starting-price/trial panel earns the hero's secondary column; no decorative
  stock photo is needed. Features precede growth rates; estimator defaults to
  one location/person/monthly and starts closed. Presets and reset only change
  local inputs. Main trial CTA has no quantity preference; estimator signup
  optionally saves non-binding preferences requiring later billing confirmation.
- Keep actual current SMS allowances: 100 credits per capacity staff per month,
  including 2,000 for a 20-person team, and existing subscription allowances.
  Do not promote unlimited messaging or silently increase solo allowances.
- Evidence, safe rollout and sandbox limits:
  [progressive-pricing review](audits/2026-10-12-progressive-pricing/README.md).

## ADR-064 — Google location search with owner entrance pins and appointment snapshots

- Date: 2026-10-12. Status: Accepted for this owner-authorized implementation.
- Requirements: FR-02/03/05/06/09/13/19; retains ADR-041/053/055/056.
- Use the existing Vue/Inertia setup, activation, booking and communication paths.
  Supported Places (New) widget manages session tokens/attribution; only selected
  address fields and geometry are requested. Google hours/contacts/names are not
  imported into operational records. No server Google secret is required.
- Keep provider geometry and suggestions transient; retain Place IDs and reviewed
  owner address data. Only owner-positioned entrance pins become durable operational
  coordinates. Legacy coordinates with unknown provenance remain untouched and are
  excluded from new nearby/nav/snapshot projections. Applicable legal/EEA review
  remains part of existing privacy/provider launch gates, not a storage waiver.
- Simple owner path: search, review address, place entrance, save. No coordinate
  entry UI, second address/map-URL questionnaire or new onboarding system. Optional
  address corrections and unit/arrival/parking details stay behind disclosures.
  Saving the sole/primary branch synchronizes the legacy business address summary.
- Inline branch selection retains applicable services, removes orphan add-ons and
  uses existing branch staff/service/hour/resource rules. Nearby ordering is local
  Haversine distance; customer coordinates are memory-only. Successful public booking
  documents allow same-origin geolocation under Permissions-Policy, with the existing
  user-triggered browser consent. Other pages continue denying geolocation.
- Freeze assigned branch operational details on every new appointment and backfill
  legacy visits from their best known current address. Same-branch replacement keeps
  the snapshot; a deliberate new branch captures new details. A public hold cannot
  confirm against changed location details. Primary/address edits never silently
  move an appointment or rewrite history. Upcoming appointments block timezone edits.
- Location-rich new notification intents capture the existing snapshot; an immutable
  footer supplements older/custom templates unless their variables already cover
  it. Existing queued messages/templates remain unchanged. The shared renderer and
  SMS segment accounting include the actual final content. No Google call occurs.
- Preserve commercial rules and SMS-only scope. API quotas, environment restrictions,
  real browser/device/provider behavior and production legal approval require target
  environment certification. A controlled relocation/amendment interface is future
  work; it cannot be inferred from a location edit.
- Contract/evidence: [Locations](modules/location-intelligence.md),
  [deployment](deployment/google-maps.md),
  [audit](audits/2026-10-12-location-intelligence/README.md).

## ADR-065 — Keep public content separate from implementation evidence

- Status: Accepted
- Date: 2026-10-13
- Basis: Product owner's comprehensive public content and SEO audit request.
- Requirements: PRD sections 1–4, FR-01–FR-20; preserves ADR-024/026/033/063.

Requirement mappings remain server-side documentation evidence. Public presenters
strip them before serialization, and public copy describes customer workflows
without internal QA, delivery-phase or acceptance language. A shared publication
policy blocks internal markers/obvious placeholders in editorial records across
detail, listing, counts and sitemap, while preserving stored history. Content and
SSR/browser SEO regression checks enforce this boundary.

One server SEO projection is rendered by the shared client/SSR head; navigation
must update canonical, descriptions, social tags, robots and JSON-LD together.
Production URL identity uses the configured primary brand host. Error/auth/private
responses must not retain indexable product schema from a previous page.

The retained Larafast roadmap/changelog/coming-soon GET surfaces and write entry
points return 410 without exposing or changing their data. This is quarantine,
not destructive cleanup; OPEN-09 remains. Payment recording, unavailable online
deposit collection, gated communications and regulated-industry limitations remain
visible in customer language. Legal review status cannot be removed through an
editorial task: OPEN-10/13/15 and live provider/release gates remain unwaived.

Specification and evidence: [Public website](modules/public-website.md) and
[dated audit](audits/2026-10-13-public-content/README.md).

### ADR-065 search operations follow-up — 2026-11-02

The owner explicitly requested Google Search Console submission and indexing
checks for the existing public website. Use the current curated eligible page
set; this does not approve private booking/account indexing, legal effectiveness,
new regional claims or general product launch. Report technical fetchability,
Google sitemap acceptance, individual index status and impressions separately.
Google's decisions and processing times cannot be promised.

`PublicSitemap` now supplies both the endpoint and legacy `generate:sitemap`
command. The command prints current XML without crawling or writing a static
file that could override live publication gates. Read-only deployment checks
must inspect HTTP status and rendered original HTML, rather than checking only
robots body text, metadata or a running process. Production hosting repairs and
pending Google actions are recorded in the [search audit](audits/2026-11-02-search-indexing/README.md)
and [operations guide](deployment/search-indexing.md); no existing release gate
is silently closed by those repairs.

### ADR-065 article editor restoration — 2026-11-04

Authority: the owner's request to repair the existing article module and image
upload. This restores the already-approved editorial/publication workflow, not
new acquisition scope. Article admin and the public renderer must agree on
stored content: retain Markdown compatibility and sanitize rich-editor HTML
through the installed Symfony sanitizer. Article-owned media uses an explicit
public disk, preserving existing public S3 deployments; temporary Livewire files
stay on the private local disk. Public article images and private client files
remain separate. No existing object is automatically moved or destroyed.

Expose the existing publication fields in the administrator form and validate
them before marking an article published. Permit unfinished drafts without an
image, retain work after upload errors, and keep scheduled/unreviewed/inactive
articles out of listing, detail and sitemap under the current shared gate.
Remove synchronous generation of unused social screenshots from article saves;
the featured image is the article's social image. Deployment and actual failing
upload verification are separate evidence; no production success is inferred
from test uploads or a PHP configuration file.

### ADR-065 simplified article status and automatic dates — 2026-11-04

Authority: the owner explicitly requested, “No need Publication tab, just status
is fine, dates should be the time when its done.” The Article section therefore
offers only Draft and Published as Status choices, without a separate Publication
section, reviewer entry or scheduling/date inputs. This supersedes the manual
editorial fields exposed earlier the same day; publication eligibility and
private-content protections remain in force.

The verified, authorized platform administrator who saves Published is the
reviewer, and review/first-publication timestamps come from the server in UTC.
Supplied hidden reviewer/date values are ignored. A no-op/visibility-only save
retains the previous review; changes to public content, images and search fields
record the current reviewer and updated time. An actual first publication date
is retained across edits and re-publication. Saving Draft keeps historical dates
but never publishes the article, regardless of Active. New drafts have no review
or publication date.

Existing future-dated records remain subject to the public query's reached-date
gate. An explicit Published save in the simplified editor publishes now, replacing
a future/missing publication date and recording a current review. The editor
does not offer new schedules. This does not publish any existing record during
deployment or waive image, summary, topic, search, content, named-author or
administrator authorization requirements. Local verification and deployment
evidence remain separate.

## ADR-066 — Clear introduction decisions and real private booking previews

- Date: 2026-10-14. Status: Accepted from the owner's eight setup requests and
  booking-confirmation bug report.
- Requirements: FR-01/02/03/05/09/19; clarifies ADR-035/053/064.
- Google signup clears stale intended navigation and enters the saved Business
  setup introduction. Email verification remains the prerequisite to tenant setup.
- Retain the owner-provider decision with an explicit explanation of its team,
  calendar, hours and service-assignment effect. Remove the online-provider
  question; preserve historical answers and compatibility with older requests.
- Use search-or-manual address entry with one authoritative full address, a
  bordered Google search, selected-address review, optional entrance map and
  optional corrections/arrival notes. Keep the canonical location editor.
- A new immutable `daily_9_21` starter preset replaces the opening-hours choices
  for new introductions. Saved legacy presets, established days/hours and booked
  history are preserved. The setup message instructs reviewing exact hours before
  accepting bookings; no implicit publication is introduced.
- Replace duplicate mock device cards with the actual `Booking/Welcome` services
  page and shared public catalog/presentation. Private settings-authorized routes
  serve previews and branding, with no-store/noindex and same-origin framing only
  on a successful preview response. Browser storage restoration, booking actions
  and header navigation are disabled in preview; viewing does not mark review,
  create commerce records, reserve a slot or publish. Availability/deposit review
  remains part of the real booking journey.
- Compare held/current location snapshots by sorted keyed values with strict
  types, excluding only the existing derived links/primary flag. JSON object-key
  ordering cannot imply a policy change; actual address, entrance, arrival and
  policy-version changes still require new review.
- No production deployment, existing-business hours change, financial-history
  rewrite or Phase 2 promotion. Evidence: [setup refinement audit](audits/2026-10-14-setup-refinement/README.md).

## ADR-067 — Platform-managed client notifications with simple channel controls

- Status: Accepted
- Date: 2026-10-14
- Basis: Product owner's explicit removal of owner email/SMS builders and business-branded notifications, with professional ClipperDesk client email requested.
- Requirements: FR-13, FR-06/08/19; replaces the owner template editing and branded sender clauses of ADR-039/041/052. The approved FR-13 scope is updated in the same change.

Client notifications offers Notifications and Delivery history. Managers save
only top-level email/SMS choices and quiet hours with current-revision checks;
there are no owner content, variable, draft, publish or sender-brand controls.
Retained owner mutation endpoints return authenticated 410 responses, with
foreign template/conversation scope still denied. Read-only examples contain
sample visit values and use the actual platform email renderer in a sandboxed
iframe; they never create delivery work or contact providers.

New email/SMS intents resolve a separately identified immutable platform content
revision and SMS uses the shared sender even when a saved legacy preference is
branded. Existing queued template references, historical sender profiles,
provider callbacks, consent and append-only financial evidence remain intact.
The platform identity supplies the SES display name; the configured verified
SES address and provider credentials remain in their existing configuration.

New platform client email has a branded responsive table layout, preheader,
event-specific status/copy, visit or payment details, arrival guidance and a
purpose-labelled secure action when available. All interpolated values are
escaped; only validated HTTP(S) URLs can become links. Plain text is retained.
Older captured/custom content uses a branded escaped wrapper instead of being
rewritten into a different event statement. No translation is implied.

Channel pauses suppress queued/retried/held work under locks, release only its
existing mobile reservation and record the manager settings audit. Already
claimed provider work cannot be recalled. Creation and dispatch both check the
channel setting alongside consent/STOP/preferences. Re-enable does not revive
suppressed history. Additive default-true columns preserve existing delivery
behavior; this does not enable an environment transport or certify live sending.
Prepared deposit handlers remain internal under OPEN-21. Registration, legal,
live-provider, privacy and public-payment gates remain unwaived.

[Specification](modules/communications.md) and
[review evidence](audits/2026-10-14-platform-notifications/README.md).

## ADR-068 — Provider-verified abandoned checkout recovery

- Status: Accepted
- Date: 2026-10-15
- Basis: Product owner requests a recoverable billing flow after abandoning payment, including Stripe credential changes and portal outages.
- Requirements: FR-01, FR-19, FR-20; extends ADR-029/054/061 without changing prices, proration, renewals or existing paid subscriptions.

Owners can edit estimates while an initial Checkout is pending. The pending
banner identifies its original quantities and total; continuing always rechecks
that original session. A separate authenticated, tenant-scoped Start again
command expires an open owned Stripe session before closing its exact local
request and permitting a new reviewed purchase. A completed session is reconciled
instead. Unknown outcomes, wrong accounts/modes, incomplete lookup results and
provider outages never authorize a second potentially payable checkout.

Persist an attempt before provider dispatch, including recovery of a committed
capacity claim without an attempt. Preserve the original idempotency key and a
customer binding obtained before a lost response. Recover uncertain creation by
reading the original owned customer and sessions; replay a no-customer outcome
only with the same credential fingerprint within 23 hours. Retain closed attempts,
quotes, audit records and append-only financial history. New attempts carry an
exact change reference and private mode/credential fingerprint in their existing
JSON; public billing payloads never expose those verification fields. Legacy
attempts retain a bounded quantity/time match. Late expiration cannot unlock a
newer request or overwrite a confirmed attempt.

Status/continue/restart return safe actionable errors. Portal failures stay in
the billing workspace (JSON for interactive actions, redirected validation error
for direct navigation). Returning from browser history refreshes authoritative
billing state. Production credential/configuration repair remains an operator
responsibility; swapping keys cannot prove that an earlier payment failed.
No database migration, live payment, paid customer reset or automatic migration
is part of this repair. Evidence and rollout: [billing recovery audit](audits/2026-10-15-billing-recovery/README.md).

## ADR-069 — Customer-first recovery and shared product notices

- Status: Accepted
- Date: 2026-10-15
- Basis: Product owner reports that Start again/status still dead-end on a payment mode mismatch, repeated clicks hit throttling, and touching buttons/yellow error banners undermine customer trust. Requests durable rules for every future prompt.
- Requirements: FR-01/19/20 and product-wide experience under FR-01–20; refines ADR-068 without weakening financial history or live payment verification.

Every task follows the customer-first acceptance and notification composition
rules in AGENTS.md, docs/design-system.md and quality-and-testing.md. A recovery
button must advance the customer, infrastructure fixes belong to operators,
input survives failure, and local versus deployed evidence is explicit.
AppNotice supplies restrained inline heading/icon/body/actions. Shared Feedback
alerts, ToastRegion, workspace notices and changed billing feedback reuse it.
Actions wrap with 10px gaps and 14px separation from text. Existing bespoke module
notices adopt this contract when touched; no unverified universal migration is
claimed.

A stored cs_test_ Checkout cannot move real money. When it blocks an unconverted
trial under live credentials, status or restart may retire it locally, retain its
original test-customer reference on the historical attempt, and detach only the
test setup binding. This is permitted only with no provider subscription,
confirmed attempt, paid capacity/rate card, saved card, customer balance, invoice,
future schedule or other unresolved/confirmed checkout. The trial and all records
remain. The next purchase requires a fresh server review and confirmation, then
creates the current live customer/session through the existing provider. Late
retired test events cannot rebind the live customer. Unknown preparations,
cs_live_ sessions, paid accounts and unresolved live outcomes are never discarded.

The previous unprefixed numeric throttles shared a user/domain key across billing
actions. Replace capacity status/restart/review/confirm with separate named
per-user limits. Status cannot spend restart/review budget. The frontend checks
once on entry, does not poll repeatedly, disables duplicate in-flight actions,
honors Retry-After with a visible wait and preserves editable estimates. A
persistent 409/missing original object offers support with a safe reference and
hides ineffective Start again; a later explicit check can observe an operator fix.
Do not ask customers to restore credentials or expose raw provider diagnostics.
Close the review dialog before departure. A transient per-business session marker
causes one authoritative document reload on return from Stripe, avoiding stale
Inertia history props; no quantities, prices or payment details are stored.

Add a read-only billing:inspect-checkout operator command showing modes, status,
config-cache state and whether the private environment-file secret matches
configured values. No secret/fingerprint/provider ID/customer data is printed;
no payment/configuration is changed. Source-of-secret and original-account repair
remain operator responsibilities. No schema migration or price change is needed.
Evidence: [customer billing recovery audit](audits/2026-10-15-customer-billing/README.md).

## ADR-070 — Reviewed public Help Center with contextual workspace guidance

- Status: Accepted
- Date: 2026-10-24
- Basis: Product owner explicitly requests complete, accurate self-service help,
  genuine application captures, smart search and links to existing workspaces.
- Requirements: FR-21 and existing FR-01–FR-20; additive product guidance only.

Store reviewed article metadata and section Markdown in version-controlled JSON
under `content/help`, with category/action/synonym policy in `config/help.php`.
Use the installed Markdown renderer with raw HTML stripped and unsafe protocols
disabled. Publish only valid, published, non-future files. This fits the existing
modular monolith and makes workflow changes and content review one change; an
additional authoring panel, external search vendor or generative support service
is not justified for the current corpus. Revisit indexed search after measured
request latency or corpus size warrants it, retaining the same public contract.

Use `/help`, `/help/category/{category}` and `/help/articles/{slug}` on the primary
website/application origin. Keep search queries and authenticated handoffs
noindex; include only published help pages in the existing sitemap. Meaningful
initial HTML must remain readable when optional SSR or JavaScript is unavailable.
The separate booking origin retains its existing business-slug contract; this
change does not reserve `help` or invalidate existing booking addresses. Public
Help entry links belong to the primary website/application. Any future booking
host alias requires checking current/previous business slugs before reservation.

Contextual Help shares reviewed topic suggestions. Article actions resolve only
active owned memberships, show a choice for multiple workspaces, explain denied
access and then use existing protected destinations. Public help never changes
membership, subscription or branch authority and never searches tenant data.

Use synthetic isolated SQLite fixtures with fake communications and no worker,
real browser captures and a local media manifest (dimensions, capture date and
checksum). Screenshots must be reviewed with the instructions. Missing/stale
assets fail the maintenance gate; no invented screenshot replaces them. Preserve
existing unavailable UI/provider boundaries in customer guidance and the coverage
audit. This authorizes isolated verification alongside existing release work;
none of the production chargeability or provider gates is waived.

Feedback accepts a bounded yes/no answer, deduplicated by an opaque session HMAC
per article revision, without account, tenant, IP or free-text fields. Operators
receive aggregate counts through `help:feedback`. Apply the additive migration
before deploying feedback. Search and feedback have independent rate limits;
the interface respects Retry-After and stops repeated suggestion requests on
persistent errors. No analytics vendor, support ticket or outbound message is
introduced.

See [Help Center specification](modules/help-center.md),
[coverage and local evidence](audits/2026-10-24-help-center/README.md) and
[maintenance runbook](audits/2026-10-24-help-center/maintenance.md).

## ADR-071 — Recover checkout preparation and project paid capacity atomically

- Status: Accepted
- Date: 2026-10-25
- Basis: Repeated owner-reported payment dead ends; supplied production diagnostics show a submitted test preparation with no locally saved session, matching configured mode and cached secret.
- Requirements: FR-01, FR-19, FR-20; extends ADR-068/069 without repricing existing subscriptions.

An explicit Start again may retire unfinished test preparation on an otherwise
unconverted trial, including same-mode/test-account changes. Apply the existing
strict exclusion of subscription, capacity, invoice, card, balance, schedule and
other active/confirmed checkout history. Retain the old quote, attempt and test
customer evidence; require a fresh review and confirmation. Never infer that a
live uncertain operation failed from a missing local session or another account's
404. Genuine live/unknown outcomes still require authoritative provider evidence.

A first-invoice decline remains retryable in the original owned checkout. Repair
legacy prematurely failed attempts only after reading their original owned session
and finding the exact still-submitted request. Delayed-method failure keeps the
original purchase unresolved until provider verification; a completed Checkout can
offer only its verified existing invoice, using the shared HTTPS host allowlist.
Only terminal unpaid `incomplete_expired` evidence releases an unconverted initial
subscription binding, retaining all invoice/attempt history and an audit event.

Apply subscription activation and capacity under one locked transaction. Normalize
API observation time to database whole-second precision. A current authenticated
snapshot may replace same-second state; an equal/older signed event must not
reapply stale capacity. Tests must include fractional clock observations rather
than exclusively frozen whole seconds.

For a submitted paid change, status recovery reconciles first. If still unresolved,
resume the original authorized request under its original idempotency keys only
within 23 hours, with unchanged current items and billing period. A partially
created renewal schedule must match the object recovered by that original create
key before phase updates. Never replace a key to escape a cached Stripe failure;
older/ambiguous outcomes need operator reconciliation. Pending payment directs the
customer to Invoices; existing capacity remains until payment/renewal verification.

`billing:inspect-checkout` accepts either a Business public ID or exact checkout
Support reference. Default diagnostics remain local/read-only. Optional `--provider`
reads the current customer and both cadence price mappings, outputs redacted
classifications, and never provisions catalog objects, subscriptions or charges.

See [billing specification](modules/subscription-billing.md#checkout-and-payment-lifecycle-recovery-adr-071)
and [verification evidence](audits/2026-10-25-billing-flow/README.md).

### ADR-071 diagnostic follow-up — 2026-10-25

Preserve a redacted checkout creation error classification on the pending attempt
and the original provider exception as the cause of the safe service exception.
The read-only inspector may report HTTP status, validated code and an allowlisted
parameter. Raw messages/bodies, keys and contact details stay out of the attempt
and customer responses. A private provider request reference in server logs lets
an operator investigate the original rejection. Clear stale details when the
original retry succeeds. This adds diagnostic evidence, not production payment
certification or a new billing system.

### ADR-071 catalog recovery follow-up — 2026-10-25

Production diagnostic evidence confirmed that the current test account can read
the customer but cannot read any of the six mapped subscription prices. Recover
with the existing explicit catalog provisioning/verification command; never
create prices automatically during customer checkout or reset paid records.
Retain old immutable cards and pending quotes. Restart an eligible test
preparation and obtain fresh owner review/confirmation to use current mappings.

Explicit environment price overrides remain authoritative. Preflight all of them
before provisioning writes and identify missing variable names without printing
IDs. The inspector distinguishes unavailable catalog objects from incomplete
provider reads and supplies the matching operator next step. Local monthly/annual
account-switch regressions must preserve old paid terms and verify the repaired
trial opens one checkout. Actual production repair is not claimed until the
operator setup succeeds and the owner reaches checkout in the intended account.


## ADR-072 — Automatically confirm the payment return

- Status: Accepted
- Date: 2026-10-26
- Basis: Owner reports that returning from Stripe shows an unfinished checkout and requires a manual billing-status check.
- Requirements: FR-01, FR-19/20; refines ADR-068/069/071. Supersedes ADR-069's single-entry-check rule only for bounded follow-up of a payment already processing.

Show Checking your payment on entry and automatically display the authoritative
result. A correctly owned stored confirmed/applied return shows success immediately,
even when webhooks beat browser navigation. Pending payments follow six bounded,
non-overlapping checks over 30 seconds. Stop on an error, navigation, an open
Checkout, a payment requiring action or a terminal result; keep Retry-After and
all customer work. Do not describe a processing payment as an unfinished checkout.

Automatic verification reads existing owned Stripe objects through the existing
projector; it cannot create/replay a Checkout or customer, submit subscription
changes, or expire a payable session. Preserve the approved guarded test-only
retirement and all live-payment, tenant, idempotency and append-only history rules.
URL flags alone are not proof. Refresh paid quantities/access automatically after
confirmation. Keep ordinary workspace GETs free of provider calls and avoid a
second legacy status loop for the same capacity checkout return.

Persist this customer-journey rule in AGENTS.md and the shared notification
contract. Local automated verification is separate from deployed payment evidence;
see [return verification](audits/2026-10-26-payment-return/README.md).

### ADR-072 confirmed-state consistency follow-up — 2026-10-28

Owner supplied screenshots showing an active purchased subscription and a paid
invoice alongside an unfinished-checkout notice. Repair stale submitted checkout
requests from strictly matching, already-confirmed local Stripe attempt and
subscription evidence. Scope matching includes business, provider subscription,
plan price, immutable rate card/fingerprint, cadence/currency, quantities and total.
Require a confirmation date and active/cancel-scheduled subscription. An invoice
or active status alone never authorizes dismissal of another unpaid checkout.

Complete only the local workflow record, clear obsolete continuation and append
an audit event. Reuse the repair on billing presentation and recovery/new-review
paths; make no provider calls for a proven local completion and preserve all
financial history/versioning. In the UI, a same-request confirmed/applied refresh
replaces stale waiting/error state, while a different request remains protected.
Offer payment continuation only for a verified open checkout. Maintain the shared
customer notification contract; do not replace the bug with a misleading success.
Local reproduction/verification is separate from deployment and browser evidence:
[audit](audits/2026-10-28-confirmed-checkout/README.md).

### ADR-072 terminal provider-state follow-up — 2026-10-31

Preserve confirmed terminal cancellation when Stripe events share a timestamp
second or later reads contain pre-cancellation active state. Stripe cannot
reactivate that same canceled subscription ID. Later outstanding-invoice
collection still records financial evidence without reopening access. This is
a consistency correction, not an immediate-cancellation policy or a change to
the ability to undo cancellation before the current period ends.
See [audit evidence](audits/2026-10-31-stripe-production/README.md).

### ADR-072 database JSON identity root cause — 2026-10-28

The new-account report persists after the stale-record follow-up. A fresh review
and Stripe SDK confirmation regression reproduces the failure for 2 locations and
6 staff in both cadences when rate-card JSON keys are normalized as MySQL stores
them: payment becomes active but the original checkout remains submitted. A
read-only local MySQL JSON expression independently confirms key reordering.
Earlier SQLite fixtures preserved insertion order and missed this boundary.

Reuse the existing verified rate card's stored fingerprint in quotes instead of
rehashing decoded JSON. Match provider projection/schedule/change identity by the
same immutable rate-card ID. Preserve original fingerprints, price IDs and terms;
there is no canonical-hash migration, new pricing layer or billing flow. Repair
already-confirmed affected requests using the exact saved or known legacy decoded
fingerprint of that same card, retaining all financial and ownership guards.
Document red/green fresh-flow, existing-account, no-op/expansion and renewal tests
in the [root-cause record](audits/2026-10-28-billing-json-identity/README.md).

## ADR-073 — Production SMS service routing and compact shared configuration

- Status: Accepted
- Date: 2026-10-29
- Owners: Product / Engineering / Operations
- Requirements: FR-13; retains ADR-041/054/067 and OPEN-11/15.

The product owner selected SMS for launch and WhatsApp requirements only, requested
real production transport locally, and asked for one small environment block to
copy to the live server. Keep two credentials (account SID/Auth Token), one SMS
number, one Messaging Service SID, one public webhook base, and the existing two
explicit live controls. Use the same token for signature verification. Retain
legacy advanced/test settings in code for compatibility, not in the launch block.

Send platform SMS through the service's pool without forcing `From`; the approved
number supplies markets without alphanumeric support. Keep the existing public
callback paths and add signed API-style aliases. Do not disable signature checks
for TLS termination. Captured sender changes retire old profiles and preflight
suppresses stale queued work rather than promoting simulated messages to real
delivery. Persist safe carrier error codes, reconcile early callback races and
keep final delivery monotonic across duplicated/out-of-order notifications.

User authorized one test to their controlled Indian phone and confirmed receipt;
Twilio reported delivered. Their existing toll-free number was added to the
service but remains IN_REVIEW. No approval bypass, WhatsApp enablement, country
registration certification or deployment is implied. Existing legal, country,
consent, credit and release gates remain. See the [audit/handoff](audits/2026-10-29-twilio/README.md).

## ADR-074 — Optional salon presentation and completed-visit reviews

- Date: 2026-10-29. Status: Accepted from the product owner's request to study
  Fresha's supplied salon/booking pages and adapt photos, professional profiles
  and reviews to ClipperDesk, excluding payment gateway collection.
- Requirements: FR-02, FR-05, FR-09, FR-13, FR-19. Product owner: the requesting
  ClipperDesk owner; implementation and verification owner: Engineering.
- Promote only appointment-bound reviews from Phase 2. Success means a business
  can publish/book with zero uploaded photos, optionally present its own gallery
  and team portraits/bios, and collect one authenticated-by-secure-link review
  after each completed visit with no password or payment dependency. Existing
  local booking/self-service evidence is the prerequisite; deployment, payment,
  production concurrency, communications and legal gates remain unwaived.
- Keep one booking implementation and scheduling authority. Public presentation
  adds an ordered business-wide gallery, team cards and opted-in reviews. Images
  remain optional and tenant-private at rest, validated as raster images, with
  authorized edits/preview and publication/visibility checks at delivery. A clean
  text/initials fallback replaces implied salon stock photography. Existing titles
  and biographies are reused; no invented years of experience or ratings.
- A review requires a completed appointment and its secure view/review capability.
  Lock and recheck tenant/appointment eligibility when saving; a unique visit
  constraint and replay handling prevent duplicates. Operators can copy a scoped,
  expiring review link and read feedback only within their existing appointment
  permissions. Public consent defaults off. Public projection uses initials,
  review date, rating and escaped plain text, with no client contacts, appointment
  reference or service/treatment disclosure. All opted-in ratings contribute;
  owner rating-gating, fabricated reviews and selective suppression are excluded.
- No automatic email/SMS review outreach, marketplace, AI review summary,
  memberships, group booking, campaigns, external review import or payment UI is
  promoted. Existing feedback communications remain marketing and disabled.
  Clients may withdraw public-display consent through their review-purpose link;
  the submission and original consent evidence remain available privately.
  Any later moderation/removal, external review provider, review content editing
  or automated outreach expansion needs an explicit privacy/retention contract.

## ADR-075 — Discoverable optional setup and recoverable platform failures

- Date: 2026-10-29. Status: Accepted from the owner's setup screenshots and
  requests for a succinct, professional interface with visible photo previews.
- Requirements: FR-01/02/03/05/09/19. Clarifies ADR-048/056/063/064/069/074;
  existing publication, financial, permission and release gates remain in force.
- Put **Photos & branding** directly in Business setup navigation. Discovery does
  not make images required: logo, cover, gallery and portraits remain optional.
  Show saved/selected previews and explicit saves with compact editing controls.
  Distinguish loading, genuinely empty and unavailable photos. A platform failure
  must not masquerade as an empty gallery or offer repeated ineffective reloads;
  preserve work and offer reachable support with a safe diagnostic reference.
- Remove the manually entered reason for ordinary staff profile status and work
  branch changes. Keep revision/tenant/branch checks, active-hold protections and
  existing appointments. Audit the actor, before/after profile and work branches,
  and retained appointment IDs automatically. Schedule exceptions and removal of
  service qualifications used by future visits retain their existing reasons.
- Signed-in owners may see non-binding estimates from approved current software
  terms before the matching current Stripe rate cards are verified. Public
  catalogue eligibility and purchase/review authority still require verified
  immutable mappings. A retained verified older revision does not establish that
  current terms are purchasable. Preserve all retained cards and paid history.
- Keep Google address search on the product's supported explicit light surface.
  Authentication denial is terminal for that page: stop search/map recovery loops,
  preserve typed/saved address text and offer manual entry. An actual denied
  referrer is configuration evidence, not proof that quota is exhausted. Verify
  the exact browser origin before changing Cloud settings. Separate restricted
  development keys remain the policy; creating a key or changing restrictions
  requires action-time confirmation. The initial diagnostic inspection was
  read-only; the owner subsequently approved the scoped local-key recovery below.
- Primary local MySQL recovery applied exactly `2026_10_29_000002_create_client_reviews`
  and `2026_10_29_100000_create_business_photos_table`; the unrelated pending
  Help-feedback migration was left untouched.
  Local Stripe test setup produced two current monthly/annual cards, retained two
  older cards and verified six current test Prices. No paid terms, charges or
  production deployment were changed. The original reviewed browser key allowed
  local port 8027 while port 8000 was denied.
- With explicit owner approval, created exactly one **ClipperDesk – Local Browser**
  key in the existing project, with saved/read-back website restrictions limited
  to `http://127.0.0.1:8000/*` and `http://127.0.0.1:8027/*`, and API restrictions
  limited to Maps JavaScript API and Places API (New). The original production key
  was unchanged. Only the ignored local environment key value changed; every other
  parsed setting was retained and the temporary key file was deleted. Client/SSR
  builds passed; safe diagnostics confirmed the current built key and uncached
  configuration. A temporary same-origin Chrome probe at port 8000 displayed
  real CN Tower predictions and selected/fetched the address without provider
  errors or saved business/client data. This is local key/origin verification,
  not complete reported-account certification or deployment. Prior regression
  results were not rerun for this key-only update.
  [Reproduction, recovery and remaining limits](audits/2026-10-29-setup-recovery/README.md).

## ADR-076 — SMS allowance follows available quota, not the client's phone country

- Status: Accepted
- Date: 2026-10-31
- Owners: Product / Engineering / Operations
- Requirements: FR-01/13/19, PRD §9. Supersedes destination-prefix eligibility
  and destination credit multipliers in ADR-054/073 and OPEN-22; other billing,
  provider and consent controls remain.

The owner rejected country restrictions within the plan: a client travelling to
a US salon with an Indian number must be able to receive its appointment text.
Use the business's available included/prepaid allowance for all valid SMS
destinations. One rendered GSM/Unicode segment costs one credit regardless of
country; the platform absorbs destination-specific provider cost differences.
The business's sales currency, pricing market and the phone prefix do not select
SMS eligibility or a multiplier. This is not unlimited messaging or automatic
credit purchasing, and does not bypass Twilio's own delivery requirements.

Apply this rule to existing and new subscriptions at delivery time. Do not
rewrite paid capacity snapshots, verified rate-card terms/fingerprints, Stripe
Prices, invoices, historical debits or reservations. Retain `sms_routes` as
deprecated historical pricing metadata so existing verified billing identity
remains stable; delivery never consults that field. No subscription migration,
Stripe reprovisioning or additional environment switch is required.

Reserve the whole segment quantity atomically before the provider call, consume
included credits before prepaid, preserve consent/tenant/restriction checks,
release definitive pre-send failures idempotently and retain credits for unknown
outcomes without resending. Previously suppressed historical messages are not
automatically replayed when this policy is deployed.

The prior production diagnosis remains factual for the deployed revision. Its
requirement for separately approved Indian subscription coverage is superseded
by this explicit owner decision. Production SMS delivery under this correction
still needs deployment and an authorized booking rehearsal; the earlier direct
Twilio test is not a booking-flow certification.

## ADR-077 — Batch salon photos and understandable booking preferences

- Date: 2026-11-01. Status: Accepted from the owner's photo-upload and booking
  preference screenshots and explicit usability requests.
- Requirements: FR-02/03/09/19. Clarifies ADR-074/075; no payment, publication,
  entitlement or Phase 2 expansion.
- Offer multi-file selection and drop, local thumbnails, optional descriptions
  and one explicit Add action. Keep the eight-photo limit. Send selected images
  sequentially through the existing authorized command, using each confirmed
  revision and one stable file/description/retry key per image. Stop on a failure;
  retain remaining work and honor cooldowns. Never resend confirmed files or
  automatically retry unknown outcomes. Known-invalid images must be removed
  before continuing; leaving the component stops later uploads.
- Keep working booking controls and explain their actual effect: booking-page
  price labels, client eligibility, online change deadline, waitlist offers per
  released opening and the lifetime of newly issued private appointment links.
  Price labels do not change amounts; staff price differences may still require
  a starting price. Consultation-only restricts new clients to services flagged
  as consultations, not proof of a completed prior consultation. Waitlist offers
  are not guaranteed notification delivery. Public booking URLs are not expiring
  private appointment links; short action/review links keep their existing limits.
- Hide the saved staff-gender-request checkbox: it has no booking or scheduling
  consumer today. Preserve the saved value and server contract. This is a clear
  existing FR-09 implementation gap, not an invented working preference; any
  future interface must connect to reviewed behavior before being shown.
- Group advanced waitlist/link settings under one named disclosure; preserve
  custom saved durations, validation, revisions, authorization and audit behavior.
  [Local verification and deployment limits](audits/2026-11-01-gallery-booking-preferences/README.md).

## ADR-078 — Platform subscription welcome discounts and private coupons

- Date: 2026-11-01. Status: Accepted from the owner's explicit request and
  confirmation: first payment only, new subscriptions only.
- Requirements: FR-01/19/20, PRD §9. Platform administrators manage percentage
  seasonal offers and manually shared coupon codes under Payments → Discounts
  & coupons. This does not discount salon appointments, SMS packs, existing paid
  subscriptions or renewal invoices. No recurring price or invoice is rewritten.
- Offer controls: name, 1–90% saving, enabled state, optional UTC start/end and
  coupon combination permission. The highest eligible automatic offer wins;
  ties use oldest ID. One coupon either replaces that offer (default), or applies
  sequentially to its reduced amount with explicit permission: 20% then 10%
  saves 28%. Integer half-up minor-unit rounding happens at each step.
- Coupon entry accepts manual codes or an explicit Generate code action. Opening
  or editing an offer never generates a replacement code. Codes normalize to
  uppercase; database uniqueness and server validation remain authoritative.
  Editing a code affects new reviews; already submitted checkouts retain snapshots.
- Review preserves gross recurring total, each offer and saving, first payment
  and regular renewal amount. Claim revalidates current offers under the business
  billing lock before submission. Submitted requests use their immutable reviewed
  snapshot, stable attempt and provider keys even after an admin disables the offer.
- Stripe receives a once-only fixed discount exactly equal to the reviewed saving,
  one redemption per checkout-specific coupon. That provider limit is not a global
  campaign use limit. Campaigns are reusable until disabled/expired; no per-person
  code binding or redemption quotas are promised in this simple release.
- Owner-directed presentation refinement on 2026-11-01: promotional information
  belongs inside price cards, with gift icon and percentage badge. It is not a
  workflow notice. Lead with the first payment, keep regular renewal/tax wording
  and exact saving rows; remove procedural marketing paragraphs. Coupon input
  is an optional disclosure immediately before review. Financial rules unchanged.
- Seed Holiday welcome at 20%, 2026-11-01 inclusive to 2027-01-01 exclusive, UTC.
  A fixed seed identity preserves administrator edits, renaming and disabling on
  repeated deployment. Seeder does not contact Stripe or alter existing customers.
- Historical Larafast billing_coupons is not the current capacity promotion
  authority. Keep its records. New promotions and snapshots are retained; deletion
  and destructive rollback are disabled. Audit records capture administrator writes.
- Live discount checkout, real tax/renewal, provider outage and concurrency evidence
  remain deployment certification work; local fixtures and mocked SDK are not live
  payment evidence. No existing launch gate is waived.

## ADR-079 — Consent-based Google Analytics for public acquisition

- Status: Accepted for the narrow owner-requested integration; external setup
  and deployed evidence are recorded separately in the audit.
- Date: 2026-11-02
- Authority: explicit product-owner request to set up Google Analytics on
  ClipperDesk, including required Google, Forge and repository changes.
- Requirements: PRD sections 4, 12 and 15; FR-01/19; ADR-024; OPEN-12.

Use Google Analytics 4 only for guest visits to the explicitly curated public
marketing pages, approved CTA actions and monthly/yearly pricing choices.
No tracking on authenticated, registration, booking, secure-link, Help search,
admin, platform, API or error surfaces. Exclude arbitrary dynamic slugs, queries,
fragments, referrers, tenant/user IDs, form input and commercial/customer records.
Use a separate ClipperDesk account/property; preserve unrelated Google accounts.

Implement basic prior opt-in: no Google tag or measurement request before
Accept analytics. Reject analytics is equally accessible; a public footer
Analytics preferences control allows withdrawal. GPC/DNT prevents collection.
Version the choice and expire it after six months; restrict host-only analytics
cookies to 60 days. Discard pending events when consent or route changes; disable
collection before navigation and unload the tag before private destinations.

Use only the necessary server-side measurement-ID environment value, default
empty. Fail closed outside the primary production host, for signed-in visitors,
invalid configuration and excluded routes. Never put credentials in the client.
Disable automatic pageviews/enhanced measurement, Google Signals, ads
personalization, user-provided data and advertising links. Send sanitized manual
pageviews to avoid duplicates during Inertia navigation. Provider retention is
two months for user/event data, with activity-based retention reset off;
aggregated reporting has different retention and must not be promised to expire.

The operator remains responsible for privacy requests through the existing
support@clipperdesk.com intake. Withdrawal stops future sending and removes
accessible integration cookies; it does not promise retroactive deletion.
Operators review Analytics data-deletion requests when identifiable/applicable.
The existing privacy notice is updated to version 1.2. Do not claim this work
establishes counsel approval, a DPO appointment, transfer certification or any
other launch gate. Google terms acceptance and operator country require direct
owner confirmation; record the actual outcome in the audit.

### ADR-079 wording clarification — 2026-11-02

The owner approved **Cookie settings** as the public footer label replacing
**Analytics preferences**. It opens the same optional analytics choice and
withdrawal control; consent behavior, tracking scope and provider configuration
remain unchanged. Historical audit observations and screenshots retain the label
that was visible when they were captured.

## ADR-080 — Owner-authorized public Privacy Policy and Terms publication

- Status: Accepted for the requested public presentation; not a finding of legal
  review or completion of operational launch gates.
- Date: 2026-11-02
- Authority: product owner explicitly stated Clipperdesk is live and requested
  removal of the privacy and terms review/non-effective notices and suitable
  updates to their visible publication metadata.
- Requirements: FR-01/19; PRD sections 12/15; ADR-062; OPEN-13.

Publish Terms version 1.0 with last-updated and effective date 2 November 2026.
Remove draft-only statements and the review-status field from that published
page. Preserve the existing product, payment, retention and mandatory-rights
boundaries; do not invent a jurisdiction, liability cap, indemnity or support
SLA. The owner request does not establish that counsel approved those matters.

Privacy remains version 1.2, including ADR-079's Analytics disclosure. Remove
its public review banner and display the owner-authorized 2 November 2026 date.
Keep that public date separate from `LEGAL_PRIVACY_EFFECTIVE_DATE`, approval,
operations/provider verification, the privacy release checker and the existing
indexation/sitemap gates. Do not set or imply any of those approvals from this
request. Existing environment values remain authoritative and unchanged.

The separate Refund Policy remains a review document. This decision does not
alter prior transaction records, introduce retrospective acceptance, certify
live payment/refund operation or waive any other OPEN-13/compliance gate.
Record local and deployed evidence separately in the publication audit.

## ADR-081 — Compact first-party SMS capabilities

- Status: Accepted
- Date: 2026-11-05
- Authority: Owner requested secure, unique, substantially shorter SMS booking
  links, allowing a longer code than 6–7 characters when security requires it.
- Requirements: FR-09/10/13/19; refines ADR-064/067 without enabling a channel or
  changing consent, financial policy or business-owner controls.

Use `https://clipperdesk.com/s/{code}` in production, using the configured
application origin locally. Generate 128 random bits with `random_bytes(16)` and
encode as 22 URL-safe characters. Keep the existing action row as the tenant,
target, purpose, expiry, revocation and consumption authority, with a unique
SHA-256 token hash and encrypted recoverable token for stable SMS retries.
Neither credential is serialized to workspaces. Generate lazily under a row lock
so old queued messages require no bulk rewrite; already-sent signed links and
email links retain their behavior. Codes contain no customer or sequential data.

Route directly into the existing action handler with IP throttling and private,
no-store, no-referrer/noindex responses; never shorten arbitrary external URLs.
Preserve single-use appointment bridges, reusable receipts, and explicit atomic
waitlist POST claims. SMS with an appointment action keeps address/arrival/maps
on the existing appointment page instead of appending another long URL. Render
before SMS credit reservation. No third-party service, extra environment
credentials, provider shortener or tracking is introduced.

Security rationale: [OWASP token generation](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html)
supports CSPRNG/128-bit generated credentials; the specific 22-character format
is our implementation choice. [Twilio branded-link guidance](https://www.twilio.com/docs/api/errors/30525)
supports first-party branded URLs rather than public shared shorteners.
[Implementation and evidence](audits/2026-11-05-sms-short-links/README.md).

## ADR-082 — Receipt PDF delivery and completed-visit review emails

- Date: 2026-11-05. Status: Accepted by explicit product-owner authorization.
- Requirements: FR-09, FR-13, FR-15, FR-19. Supersedes ADR-074's prohibition
  only for appointment-bound review email. Broader marketing remains deferred.
- Reuse the communication intent/message/attempt pipeline and existing policies.
  Receipt automatic email defaults on to preserve behavior; review automatic
  email defaults off, including existing businesses. An enable timestamp excludes
  older completed visits; no scan or bulk backfill occurs. Consent is never inferred
  from a business switch. Review invitations retain marketing classification,
  subscribed status, explicit email selection and suppression requirements; their
  narrow legal-basis marker does not enable feedback/rebooking campaigns or SMS.
- Manual and automatic sends serialize on the appointment and reuse a stable
  intent. Once requested, repeated clicks do not create another send, including
  provider-uncertain outcomes. Recovery uses tracked delivery/support rather than
  another charge or untracked resend. Missing email/permission blocks the request.
  Queue delivery rechecks preferences, automation (for automatic sends), completion
  and existing feedback. Manual delivery works when automation alone is disabled.
- Use installed Browsershot/Puppeteer with managed Chromium for PDF generation,
  sharing escaped Blade receipt presentation. New snapshots retain issue locale
  and zone; older immutable snapshots use the existing route fallback. Snapshot
  content/hash and existing links are unchanged. A4 has repeating table headers,
  page numbers and grouped totals. PDF rendering failure occurs before provider
  submission and may retry; uncertain SES acceptance still requires operator review.
- One issued receipt remains original history, even after refunds; this does not
  introduce provisional receipts or rewrite outstanding historical snapshots.
  No launch-market tax/legal approval or live delivery certification is implied.

## Open decisions

### 2026-11-07 Hamilton founding-customer pilot offer

The founder authorized a three-month trial and assisted shop setup for initial
customers recruited by their sales partner in Hamilton. This is a targeted sales
offer, not a change to the default 14-day signup trial. No software configuration,
account extension, deployment or regional launch gate is changed by documenting
it. See the [partner brief](sales/hamilton-partner-sales-brief.md).

Before enrollment, Founder/Operations must resolve the exact Hamilton geography,
eligibility, calendar-month versus day interpretation, account activation and
expiry, allowances, setup/migration scope and costs, support ownership and
end-of-trial account options. Partner compensation and negotiating authority also
remain unspecified. Existing regional, privacy, messaging and payment gates apply.

2026-11-01 Stripe audit follow-up to **OPEN-13**: the SaaS billing dispatcher
does not yet project charge refunds, disputes or early fraud warnings. Finance/
Product must approve the access/refund/recovery response before these events can
automatically change an entitlement. Implementation must resolve subscription
ownership through Stripe's invoice/charge graph and retain append-only evidence.
Live key configuration, public catalogue readiness and a signed 204 callback do
not waive this existing financial-operations launch gate.

| ID | Decision needed | Why it blocks or influences work | Resolve by | 2026-08-16 release disposition |
| --- | --- | --- | --- | --- |
| OPEN-09 | Approve the Prompt 00 remove/replace inventory for Larafast marketing, roadmap, AI, content, and superseded provider surfaces | Reduces dead code and prevents confusing product ownership | Before cleanup is authorized | **Retained.** Legacy surfaces remain quarantined; no destructive cleanup was silently assumed. Medium launch risk owned by Product/Engineering; named owner and date unassigned. |
| OPEN-10 | Final data retention and anonymisation schedule plus destructive executor authorization | Client privacy, attachments, audit events, financial records, and closure are safely bounded by ADR-018 but cannot complete destructive requests | Before destructive processing or paid public launch | **Retained; Critical blocker.** Requires jurisdiction-appropriate privacy counsel and Product approval; the Canadian operator/contact facts in ADR-062 do not authorize destruction. No waiver or expiry exists. |
| OPEN-11 | Complete counsel-led ClipperDesk trademark clearance and acquire the approved production domains | ADR-027 selects the identity, but naming rights, domain ownership, sender authentication, and defensive domains are external launch controls | Before public launch, outbound production mail, or printed collateral | **Retained; Critical/High blocker.** Product/Operations and counsel must approve and acquire the final public, app, and booking domains; configuration defaults do not establish ownership. No waiver or expiry exists. |
| OPEN-12 | Approve marketing attribution/analytics provider, consent class, retention, and accountable privacy owner | Phase 1.5 can implement a bounded first-party event contract, but cannot load a tracker, advertising pixel, fingerprinting, session replay, or claim consent/retention approval | Before enabling any third-party marketing measurement or paid acquisition | **Partially resolved by the owner-directed ADR-079.** GA4 is selected for prior-opt-in guest public-page/CTA/interval measurement, with bounded fields, short retention and the existing privacy intake. Broader attribution, advertising, cross-service identities and regional counsel/transfer review remain open; no privacy-owner appointment or legal approval is inferred. |
| OPEN-13 | Approve the legal operator/contact suite and live refund responsibility for subscription and appointment payments | Stripe India website review expects public Terms, Privacy and Return/Refund/Cancellation URLs plus customer-service details and processing timelines; the current appointment adapter records internal refunds but has no certified provider refund executor or approved live merchant-of-record/connected-account allocation | Before legal documents become effective or any live payment is accepted | **Open; Critical/High blocker.** Legal/Product must approve operator, address, governing/dispute/liability terms and version acceptance; Finance/Operations must own direct support, request/decision/submission timelines, and the live Stripe subscription and appointment refund/reconciliation paths. Terms/refund remain non-effective review documents. ADR-062 supplies operator/contact facts and an approval-gated privacy notice; remaining contract, operations and refund approvals are retained. |
| OPEN-14 | Restore the remaining module documentation referenced by AGENTS.md | Communications, dashboard, product experience and scheduling specifications are restored; other domain module documents remain absent or partial | Before the next affected domain scope change | **Partially resolved.** `docs/modules/communications.md`, `dashboard.md`, `product-experience.md` and `scheduling-operations.md` are restored; `client-records.md` now restores CRM, history, governed commands and operational linkage (ADR-046). `checkout-sales.md` now restores checkout, payments, receipt and refund boundaries (ADR-047). `team-availability.md` now restores workforce, reviewed schedule/service changes and read/access boundaries (ADR-048). `services.md` now restores the catalogue, reviewed commands and booking/commerce boundaries (ADR-049). `business-setup.md` now restores initialization, operational readiness, reviewed edits and explicit publication (ADR-053). Restore the remaining affected specifications before changing those domains. |
| OPEN-15 | Approve the exact first-country launch order and complete regional legal, commerce and public-site profiles | The product owner selected the United States, Canada, the United Kingdom and selected Europe as target markets, while current commerce/public content still contains India/INR/`en-IN` assumptions; SMS registration, consent language, quiet hours, taxes, receipts, currency and privacy obligations differ by country | Before any paid regional launch or live mobile sending | **Open; Critical/High blocker bounded by ADR-039.** Product must choose the first exact countries and supported currencies. Named legal/privacy/finance owners must approve country-specific policies and provider registrations before live enablement. |

| OPEN-16 | Complete and certify the public deposit payment interface | The deposit API returns a Stripe PaymentIntent client secret, but the public Vue flow has no payment element or return/status recovery. The server correctly requires paid deposit evidence; a misleading “collect later” message hid this gap. The UI now shows the amount and directs clients to the business without claiming confirmation. | Before enabling deposit-required self-service booking in production | **Open; high blocker.** Engineering/Finance must complete the provider UI and recovery journey under FR-12 and FR-14, restore the affected module specifications under OPEN-14, and meet OPEN-13/live payment gates. No policy or paid-confirmation bypass is approved. |

| OPEN-17 | Define temporary queue holds/steps-away behavior and any priority policy | The existing queue has no persisted hold/VIP/accessibility-priority state. Adding one requires explicit ordering, estimate, expiry and audit semantics so staff cannot silently skip clients. | Before adding those workflows | **Open; not a release waiver.** The redesigned board retains recorded reorder, preferred staff, assignment, notification and reasoned leaving under ADR-045. No new priority is inferred. |

| OPEN-18 | Define compensating amendments/cancellation of a saved basket and the controlled payment-allocation transfer interface | Existing SaleLine/PaymentTransaction records are immutable; the workspace freezes reviewed rows. An inventory shortfall after saving cannot be repaired by silently rewriting paid or unpaid history. The legacy internal allocation-correction service has no approved operational UI contract. | Before exposing those commands | **Open; bounded by ADR-047.** Product/Finance/Engineering must define permission, source/target version checks, settled-sale and receipt treatment, post-close rules, inventory/commission compensation and concurrency evidence. Current stock failures roll back the payment command and require an authorized stock correction or governed support review; no cancellation or transfer is silently performed. |

| OPEN-19 | Approve overnight shift editing, travel buffers between branches and a manager interface for future-effective service variants | Legacy overnight records can display, but the existing editor validation requires end after start; the model has no travel rule or dated-variant editing interface. Silent coercion or overwriting would change scheduling truth. | Before adding those commands | **Open; bounded by ADR-048.** Existing split shifts and dated working exceptions are supported. Cross-zone simultaneous capacity is rejected. Existing future variants are preserved and block current-only editing. No commute recommendation, payroll meaning or overnight-edit contract is invented. |

| OPEN-20 | Define service-specific tax-rule execution, completed-consultation prerequisites, service image uploads and advanced segment/resource editing | The tax-category/image references and consultation flag do not establish a tax-rule registry, secure service-media workflow or completed-consultation gate. Canonical resource/segment data exists, but no reviewed layout editor is provided. | Before exposing these operational commands | **Open; bounded by ADR-049.** Business tax and existing consultation-only new-client policy remain authoritative; image references and resource/segment identities are preserved. Product/Engineering/Finance must define permission, validation, historical snapshots and public presentation before expansion. No Phase 2 promotion or release waiver is implied. |

| OPEN-21 | Connect deposit communication events and approve the usable client payment action | Deposit request/received handlers and templates exist, but no deposit domain events invoke them; the current public action is only information and OPEN-16 still blocks self-service payment. | Before labeling deposit notifications active or offering a payment CTA | **Open; bounded by ADR-052, OPEN-13/16.** Product/Engineering/Finance must define committed request/collection events, exact-once keys, failure/refund language and tested public action. Prepared templates are not proof of an operational automation; no synthetic event or paid-confirmation bypass is approved. |

| OPEN-22 | Approve commerce rate cards and platform SMS unit economics | Local commerce amounts, provider costs, pack prices and refund/dispute handling need operational approval; client phone countries must not restrict plan SMS | Before enabling each paid commerce market or selling text packs | **Partially resolved; bounded by ADR-054/056/076.** SMS allowance is worldwide at one credit per segment, including existing subscribers; provider cost differences are platform economics, not a destination gate or multiplier. Certify taxed/async credit payment and refund/dispute recovery; USD software amounts are approved by ADR-056; other commerce markets and paid-pack reversals remain open. |

| OPEN-23 | Define intentional branch relocation and amendment of already-booked arrival details | Saved appointment location snapshots deliberately retain the booked address; a branch move must not silently redirect past or upcoming appointments | Before exposing an appointment location-amendment/relocation workflow | **Open; bounded by ADR-064.** Product/Operations must define permission, versioned evidence, client notice, reschedule/cancellation treatment and provider retry behavior. Current location edits preserve snapshots; owners must coordinate affected bookings through existing reviewed operations. |

| OPEN-24 | Define application-level global STOP/START routing for clients shared by multiple tenants on a platform SMS number | Twilio sender-level opt-out applies across that sender, while a reply does not identify a business. Selecting one matching tenant or restoring multiple businesses' permissions would be unsafe. | Before offering tenant-specific two-way preferences on a shared platform number | **Open; bounded by ADR-067/073.** Current inbound handling only changes an unambiguous client/tenant and otherwise does not expose a conversation or restore consent. Twilio sender-level opt-out still blocks sends. Product/Privacy must define global suppression, evidence and independent per-business re-consent before extending this behavior. |

| OPEN-25 | Define review reporting, content moderation, appeals and recovery after secure-link expiry | The narrow completed-visit flow supports opt-in publication and client consent withdrawal, but business owners cannot selectively remove ratings and no public dispute/report process is yet specified. | Before production reviews are enabled | **Open; bounded by ADR-074.** Product/Privacy/Support must define reachable reporting, content-based review rules independent of star rating, audited restriction/appeal and identity-safe client withdrawal recovery. No campaign, third-party review integration or release waiver is implied. |

### 2026-11-01 Offer confirmation JSON comparison correction

FR-01/19/20, ADR-078: compare saved and current promotion snapshots by recursively
sorted object keys while preserving strict scalar types and sequential discount
list order. MySQL JSON object key normalization is not a commercial change.
Continue rejecting changed offers/amounts before submitting payment. A genuine
mismatch returns billing_offer_changed, closes the obsolete review, preserves
selection and allows immediate new review; do not label this an outage or impose
a retry cooldown. No stored quote, invoice, rate or Stripe attempt is rewritten.

### ADR-065 crawlable archives and marketing host consolidation — 2026-11-04

Authority: owner explicitly requested robots.txt and point-one discovery repairs.
Use sequential crawlable article archive links and distinct page canonicals,
without changing publication/privacy gates. Consolidate only successful explicit
marketing routes from known production aliases onto the configured primary host.
Never blanket-redirect the booking domain: tenant booking and private tasks must
keep their origin. Preserve raw marketing queries in redirects; only validated
archive page numbers enter canonical identity. Repair the existing Nginx robots
location with Laravel fallback, retaining generated rules and sitemap ownership.

### ADR-065 acquisition evidence and broader industry positioning — 2026-11-05

Authority: the owner approved the public-page improvement plan and explicitly
clarified that salons/barbershops are the main focus while other supported
appointment-led industries remain part of the product. Requirements: PRD sections
1–4/12/15; FR-01/04/06/08/11/14/18/21; ADR-024/065/070/079.

Keep all thirteen existing industry destinations and the broad brand/entity
profile. Strengthen priority industry pages and shared features with truthful
use examples, FAQs and existing reviewed public demo screenshots. Resolve media
through the Help catalog's file/dimension/hash checks, publish sample-data
captions and retain accessible enlargement. A screenshot is not customer evidence
or certification of a live integration.

Add one read-only product walkthrough at `/features/product-walkthrough`, within
the already reserved Product prefix so tenant root booking addresses retain their
namespace. Add one distinct daily opening/closing checklist under existing guides;
reuse the resource hub and add a printable rendition to maintained guides. Keep
curated sitemap/indexation/alias and consent rules aligned. No new tracking type,
financial workflow, private customer record, specialist capability or release
waiver is introduced. Customer stories require real evidence and permission;
do not publish a fictitious story or an empty coming-soon destination.

## Email-led setup and migration assistance — 2026-11-06

Owner-approved FR-02 acquisition refinement: promote personal account setup and
reviewed migration help on Home, Pricing, industry solution pages, feature detail
pages and the product walkthrough. Shared SetupSupport uses existing marketing
tokens, a wrapping action row and the configured support email. Requirements are
gathered manually by email; no intake form, upload, migration engine or in-app
workflow is added. Describe clients and upcoming appointments/bookings explicitly;
other records depend on review. Agree scope, timing and any costs before work;
never promise universal compatibility, free service or a fixed turnaround. Ask
for no client files in the initial email. Owner review precedes going live.


## Three-month account trial — 2026-11-07

Owner-approved FR-01 change: newly verified accounts receive three calendar months,
clamping month-end dates without overflow. Existing saved trial dates and paid
subscriptions are unchanged. Public pricing uses “Three months to make it yours”
and “3-month free trial”, without launch/urgency claims. No card is required;
a paid subscription requires separate confirmation. Actual saved end dates remain
authoritative in the subscription workspace.


## Opt-in live pitch-demonstration tenant — 2026-11-07

Owner-authorized implementation under FR-01–FR-19: provide a separately invoked
`PitchDemoSeeder` for the owner to deploy and run on production. Ten seats mean
ten active bookable professionals (five per location), with ten physical chairs
and four additional role-demonstration logins. Do not change shared catalogue,
normal trial duration, platform roles, product release gates or existing tenants.
The demo alone receives a one-year non-provider trial, a complimentary zero-value
manual invoice and capacity for two branches/ten professionals. All monetary
history is fictional and tenant-contained; no external charges or deliveries.
Bundle generated fictional portraits/interiors, keep reviews private, and label
the business as a demo. Replays preserve existing dates/passwords/history rather
than reset or rewrite ledgers. Database creation and completion audit are atomic;
tracked new media is removed on failure. See [run guide](demo-account.md).

The existing gallery is business-wide: show each interior with a location caption;
no new location-photo schema or service-resource behavior is approved by this task.
Shared services do not attach resources from two different branches because the
current engine requires every attached resource to match the booked location.

### Open demo follow-ups

- Branch-specific gallery ownership and branch-scoped resource requirements need
  a separate reviewed product contract if required beyond the named demo gallery
  photos and physical-chair records. No invisible model change is made here.
- A rolling demonstration refresh or expiry extension must define append-only
  history and credential preservation before adding a reset/refresh command.
  The initial ±30-day window and one-year access are explicit, not perpetual.


### Pitch-demo password selection — 2026-11-07

The owner explicitly selected `Password@123` for all fourteen pitch-demo logins,
superseding the supplied-secret/password-preservation rule for this demo only.
Fresh seeding uses that password; rerunning restores it only after verifying all
fourteen expected accounts belong exclusively to the completed demo tenant.
Changed credentials clear remember tokens and are audited without secret values.
Financial records, appointment dates and other tenant accounts remain untouched.


### Canadian demo setup and extended window — 2026-11-07

Owner-approved demo-only refinement (FR-01–06/15/18/19): version 2 uses fictional
Toronto locations, en-CA, CAD catalogue/checkout/inventory/compensation and local
America/Toronto instants. Its access terms and complimentary invoice are CAD/zero;
this does not promote paid CAD SaaS pricing or authorize a currency conversion.
Use month-end-safe dates from two calendar months before creation/upgrade through
two calendar months after it, including today and timezone-offset changes.

A marked version-one demo upgrades once inside a transaction. Retain every issued
financial/receipt/commission/cash-close/invoice snapshot in its original currency;
change current catalogue settings, add new CAD activity and cancel only generated
still-active INR bookings with lifecycle history and an explicit reason. Preserve
manual appointments; conflicts stop and roll back rather than silently move them.
Subsequent runs restore only the existing demo password and completion metadata,
without regenerating the window or financial history. No rolling reset is approved.

The seeded introduction must be complete (`personalized_at`, `guided_completed_at`
and the four steps), and canonical readiness must pass. Demo provenance uses
`demo_version`, avoiding the normal starter claim that no client activity exists.
Keep ordinary onboarding, global plans and customer trial lengths unchanged.

## Marketplace expansion approval — 2026-11-08

Accepted, owner instruction in marketplace implementation chat: promote only the
marketplace/customer expansion recorded as MP-01–04 in the PRD. Keep Business and
Marketplace visibly related with distinct customer journeys. Reuse canonical
availability and booking commands; do not fork calendars, CRM or financial history.
Appointment payments remain manually recorded by businesses; subscription payments
remain separate. No marketplace commission or ranking policy is inferred.

Initial discovery enrollment uses an explicit reviewed `MARKETPLACE_LISTED_SLUGS`
allowlist (empty by default). Existing direct-page publication alone is not consent
to marketplace discovery. This is an interim operator control, not an owner listing
editor. Customer identity and inbox must be completed before advertising accounts.

Open marketplace decisions: confirm canonical production hostname/navigation;
customer identity verification and historical appointment claiming rules; messaging
retention/abuse handling; listing-consent owner workflow; location search/map data
licensing and ranking; required-deposit policy for the manual-payment marketplace;
commercial fees and attribution. The discovery delivery does not waive these gates.

### Marketplace implementation contract — 2026-11-08

The owner's “finish the implementation” instruction authorizes completion of
MP-01–04. Accepted implementation choices: keep the marketplace at the first-party
`/marketplace` path; separate customer session guard/table; email-link verification
and recovery; claim old bookings only with a valid private view link plus matching
verified email; preserve CRM ownership; link rescheduled replacements atomically.
Public accounts never acquire Business roles. Customer audit actors use explicit
`marketplace_customer` source/public identity, not a concurrent Business login.

Owner listing controls supersede the interim operator-only enrollment approach.
Business-wide settings permission, revision/lock and explicit listing consent are
required; an owner's pause overrides the legacy slug allowlist. Reuse the canonical
salon gallery rather than invent a second conflicting media store. Ranking uses
explicit name/rating choices, no paid placement or commission inference.

Use saved owner entrance pins and session-only approximate coordinates for nearby
search. No new Places storage/geocoding service is introduced. Date/price discovery
uses canonical availability/catalogue and needs broad-search load measurement
before large enrollment. Messaging is in-app/booking-linked with explicit refresh,
read status, encrypted storage, per-command replay safety and customer pause/report
controls. No external chat notifications/marketing consent are inferred.

Manual booking payments preserve existing required-deposit restrictions. This
approval is not permission to pretend a required deposit was paid. SaaS payments
remain independent. Marketplace terms/privacy wording, communication retention,
moderation-removal/appeals policy, large-directory performance and public host/mail/
map certification remain launch review items. No production rollout or real salon
enrollment was performed. Existing phase-one release gates are not waived.

### Marketplace customer refinement and entry decision — 2026-11-08

Accepted from the owner's reported session/search issues and requested competitor
review. This supersedes the default-hidden listing and private-link-only claim
rules above: active, published online-booking salons are discoverable by default;
an owner's explicit pause remains authoritative. Verified customer email links
previously unclaimed appointment projections automatically; existing ownership
is immutable and no cross-tenant CRM merge/access is introduced. Profile saves have
an explicit destination; authenticated confirmation URLs cannot show expired-link
errors. Email/Google login remembers the customer separately from Business.
Google uses OAuth state, verified email, a unique subject and the existing shared
callback with explicit saved audience. New accounts still accept current terms.

Retain the existing Business acquisition homepage and stable indexed URLs at this
stage; `/business` permanently redirects there. Promote Marketplace prominently on
that homepage and in shared navigation, with discovery at `/marketplace`. Changing
the root alone does not establish better SEO, and would replace established intent
before directory launch certification. Marketplace stays noindex pending its
existing launch gates; a future indexable directory/root migration needs its own
content, canonical/redirect and rollout review. Customer/account pages remain
private/noindex. This resolves the current entry/navigation choice, not public
host/legal/map/load certification. No new booking payment gateway is authorized.

Browser review of logged-in Fresha and Salonist confirmed unified service/location/
date search, compact avatar/logout, dedicated profile and account navigation.
Use those interaction patterns with Clipperdesk's own imagery/palette and shared
email/notification shell. Do not infer wallet, native app or unrelated profile
fields as new approved scope.

### Unified booking and Google Marketplace search — 2026-11-08

Owner-approved follow-up: remove the duplicate Marketplace service/time screen and
render the established booking page at the Marketplace salon URL. Preserve old
`/book` entry links as redirects with their choices; direct salon links still use
the same component and do not inherit Marketplace pause restrictions. Canonical
holds, commit, tenant authorization and manual payment/deposit rules are unchanged.
Keep favourite/account affordances alongside the established booking presentation.

Service suggestions come from real publicly eligible Services/catalogue records.
The three editorial category cards use business type or public service/category
terms and reveal the result area. No new global service taxonomy/editor is added.

The owner explicitly requests configured Google Places/map search and precise
current location. This supersedes rounded Marketplace centres only: request browser
high-accuracy location on action, or selected Places geometry. Keep the search centre
in the existing server session with a 30-minute use expiry and remove on expiry
check/clear; never put coordinates in URLs, customer or booking records. No Google
business content catalogue or persistent geocoding database is introduced. Existing
booking branch-only distance sorting remains browser-only. Update the public privacy
disclosure to distinguish the two journeys; legal launch review is still required.
Use the existing Google key/loader/widget and owner-saved entrance pins. Accountable
review of regional provider terms remains a launch gate, not a reason to add a new
provider or silently change Google Cloud settings. Technical references:
[Places widget](https://developers.google.com/maps/documentation/javascript/reference/places-widget),
[Maps service-specific terms](https://cloud.google.com/maps-platform/terms/maps-service-terms).

### Account workspace and Business header refinement — 2026-11-08

Accepted from the owner's attached header screenshot and request to rebuild the
logged-in customer pages. Use a shared Marketplace account workspace for bookings,
inbox, profile and conversations, with common navigation/type/form/card alignment.
Keep all existing ownership, booking management, messaging replay/pause/report and
profile persistence behavior. The Business conversation reuses the refined thread
presentation inside its existing application shell; this does not redesign unrelated
Business operational workspaces or add messaging providers.

The compact Business brand lockup and Find a salon navigation supersede the detached
Business label and large Home customer-prompt banner. The latter is removed; root
Business acquisition and the Marketplace URL/indexation decision remain. Preserve
the real brand mark, trial CTA and existing destinations. Responsive navigation
switches to its existing drawer below1280px. No new product scope, auth/payment
policy, database migration or production deployment is inferred.

### Marketplace identity in customer communications — 2026-11-08

Accepted from the owner's instruction to carry the Marketplace logo into email and
treat appointment/reminder/related messages to salons' clients as Marketplace.
Apply the same CD geometry, forest/lime badge/sparkle, capital-C Clipperdesk wordmark
and Marketplace descriptor to account and all client email purposes. Keep the salon
name/service facts prominent and account/security/billing/team operator email on
Business branding. This promotes presentation only, not new sends/providers.

Use a shared Blade brand partial and email-safe PNG export. Client SES retains its
verified address and gains Marketplace display name; new email plain-text content
gets a new immutable platform revision. Old queued text remains intact and both
platform revisions retain structured rendering. SMS sender/body revisions/credits,
consent, delivery idempotency, attachments and payment rules are unchanged. No live
provider send or inbox-render certification follows from local tests.

## Marketplace local growth implementation contract — 2026-11-08

Accepted by the owner's execution request: MPG-01–10 promote only strategy stages
A–D locally. Supersedes the earlier three-card/no-taxonomy restriction for this
slice. Preserve Business root, Solutions and `/marketplace/salons/{slug}` canonical
booking. Keep the direct booking origins as noindex aliases of the same public
entity; do not redirect a working owner link through a new selection screen.

Use versioned reviewed PHP taxonomy definitions and relational tenant service
assignments, branch offers and geography bindings in the existing database.
`nail_salon` aliases `nail_studio` for interpretation only; no operational rewrite.
Ambiguous operational types (other, independent_professional, multi_service) never
imply a specialty. Health/aesthetics matching is factual named appointment intent,
without medical credentials/schema endorsements. Generic LocalBusiness is safe
where a subtype cannot be established. Do not emit review rich-result markup in
this release; actual consented reviews remain visible and contribute equally.

Use the existing afterCommit/retry/scheduled-sweep pattern with a dedicated durable
projection work row per business. Rebuild from current source under the business
lock, never replay stale event payloads. Dirty/expired projection and current
eligibility gates prevent stale delivery. Reconcile source changes, effective-date
transitions and missed pivot updates. Public projection caches carry no sessions,
accounts, contacts, tokens or search centres; HTTP responses retain private no-store
where authentication/booking/session data exists. No shared whole-response cache.

Geography comes from reviewed operator records, never city-name parsing, IP or
stored Places geometry. Owner chooses an approved area and confirms an address may
be public within the existing Locations workflow. Address changes invalidate the
binding. Profiles require a public eligible path, accurate name/address/services,
public contact route and owner review request; no photo/review quota. Operator
approval is separate, revocable and content-revision bound. Hub minimum starts at
3 distinct businesses (editorial choice); registry never generates permutations.
No inventory is pre-enrolled, approved, or indexed by migration/backfill.

Attribution policy `mpg-v1`: optional first-party acquisition observation requires
explicit analytics consent and no privacy opt-out signal, expires after 30 days,
retains only allowlisted source classes, public page key and timestamps. Never store
raw referrers, UTM text or search phrases. Necessary booking-entry provenance remains
separate and never proves acquisition. Attribution evidence on a confirmed booking
is immutable; rescheduled replacements inherit its root without duplicating a
confirmation. Analytics retention is 60 days after observation; prune optional
evidence to unknown, retaining appointment/payment facts under existing retention.
No network tracker is enabled on private pages. Broader legal/production activation
remains OPEN-12. Search Console imports are aggregate page/day data, no queries or
customer identity, idempotent replacement by property/day/page with reviewer/source.

Nonblocking local assumptions: no production pilot market/cohort chosen, no Google
read credentials, no geography authority imported, and no external/legal sign-off.
These are explicit stage-E actions, not fabricated defaults. Quality thresholds and
ranking v1 are testable starting policies, not Google rules or proven optimal order.
See [implementation audit](audits/2026-11-08-marketplace-local-growth/README.md).

### Customer-owned photo and cookie language — 2026-11-09

Accepted by the owner’s screenshot request (MP-05): customer photo changes reuse
the existing verified Marketplace session/profile, private raster normalization
and shared avatar locations. No public customer directory or imported Google
photo is introduced. Photo storage is separate from Business media. “Accept
optional cookies” and “Reject optional cookies” describe consent choices; necessary
sign-in/booking cookies remain available. The optional acquisition observation
still requires its explicit purpose-specific choice and existing privacy controls.

The owner’s subsequent screenshot refinement keeps photo controls inside the
identity header: avatar picker and draft-only Save/Cancel. The owner’s final
refinement replaces the saved-photo text action with a small corner ×, hover/focus
tooltip and shared confirmation dialog (Keep photo / Remove photo). Touch users
can reach it without hover. No dedicated photo section or repeated explanatory paragraph.
Apply the same restrained hierarchy to all signed-in customer Marketplace pages,
removing repeated promotional/advice cards while retaining useful booking/message
controls, errors and mobile touch targets.

Local regression inspection found two existing receipt-event producers. ReceiptService
is the single producer with its established receipt idempotency key; checkout
delegates to it and retains the event’s amount/currency/sale metadata. No new
financial entry, collection method or historical event rewrite is introduced.

The subsequent density refinement sets customer account buttons to 36px and fields
to 40px on desktop, with less padding. Mobile keeps 44px touch targets and 16px
input text. This is scoped to Marketplace accounts, not a global control reduction.

### Marketplace booking shell continuity — 2026-11-09

Accepted from the owner’s discovery-to-business screenshots: reuse MarketplaceLayout
for Marketplace provider booking routes throughout the existing booking steps.
The previous ProductMark plus Marketplace text inside PublicBookingLayout is
superseded for this entry surface. Scope business accent variables to the inner
booking content, preserving the shared Marketplace header/footer and canvas.
Business identity/media, catalogue, availability, holds, confirmation, privacy and
manual collection rules remain canonical. Direct booking/private preview continue
using their existing public-booking shell. Use one shared status/recovery notice,
not another copy in Booking/Welcome. No indexing or production gate is changed.

### Marketplace email images and secure customer shell — 2026-11-09

Accepted from the owner’s broken-logo/background and Manage booking screenshots.
Embed the existing Marketplace PNG as a CID MIME image for account and SES client
mail; do not depend on inbox proxies reaching a development/private hostname.
Keep text branding usable when the packaged asset is unavailable. Correct the
Marketplace theme's remaining inherited blue body/panel/footer colours; Business
operator emails retain their existing theme. Preserve text alternatives, PDF
attachments, sender/configuration tags and uncertain-send retry policy.
All PublicBookingLayout self-service surfaces use the Marketplace shell, including
management/actions, waitlist offers and existing client forms/completion. Keep
focused content widths, secure token rules, private no-store/noindex, and guest
access; do not turn public account navigation into a required login step.

### Business Messages focus and email alerts — 2026-11-09

Accepted from the owner’s Messages request. Keep the existing marketplace feature
key/permissions, label it Messages, and make the default route a standard Business
inbox. Move existing listing/publication/activity controls to an authorized listing
settings route linked from Business setup. Share an inbox/conversation shell with
normal Business surfaces; keep customer-side Marketplace styling separate.
For now, notify the lowest-ID active verified owner account for customer messages;
never fall back to an unverified public business contact. Notify the currently
verified booking customer for business replies. Recheck ownership, active business,
pause/read state and recipient eligibility before delivery. Use the existing email
notification delivery ledger as a durable after-commit outbox, with one alert UUID
per new message, no historical backfill and no chat body/CRM details in email.
Reuse the configured framework mailer/notification channel and its tracking. A
failed/unknown email must not roll back a saved message or trigger a blind resend.

Message alert operations: `MARKETPLACE_MESSAGE_EMAIL_ENABLED=false` stops creation
and processing without removing conversation/delivery history. Recovery dispatches
only queued new alerts; stale sending becomes unknown after 15 minutes. No blind
replay of uncertain/accepted/failed mail or backfill of old conversations. Use the
existing queue/mailer and operational delivery records; do not interpret transport
acceptance as customer receipt. The customer-facing signed receipt may adopt
Marketplace presentation without changing its immutable issued snapshot or the
Business/PDF document. These are presentation/notification refinements, not financial
or indexation changes.

### Automatic store discovery and profile publication — 2026-11-11

Accepted from the owner’s request to remove per-store deployment maintenance.
Discovery defaults enabled and uses published qualified booking supply. On booking
publication/resume, refresh supply after commit before returning when available,
with durable retry on failure. Individual profile records and content hashes update
automatically from public facts. Paused/withdrawn and demo/private inventory guards
remain authoritative. Existing public booking addresses qualify for profiles without
a separate curated geography binding. Curated hubs retain editorial review.

MARKETPLACE_GROWTH_ORIGIN and MARKETPLACE_GROWTH_PILOT_IDS are retired. Canonical
origin checks use BRAND_WEBSITE_URL. MARKETPLACE_GROWTH_INDEXATION remains the sole
normal SEO rollout setting, default false. The existing enabled config key remains true for normal operation. The retired
MARKETPLACE_GROWTH_ENABLED environment variable has no effect. The old slug list is unused and removed. This refines
MPG-05/07’s manual profile/pilot controls. Production indexing is still an explicit
platform deployment choice.
