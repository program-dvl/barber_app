# Project status

## 2026-11-08 Multi-industry Marketplace growth planning

- Created a concrete strategy and separate-thread implementation prompt for local
  service discovery, inventory-led SEO, new-business exposure and measured outcomes
  across all 13 Solutions audiences. Repository code and current official Google/
  competitor documentation informed the plan; the supplied live Solutions URL
  could not be fetched, so its repository source supplied the audience list.
- Planning only: no product code, indexation flags, sitemaps, tracking permissions,
  business publication state, external campaigns or production settings changed.
  No ranking, conversion or revenue lift claimed.
- [Strategy](strategy/marketplace-local-growth-plan.md) ·
  [Executable prompt](prompts/marketplace-local-growth.md).

## 2026-11-08 Marketplace branding across customer emails (local)

- Shared email CD/sparkle PNG and capital-C Clipperdesk/Marketplace lockup now used
  by customer sign-in and client appointment/service email, including reminders,
  changes/cancellations, receipts, review invitations and waitlist/queue updates.
  Client HTML retains salon details/actions and adopts the forest/sage palette.
- Client SES display name and new immutable email text revision use Clipperdesk
  Marketplace. Old queued text/revisions remain intact and structured HTML still
  supports the previous platform revision. Operator Business mail, verified sender
  address, SMS configuration/credits, consent and delivery safety remain unchanged.
- Relevant communications/Marketplace/account-mail suites: **131 passed / 1,015
  assertions**. The new PNG was visually inspected; rendered HTML/SES mocks verify
  branding, purpose/status/action safety, escaping, retained text and receipts.
  Initial OpenSSL fixture writes needed writable `RANDFILE` in `/tmp`; the final
  complete run passed without source/security changes for that environment issue.
- Deploy the new public PNG alongside config/views/code. No new asset build or
  migration required; no deployment, real client/provider email or inbox-render
  certification performed. Log: `/tmp/marketplace-email-brand-tests.log`.

## 2026-11-08 Marketplace monogram refinement (local)

- Header badge reuses the exact Business CD path geometry in forest/lime, retaining
  the sparkle. Header/footer wordmark now reads Clipperdesk with a capital C.
- SVG path comparison, client/SSR build and whitespace checks pass. No deployment
  or new browser visual verification claimed.

## 2026-11-08 Profile sidebar simplification (local)

- Removed the two right-hand profile information cards and duplicate logout button;
  profile form uses the account content width. Shared navigation logout remains.
- Six existing mounted account tests and client/SSR build pass; whitespace clean.
  No deployment or new visual verification claimed.

## 2026-11-08 Business header and customer account redesign (local)

- Replaced detached Business qualifier with compact real mark/name/Business lockup;
  removed the large Home appointment-prompt strip. Find a salon remains in shared
  navigation; below1280px the existing drawer keeps branding/actions from crowding.
- Rebuilt customer bookings, inbox, profile and conversation around one account
  rail/header/form/card system with mobile navigation. Visit cards separate date,
  status/details/actions; inbox uses compact rows; profile aligns name/phone/email;
  chat has dedicated history/composer and booking/control sidebar. Business thread
  adapts its wording in the existing workspace shell. No backend schema/routes,
  tenant/ownership boundaries, manual payment or external chat behavior changed.
- Verified backend **316 passed / 4,935 assertions**, frontend **230 passed** including
  six new mounted account tests. Source/build evidence covers preserved visit links,
  profile validation drafts, send UUID replay/draft retention, paused/reopen, refresh
  loading and customer logout. Client/SSR build passes; existing CSS/font warnings.
- CUA inventory again reported browser use disabled in Work settings. No new
  desktop/mobile screenshots or visual/a11y certification; the supplied screenshot
  is before-only. Final browser review remains required. No real customer/provider
  mutation, migration or deployment. [Evidence](audits/2026-11-08-marketplace-account-design/README.md).

## 2026-11-08 Unified Marketplace booking and Maps implementation (local)

- Marketplace salon URLs now render the established `Booking/Welcome` directly;
  removed the duplicate service/time preview. Old `/book` entry URLs redirect with
  service/location/date intact. Existing canonical holds/commit, public direct
  links, manual payments and required-deposit rules remain intact.
- Service suggestions use actual publicly eligible canonical catalogue names and
  categories. Broad cards match business type or public service/category terms,
  show selected feedback and reveal results. No invented service records added.
- Added configured Google Places widget to location search and device high-accuracy
  geolocation on request. Search centres retain reported precision in the session,
  valid30minutes, cleared on expiry check/removal; no coordinate URL/profile/booking
  history. Updated privacy disclosure to distinguish discovery from branch-only
  browser distance sorting. No key/provider settings or database migration changed.
- Map implementation pairs numbered pins with cards, selection highlighting,
  Explore & book and Show all pins. No-pin cards and provider-failure list fallback
  remain accessible; phone layout stacks map/list. These interactions have mounted
  component tests, but live rendering/mobile appearance are not newly certified.
- Backend regression **116 passed / 1,259 assertions**, privacy/security **32 passed /
  258 assertions**, frontend **224 passed**; client/SSR build passes. Tests cover
  canonical page/legacy redirect, real service eligibility/hidden salons, mixed
  service categories, precise-centre expiry, category click/result reveal, map
  selection/failure and transient Places geometry/stale callbacks. Existing font/
  CSS warnings remain. No deployment, real booking, provider message or payment.
- Chrome review was attempted on configured local origin8000; computer use returned
  “Local browser use is disabled in Work settings”. Live Places suggestions, map
  rendering/key authorization, device permission grant/denial, and desktop/mobile
  visual QA remain pending. Earlier screenshots certify the previous iteration only.
  [Updated evidence](audits/2026-11-08-marketplace/README.md#unified-booking-and-google-map-continuation).

## 2026-11-08 Marketplace account/search refinement (local)

- Fixed the reported name-save journey: explicit profile redirect, remembered
  customer login and authenticated sign-in/confirmation redirects. Added dedicated
  name/mobile profile and avatar/profile logout, independently of Business login.
- Added stateful Google verified-email signup/login through the existing callback;
  new customers still review terms. No Business account or provider token is created.
  Google provider responses are mocked in tests; live callback remains unverified.
- Existing unclaimed same-verified-email appointments automatically join the account;
  another customer's links cannot be reassigned. Removed manual claim-by-link UI.
- Published active online-booking salons appear by default; explicit owner pause
  wins. Local read-only count found 7 eligible of 23 businesses; no mass update or
  production enrollment occurred. Draft/inactive/disabled listings stay hidden.
- Unified service/location/date search with contextual category/current-result
  suggestions and Any day/Today/Tomorrow choices; compact rating/today controls,
  no currency/price UI. Shared transactional email structure uses Marketplace colours.
- Retained Business root/stable acquisition URLs, added prominent customer entry
  on Home and `/business` permanent redirect. Marketplace remains noindex pending
  its existing launch gates; no deployed SEO result is claimed.
- Regression **332 passed / 5,073 assertions**, frontend **219 passed**, client/SSR
  build and all 22 frontsite budgets passed. Final focused rerun covers the small
  listing audit correction. Migration 000004 applied to local MySQL and preview
  SQLite. Existing font/CSS build warnings remain.
- Chrome access restored: reviewed logged-in Fresha and Salonist search/account/
  profile navigation. Isolated fictional local browser checks verified name save,
  retained login, old confirmation redirect, logout, expired-link recovery, populated
  default list, unmatched-location/clear recovery, search/date panels and Escape.
  Profile/search inspected at desktop and phone390×844; no horizontal overflow,
  header logo touch height44px. Saved screenshots and precise remaining launch
  limits are in [the evidence](audits/2026-11-08-marketplace/README.md#customer-refinement-verification).
- No deployment, real provider email/SMS send, external booking or booking payment.

## 2026-11-08 Connected Marketplace implementation (local)

- Added dedicated customer email-link signup/login/recovery, terms acceptance,
  upcoming/past visits, safe private-link claiming, favourites and booking inbox.
  Customer guard/identity remains separate from Business/CRM; current contact,
  tenant, branch and own-staff authorization apply to account/messages.
- Salon profiles reuse canonical gallery/team/reviews/location/services. Search
  adds category, rating/sort, price/currency, date/today, approximate nearby and
  map/list. Canonical booking automatically links matching-email signed-in visits;
  replacement lifecycle preserves linkage. Manual payment recording and required-
  deposit protections remain; no gateway or external chat sends were added.
- Business gains listing preview/publish/pause with revision/audit, inbox/replies
  and source session counts. Customer pauses/reports, encrypted message history,
  read status, send replay and permission-gated platform concerns are implemented.
  Existing acquisition gets explicit Business identity and Marketplace links.
- Final backend **377 passed / 5,343 assertions** (Marketplace, public booking,
  reviews, access, marketing and booking engine); frontend **219 passed**; client/
  SSR build, 22 frontsite route budgets and whitespace checks pass. Existing
  CSS/font build warnings remain. Three migrations applied to local MySQL;
  interrupted composite-FK/index creation was corrected and safely completed.
- Isolated fictional browser journey completed salon → booking → confirmation →
  automatic account sync; favourite and separate email-link login worked. Customer
  message, salon reply and read status observed from both sides. Desktop1440
  account inspected; phone390 conversation had no overflow or short action buttons.
  Browser access was later disabled, so final map/filter/navigation/wordmark and
  full failure/cooldown/mobile rechecks remain release work, not claimed verified.
- No deployment, real salon enrollment, external email/SMS chat delivery or booking
  charge occurred. Public terms/privacy review, exact-origin mail/maps, broad-search
  load checks and controlled deployed journeys remain launch gates. See
  [contract](modules/marketplace.md) and [evidence/rollout limits](audits/2026-11-08-marketplace/README.md).


## 2026-11-07 Live pitch demo verified after Forge command errors

- The owner's Forge runs reported tunnel failure after “Seeding database”. A
  separate read-only production check confirms the CAD demo completion audit
  and **1,640 saved appointments**. PHP CLI reports 512M/no execution time limit;
  the precise cause of Forge's session failure is unconfirmed.
- Deployed owner login with the supplied demo password succeeds. Live dashboard
  shows seeded activity; Business setup shows **6/6 essentials ready**,
  **CA/CAD/America/Toronto**, two locations/eight services/ten staff and the current
  setup view. Screenshot retained in the [live evidence](audits/2026-11-07-canadian-demo/README.md#production-verification-after-forge-command-errors--2026-11-07).
- No seeder rerun, server/SSH changes or deployment performed during diagnosis.
  The demo is already available; no repeat run is needed.

## 2026-11-07 Canadian pitch demo and completed setup (version 2)

- Demo now uses CA/en-CA/CAD, Toronto addresses and +1 416 example contacts,
  America/Toronto, Canadian-dollar service/retail prices and complimentary CAD
  software access. No global paid-CAD rate card or exchange conversion was added.
- Fresh seeds cover two calendar months before/after the seed date, including
  today. The 2026-11-07 isolated preview has **1,640 visits** across September 7–
  January 7 and 734 sales at the inspected local run time. DST offsets are retained.
- Fixed missing personalization/guided-completion timestamps and demo provenance;
  Business setup shows **6/6 essentials ready / Your current setup**, with no
  introduction or inaccurate starter-data disclaimer. Canonical readiness passes.
- Rerunning on a marked version-one demo performs a one-time transactional upgrade.
  Issued financial/receipt histories retain original amounts/currencies; generated
  active INR visits receive audited cancellation and new CAD appointments. Manual
  clients/appointments are preserved. Later replays do not duplicate the window.
- Local scoped suite **4 passed / 955 assertions**; the final focused upgrade
  regression **1 passed / 35 assertions** additionally verifies manual client and
  appointment preservation. See the
  [Canadian demo audit](audits/2026-11-07-canadian-demo/README.md). Desktop1440 and
  phone390×844 browser checks show ready setup/CAD/Toronto and no horizontal
  overflow; screenshot evidence retained. Scoped formatting/whitespace pass.
  Not deployed or run against production; no external payment/message performed.

## 2026-11-07 Owner-run pitch demo seeder

- Completed opt-in PitchDemoSeeder with two locations, ten linked bookable staff,
  four administrative role logins, sixteen bundled generated images, sixty clients,
  820 appointments across ±30 days, canonical sales/receipts/refund/stock/commission
  history, forms, queue/waitlist, cash closes and private sample feedback.
- Demo-only one-year trial, two-location/ten-staff access and complimentary invoice;
  messaging starts disabled, history is suppressed and no provider calls are made.
  Repeat invocation preserves records and restores the owner-selected demo password;
  late failure rolls back data/media.
- Isolated SQLite **3 passed / 537 assertions**, including actual owner login,
  twelve owner workspace responses, staff calendar, public gallery/private portrait
  media, readiness, overlaps, financial totals, replay and rollback. Scoped Pint,
  PHP syntax and whitespace pass. Generated assets visually inspected. Deployed,
  MySQL-concurrency and browser visual checks were not performed. The owner will
  deploy/run it; see [credentials and live run guide](demo-account.md).

## 2026-11-07 Focused audience content improvements

- Local source adds publication-gated industry article cards, matching reviewed
  screenshots, five printable article worksheets and practical setup/policy examples.
- Production client/SSR builds and frontsite budgets pass; isolated SQLite checks
  verify eligible, draft, scheduled and unrelated-industry links. Desktop, 390px
  phone and print-media worksheet previews inspected using fictional content.
- Existing live article records and production deployment remain unchanged.
  Indexing and ranking outcomes require post-deployment Google evidence.


## 2026-11-06 Receipt delivery and completed-visit review emails

- Implemented per-business automatic receipt/review email preferences, direct
  staff send/copy/download actions, branded online/PDF receipts and tracked MIME
  attachments. Reviews default off, retain client permission and public-consent
  boundaries, and exclude historical visits. Stable intents and delivery checks
  cover duplicate events, queued preference changes and receipt/completion order.
- Local scoped backend **114 passed / 961 assertions**; frontend **10 passed**;
  client/SSR builds and whitespace checks pass. PDF/layout evidence, deployment
  requirements and remaining release checks are recorded in the
  [visit-email audit](audits/2026-11-05-visit-emails/README.md). Node/Chromium must
  be provisioned for workers; additive migration and worker restart required.
  No production migration/deployment or real customer email was performed.


## 2026-11-06 Public setup and migration assistance

- Added shared email-led setup/migration messaging to Home, Pricing, industry
  solutions, feature details and the product walkthrough. Covers new-business
  configuration, clients and upcoming appointments, with other records reviewed
  individually and scope/timing/costs agreed first. Existing support email only;
  no platform workflow or automated migration capability added.
- Client/SSR production build and whitespace checks pass locally. Desktop/mobile
  visual verification and deployed verification have not been performed.

## 2026-11-05 Compact secure SMS action links

- Implemented first-party `/s/{code}` SMS URLs with 128 random bits encoded in
  22 characters, a unique lookup hash, encrypted retry copy, hidden model fields
  and per-IP throttling. Existing purpose/tenant, expiry/revocation/consumption
  checks and signed email/previously sent links retain their behavior. Older
  queued SMS gains a code at rendering without a bulk rewrite or new settings.
- SMS with an appointment action omits the appended address/maps footer; the
  existing appointment page retains the captured address, arrival and directions.
  Credits use final rendered segments. Fixed an existing waitlist HTTP response
  type error found while checking compact GET preview and atomic POST claim.
- Scoped backend **225 passed / 2,583 assertions**; Pint/whitespace pass. Isolated
  browser desktop1512px/phone390×844 verifies the compact-link journey, arrival
  details, directions, no overflow and 44px phone directions action; expired-link
  410 checked and viewport restored. Fake providers only; not deployed or sent.
  Additive migration required, no environment/Twilio changes. Existing single-use
  appointment-bridge behavior remains, including consumption on GET.
  [Scope, evidence and deployment](audits/2026-11-05-sms-short-links/README.md).

## 2026-11-05 Public acquisition pages and product walkthrough

- Implemented owner-approved broad positioning with salons/barbershops prominent;
  retained all 13 industry pages. Added genuine demo screenshots/use examples/FAQs
  on priority industry and shared feature pages, clearer pricing questions and
  contextual trial/product links. Added a read-only five-step walkthrough and
  distinct daily operating checklist; maintained guides gain print styling and
  shared AppNotice guidance. Existing finance, provider and privacy gates remain.
- Local Marketing282/4,412 assertions, frontend219, client/SSR builds,22 route
  budgets and formatting pass. Desktop1512px/tablet768px/phone390×844 checks of
  nine paths pass layout/metadata; screenshot enlargement/focus return, FAQ,
  Inertia navigation and guide print styling verified. Isolated preview has SSR
  disabled. Source3474540 is active in Forge release82151140. Live original-HTML
  crawl passes133/133 sitemap pages plus robots; focused twelve-page rendering,
 19 linked destinations, new-page aliases and preserved booking entries pass.
  Live browser control was disabled; owner chose to finish with available checks,
  so production visuals/interactions remain distinct from local evidence. No
  Google indexing, ranking or traffic improvement is claimed.
  [Scope and evidence](audits/2026-11-05-acquisition-pages/README.md).

## 2026-11-05 Owner-authorised live blog editorial review

- Reviewed and revised all four published articles through the live admin editor:
  clearer distinct intent/titles, practical operating/trial/opening checklists,
  no-show message examples and measurement, labelled financial illustrations,
  official sources and contextual links. Updated summaries/search metadata and
  grouped the operating/software guides for existing related-article discovery.
- Preserved original URLs, first publication dates, authors, images and published
  status. Public material-update dates correctly show 5 November. No invented
  customer evidence or feature claims; payment/deposit limits are explicit.
- Four original article URLs pass live HTTP/SSR metadata, headings and JSON-LD
  checks; all remain in the sitemap. All17 distinct linked pages return200.
  Exact rendered body/metadata/schema match; all images load. Desktop1512px and
  phone390×844 checks show no overflow; screenshots reviewed, viewport restored.
  No code deployment or Google indexing/ranking outcome is claimed.
  [Content, backups and verification](audits/2026-11-05-blog-editorial/README.md).

## 2026-11-04 Search discovery repairs

- Owner-authorized Nginx robots fallback applied through Forge; live robots now
  returns200/text/plain with canonical sitemap. Existing upload limit preserved.
- Implemented crawlable twelve-post archive navigation with distinct page
  canonicals and successful marketing-only alias redirects. Tenant booking,
  private/auth/API routes and mutations retain their behavior.
- Marketing276 passed/4246 assertions; frontend219 passed; client/SSR build,
  21 route budgets and scoped formatting passed. Isolated 25-post browser
  navigation and 390px/44px controls passed. Source **3122f24** deployed through
  Forge **82111204**. Live alias301 redirects and preserved booking entry200
  responses verified; primary blog/sitemap/image remain200. All131 sitemap
  pages pass the post-robots crawl. Only four live posts exist, so later archive
  pages are verified with synthetic local content rather than production inserts.
  [Evidence](audits/2026-11-04-search-discovery/README.md).

## 2026-11-04 Article status-only publishing

- At the owner's request, replaced the separate Publication section and manual
  reviewer/dates with one **Status: Draft / Published** control. On a valid
  Published save, the verified administrator's account supplies the reviewer and
  server UTC time supplies review/first-publication dates. Ordinary edits retain
  the original publication date; changed public content refreshes its review.
  Stored history and authorization remain server-owned; forged lifecycle values
  are ignored. Drafts and Active alone never publish an article.
- Retained summary/topic/search/image/content publication checks. A successful
  image retry now clears the previous image error. Native Status control has a
  44px hit area; shared mobile Save/Cancel actions already provide 44px targets.
- Marketing + administrator-resource checks **250 passed / 3,990 assertions**;
  scoped Pint and whitespace passed. Isolated browser publication succeeded
  without entering reviewer/dates, recorded the synthetic editor and current
  UTC time, retained the first date after a later save, and appeared in the
  public article/sitemap with the correct image/social image and one H1.
  Required-field failures retained text/image and expanded the search section.
  Desktop **1440×900** and phone **390×844** have no horizontal overflow; actual
  phone Status/Save/Cancel targets measure **44px**. Browser sizing was restored.
- The owner deployed **69cad43** through push-to-deploy; Forge deployment
  **82069727** reports **Deployed**. Read-only live verification confirms the
  single Draft/Published control, absence of manual reviewer/date fields and
  Publication section, and the owner's saved article still Draft with its
  image. Desktop screenshot retained; phone DOM at **390×844** has no overflow
  and a **44px** Status control. Live phone screenshot capture returned a blank
  background under the existing browser zoom, so phone visual evidence remains
  the isolated check. Browser sizing was restored. No real article was published;
  automatic timestamp writes were verified in the isolated browser, not by
  publishing the owner's article. The production image repair below is complete.
  [Live evidence](audits/2026-11-04-article-editor/status-live-evidence.json).

## 2026-11-04 Article editor and featured-image upload repair

- Restored explicit public article storage (preserving existing S3), private
  temporary uploads, 5 MiB JPEG/PNG/WebP validation and named upload errors with
  draft recovery. Added PHP-FPM per-directory transport settings of 32/40 MiB,
  preserving existing salon-media limits; effective production limits unverified.
- Added the existing editorial fields to admin creation/editing, including UTC
  review/publication and scheduling. Drafts can save before an image is ready.
  Added visible validation for raw/decoded blocked copy, private/temp/signed links,
  missing visible text and oversized content. Public publication gates remain.
- Fixed rich HTML being stripped as Markdown, preserved legacy Markdown with
  Symfony sanitization, used featured images in public cards/detail/social data,
  and removed unused synchronous social screenshot generation from saves.
- Marketing/admin PHP **236 passed / 3,874 assertions**; frontend **217 passed**;
  client/SSR builds, 21 budgets, scoped Pint and whitespace passed. Isolated
  browser draft create/save/reopen and original PNG upload/save succeeded.
  Saved image is identical to the original **2,269,879-byte PNG**; local public
  URL returns 200/image/png with the full length.
- Forge reports **746682a / Deployed** (**82065079**), then **271a34e / Deployed**
  (**82066589**); this task did not trigger either deployment. A live retry
  established Nginx **413 text/html** before PHP, with surrounding updates 200.
  The owner then explicitly approved this upload fix. Added only
  `client_max_body_size 40m;` after `charset utf-8;`, verified complete readback
  and Forge's finished reload. Reopening matches the approved file apart from
  final-newline normalization. Other hosting changes remain outside that approval.
- **The reported production featured-image journey now succeeds.** Retried the
  original image, saved the owner's article once as Draft and reopened article
  **1** with exactly matching title and full **16,051-character** editor HTML.
  The durable image returns **200 / image/png / 2,269,879 bytes** and its SHA-256
  matches the original. Saved draft remains absent from blog/sitemap (127 URLs)
  and returns 404 publicly. No article was published or schema/provider changed.
  Effective FPM INI values and other upload workflows remain unverified.
  Inline-image/public-publication and full desktop/mobile checks remain separate.
  [Evidence and continuation](audits/2026-11-04-article-editor/README.md).

## 2026-11-04 Google search performance follow-up

- Read-only Search Console: selected three-month view now 37 impressions,
  0 clicks, 0% CTR, average position 55.8, with finalized dates through
  1 November. Prior 2 November check was 28 impressions / 0 clicks / 61.8;
  periods differ by one reported day and cannot attribute improvement to the
  2 November repairs. Fresh 3–4 November 24-hour view: 12 impressions / 0 clicks /
  43.1; preliminary data is separate, never added to the finalized total.
- Sitemap remains Success / 127 URLs. All 127 current live page checks pass
  including SSR; robots still returns 404. Bounded sample of ten: seven indexed,
  three discovered/no crawl. Online-booking and use-cases now indexed; the
  latter selects apex rather than www. Barber/salon pages remain discovered.
  Aggregate Pages report still dated 23 October; no new full index total claimed.
- Newly verified duplicate marketing pages on book.clipperdesk.com return
  200/indexable despite apex canonicals. Google separately indexes two sampled
  solution aliases and selects book host, and they receive fresh impressions.
  Narrow marketing-only redirects are recommended, preserving salon/private
  booking; no code or hosting change made. Owner's prior hosting hold respected.
- Manual actions/security clean. Google's Links report shows zero reported
  external links (lagging sample, not proof of actual absence). Content audit
  confirms zero published blog articles, two short guides and 95 Help URLs.
  Prioritized consolidation, commercial-page crawl/content, genuine product
  evidence and useful reviewed guides; no unsupported feature claims promoted.
  [Metrics, evidence and improvement plan](audits/2026-11-04-search-performance/README.md).

## 2026-11-02 Cookie settings wording (ADR-079 clarification)

- Renamed the public footer control from Analytics preferences to **Cookie
  settings** and aligned the consent-panel guidance, privacy notice and current
  experience/deployment documentation. It opens the same analytics choice;
  consent behavior, measurement scope and provider settings are unchanged.
- Privacy policy regressions passed **29 tests / 240 assertions**; production
  client/SSR builds and all **21 public route budgets** passed. Forge confirmed
  **70575ad** deployed. Live footer, panel guidance and privacy text use Cookie
  settings. Desktop 1680×778 reopening/rejection and phone 390×844 keyboard
  reopening passed; the phone panel stayed within the viewport, with 44px
  actions and no horizontal overflow. Browser sizing was restored afterward.
  [Live footer screenshot](audits/2026-11-02-google-analytics/cookie-settings-desktop.png).

## 2026-11-02 Owner-authorized legal publication (FR-01/19; ADR-080)

- Removed the public Privacy Policy review banner and Terms review banner,
  review-status field and draft-only body wording at the owner's instruction.
  Terms is version 1.0, updated/effective 2 November 2026; Privacy stays v1.2
  with the Analytics disclosure and an owner-authorized public effective date.
- Public privacy date is separate from the existing operational effective-date
  env, approval, provider/operations checks and indexation/sitemap gates. No
  existing environment values, records, legal certifications or refund policy
  were changed. The Refund Policy retains its review presentation.
- Marketing regressions passed: **153 tests / 3,503 assertions**; final focused
  privacy/trust rerun passed **35 tests / 339 assertions**, including the
  independent public-date gate. Client/SSR build, 21 public budgets, scoped Pint
  and whitespace passed. Actual built-app browser checks at 1440×900 and 390×844
  confirmed the current metadata, absence of the old notices and no horizontal
  overflow on both pages. Local preview used SSR-disabled fallback/client
  integration. Forge then confirmed **981dd17** deployed; actual production checks
  at both widths verified the same metadata, removed banners/status and no
  overflow. Operational approval/indexation/sitemap gates remain unchanged.
  [Evidence and limits](audits/2026-11-02-legal-publication/README.md).

## 2026-11-02 Google indexing and live crawl audit

- Submitted the existing production sitemap in the authorized domain Search
  Console property. Its initial Couldn't fetch status subsequently cleared to
  **Success / 127 discovered pages**, confirmed in the UI and screenshot.
  This is discovery evidence, not indexing of every page.
- Inspected all 32 marketing URLs directly in Google: **16 indexed, 15 unknown
  with no crawl, 1 duplicate** (`/use-cases`, historical Google-selected www
  canonical). The aggregate Pages
  report remains dated 2026-10-23 and reports 8 indexed / 12 excluded; it must
  not replace the newer individual evidence. Subsequent Help inspection
  verified **56 indexed / 1 discovered** out of 57; Google's daily property URL
  inspection quota then stopped the remaining **38 Help pages**. Combined direct
  evidence: **89 checked / 72 indexed / 17 not indexed / 38 uninspected**.
- Enabled Forge's official supervised Inertia SSR service with deployment
  restart selected. Before: 32 marketing pages had empty initial HTML. After:
  **127/127 sitemap pages pass** status, canonical, metadata, rendered H1/main/
  links and JSON-LD checks. Robots still returns HTTP 404; the overall production
  readiness check correctly fails. Confirmed the existing Nginx exact robots
  location has no Laravel fallback; prepared the precise repair, **not applied**.
- Owner reconfirmed another chat is deploying; further hosting changes are on
  hold. Browser control was restored after interruption. Google manual indexing
  submission failed with a reCAPTCHA connection error, repeated after one reload;
  **zero manual indexing submissions confirmed**. Stopped retries and quota work.
  Manual actions and security issues both report No issues detected. Google
  crawl host health has no problems; Core Web Vitals has insufficient field data.
  Performance baseline: 28 impressions, 0 clicks, average position 61.8 in the
  selected three-month report. Small samples do not establish durable rankings.
- Local sitemap command now shares the curated endpoint source and never
  crawls/writes a static public sitemap. Added a bounded read-only HTTP checker.
  Marketing/Help regressions: **183 passed / 3,778 assertions**; checker 4 passed;
  focused command rerun 3 passed / 21 assertions; scoped Pint/whitespace passed.
  Actual Chrome desktop/390px checks of home, barbershops, pricing and Help pass
  metadata, content, overflow, images and navigation. These code
  changes are uncommitted and not deployed by this task. Concurrent Analytics
  work in the shared checkout is separate. No launch/legal gate is waived.
  [Evidence and remaining work](audits/2026-11-02-search-indexing/README.md).

## 2026-11-02 Optional Google Analytics implementation (PRD 4/12/15; ADR-079)

- Implemented a single-measurement-ID, prior-opt-in GA4 adapter for guest curated
  marketing pages, bounded trial clicks and interval choices. Production/host/
  route gates exclude signed-in, Help, auth, booking and private/customer records.
  Added equal consent choices, footer withdrawal, privacy-signal handling and
  updated privacy v1.2; existing environment values and credentials preserved.
- Final Marketing suite 153 passed / 3,503 assertions; frontend 215 passed,
  including 25 analytics cases; client/SSR builds, 21 public budgets, scoped Pint
  and whitespace pass. Actual-component Chrome harness checked desktop/390px
  choice, rejection, opt-in, withdrawal, navigation and storage/tag failures
  with Google requests intercepted. This is not live Google receipt evidence.
- Owner approved Canada and both Google agreements; the separate ClipperDesk
  account/property and public web stream 16253588035 were created with enhanced
  measurement off. QRxpress was preserved. Browser access recovered; account
  414302511 / property 561865152 uses G-G14K5KCP1X. User/event retention is
  two months, activity resets and ads/Signals/user-provided/granular data off.
  Forge saved only the new measurement-ID line, with pre-save full-text comparison
  preserving existing content and post-reload ID readback. Initial production
  pageviews/pricing 204 and Realtime receipt were verified. An observed automation
  stall prompted correction of unsafe loaded-Google queue truncation and a
  temporary pause using only the new ID value. Later tool timeouts resolved
  through native accessibility inspection and signup succeeded.
- Forge confirmed **981dd17** deployed; restored only G-G14K5KCP1X using targeted
  Find, preserving other environment values. Actual production pricing pageview
  and trial-click delivery used the right stream; **marketing_cta_clicked HTTP
  204** was followed by a responsive full **/register** document with Create your
  account, zero Google tags and no further Google requests. Phone 390×844 also
  opened the signup form tracker-free; mobile capture did not follow the new renderer,
  so no separate mobile 204 is claimed. Final fresh-tab withdrawal recheck passed:
  actual UI rejection reloaded with zero Google tags/requests; subsequent Pricing
  navigation also had zero tags/requests. **Collection enabled with
  prior opt-in.** Realtime includes deliberate production/local test traffic,
  not completed-signup or revenue evidence. [Evidence and limits](audits/2026-11-02-google-analytics/README.md).


## 2026-11-01 Checkout rejection classification investigation

- Owner-supplied production diagnostic confirms Stripe HTTP 403
  more_permissions_required, matching live key/customer and all six prices;
  no saved Checkout session. Exact denied endpoint is not in the old diagnostic.
  Coupon creation permission is the leading hypothesis, not yet verified.
- Owner reports production confirmation failure for reference
  01M6B8F01JVY0G7BK4J67D3D9G after the offer comparison correction. Permission repair remains pending in the original Stripe account.
- Fixed adapter-wrapped Stripe errors losing their 400/401/402/403/404/422
  classification in customer recovery. These now require platform help instead
  of futile Start again/Check again actions. Unknown transport outcomes retain
  the original attempt and payment safety; no records or charges cleared.
- Removed vague saved-request default in favour of explaining checkout could
  not open and a payment-link check is needed. No credentials exposed.
- Capacity suite 207 passed / 1,452 assertions; frontend 190 passed, client/SSR
  builds pass. Additional rejection regression exercised wrapped 400/403/404.
  Not deployed; actual failure and recovery remain unverified pending diagnostic.

## 2026-11-01 Offer confirmation JSON-order correction

- Identified strict PHP array equality in SubscriptionPromotions::assertUnchanged
  as sensitive to MySQL JSON object-key normalization. Canonical object-key
  comparison now accepts equivalent saved offers while preserving strict types,
  discount-list order and first-payment amount checks.
- Genuine mismatches return billing_offer_changed; obsolete dialog closes and
  selection/code stay available for immediate review, with specific copy and no
  outage label or cooldown. Submitted payment idempotency remains unchanged.
- Local capacity suite 207 passed / 1,452 assertions, frontend 190 passed,
  client/SSR builds, scoped Pint and whitespace pass. Regression simulates MySQL
  reordered JSON objects; it rejects type changes and reversed discounts.
- Not deployed or independently verified on the reported production account.
  No production database repair or charge was made. Local SQLite plus simulated
  MySQL ordering is not a live MySQL/payment/browser certification.

## 2026-11-01 Separate yearly savings and subscription destinations

- Yearly pricing and owner Plan now distinguish 12 monthly payments, yearly
  saving and named seasonal saving, plus total first-year savings. Solo example:
  $348 − $58 yearly − $58 holiday = $232 first payment; $116 total saved.
- Signed-in pricing hero/calculator and shared pricing header CTA open the first
  active billing-authorized workspace's Plan tab as Manage subscription.
  Users without billing authority retain the workspace fallback.
- Frontend 189 passed and client/SSR build pass locally. No pricing, provider,
  payment or schema changes. This revision has not been deployed or checked
  in the production browser; browser verification remains outstanding.

## 2026-11-01 Discount presentation refinement

- [x] Replaced full-width promotional notices above Plan controls with a compact
  gift/campaign/percentage strip inside the price summary. First payment leads;
  regular renewal, USD/tax wording and a welcome-saving breakdown remain clear.
  Coupon entry is a 44px disclosure immediately above Review subscription.
- [x] Public hero and estimator share this treatment, removing expiry and checkout
  paragraphs. Verified 18px separation below Estimated subscription; corrected
  broad hero price styles that also enlarged the discount badge.
- [x] Local browser at desktop and 390px: monthly/yearly amounts, aligned coupon
  error, correction to valid code and cancel-preserved input verified. Phone
  document width 390px; disclosure/review controls 44px and input 46px.
  Frontend 189 passed; pricing backend 16 passed / 239 assertions; client/SSR
  build and whitespace checks pass. No backend/payment/schema change.
- [ ] Not deployed by this task. Owner reports the earlier module deployed; these
  presentation corrections were verified on an isolated local SQLite fixture.
  [Evidence](audits/2026-11-01-offer-presentation/README.md).

## 2026-11-01 Subscription welcome discounts and coupons (ADR-078)

- [x] Added administrator-only Payments → Discounts & coupons with percentage,
  on/off and optional UTC dates; explicit Generate code plus manual entry;
  standalone or sequentially combinable private coupons. New subscriptions’
  first payment only, explicitly confirmed by the owner. Renewals retain rates.
- [x] Public pricing and owner Plan show automatic offers. Review snapshots named
  savings, exact first payment and regular renewal; invalid-code correction
  retains selection. Claim rejects changed offers; submitted checkouts retain
  original terms and stable Stripe keys. Discounted callbacks validate amounts.
- [x] Installed the additive migration and 20% Holiday welcome seed on local
  MySQL barber_app. Dates: 2026-11-01 to 2027-01-01 exclusive, UTC. Seed repeats
  preserve operator edits. No existing local subscriptions changed.
- [x] Isolated browser: generated/manual code save, invalid-code correction,
  $47 → $33.84 combined review, public on/off and desktop/390px layouts verified.
  Mobile controls 44px and no horizontal overflow. Frontend 188 passed; client
  and SSR builds pass. Focused billing/admin/pricing 247 passed / 1,784 assertions. Scoped Pint and whitespace pass.
- [ ] Full backend has 1,033 passes / 30 skips / 2 communication count failures;
  full suite is not green. Not deployed. Restricted live Stripe Coupon write
  access and a real discounted payment/tax/renewal rehearsal remain unverified.
  [Evidence and deployment](audits/2026-11-01-subscription-promotions/README.md).

## 2026-11-01 Batch salon photos and clear booking preferences (ADR-077)

- [x] Gallery accepts multiple photos in one picker/drop, previews the selection
  and uploads with one explicit action. Eight-photo/account limits remain. Each
  confirmed upload advances the revision; partial failures retain remaining
  files/captions, exact retries cannot duplicate a saved file, known-invalid
  photos have a removal action, and leaving stops later uploads.
- [x] Traced the reported booking controls to actual price presentation, client
  eligibility, waitlist offer creation and private-link issuance. Replaced vague
  labels/options with clear wording and contextual help; grouped waitlist/link
  controls. Hid the staff-gender checkbox because its saved/projected value has
  no runtime booking consumer. Its saved value/contract remain; the FR-09 gap is
  explicit rather than presented as a working preference.
- [x] Local browser: selected/saved three files together, reloaded saved photos,
  exercised an invalid middle image and resumed the remaining photo; checked
  previews/recovery at desktop and 390px. Preference choices/hints, advanced
  controls and real save verified on the isolated fixture. Cancel retained a
  three-photo unsaved batch; deliberate discard made no uploads. No horizontal overflow;
  mobile main actions 324×44px, selection removal 44×44px.
- [x] Frontend **187 passed**; focused gallery/setup/public-booking backend
  **122 passed / 946 assertions**. Client/SSR builds pass. All business writes
  during browser checks used an isolated disposable SQLite fixture and demo
  images; no real customer records, provider configuration or schema changed.
- [ ] Not deployed; the screenshot's actual account entitlement was not changed
  or certified. [Evidence](audits/2026-11-01-gallery-booking-preferences/README.md).

## 2026-10-31 Stripe subscription production audit

- [x] Reproduced and fixed same-second terminal cancellation ordering, later
  active snapshots and outstanding-invoice collection reopening canceled access.
  Financial invoice/payment history remains recorded. Found and fixed a real
  Stripe portal creation rejection for the unsupported create parameter `active`.
- [x] Added a read-only production readiness command covering loaded key modes,
  event journal, schedules, callback configuration and six recurring prices.
  Final backend **1,019 passed / 10,732 assertions / 30 existing skips**; Pint and
  whitespace checks pass for changed production files/new command tests.
- [x] Direct production inspection found test keys/test price mappings. With
  explicit owner approval, saved a restricted live billing key and matching live
  signing secret in Forge, fixed canonical APP_URL, and installed both verified
  live rate cards from the six existing prices. No customer charges created.
- [x] Live Stripe Payments/Payouts active; card retries configured. Signed live
  portal-configuration delivery returned **204 Delivered**. Managed live portal
  created with supported parameters. This confirms transport, not paid renewal.
- [x] Removed the temporary portal event and read back the saved **18-event**
  active destination. Re-enabled checkout and pinned the six existing live
  Prices after identifying that database fallback still chose old test cards.
  Forge confirmed both environment saves. On 2026-11-01, production pricing GET
  returned **200** with monthly/yearly `ready=true` and catalogue available.
- [x] On 2026-11-01, after reporting deployment of the reviewed fixes (local
  commit `78fcc14`), the owner supplied production output from
  `billing:check-production --provider-read`: all required configuration checks
  passed, including both verified rate cards, all six live prices, the enabled
  destination/event selection and zero pending/failed billing events. The
  restricted key's account-details REVIEW is expected; account activation and
  signed delivery were separately verified above. This is owner-supplied
  deployed command evidence, not a fresh independent revision inspection.
- [ ] Actual live paid checkout/renewal and tax posture remain uncertified.
  Two existing active app subscription IDs are unavailable in the live account;
  records preserved pending review. Charge refund/dispute/fraud-warning handlers are absent
  from the billing dispatcher and need separate recovery/ownership verification
  before comprehensive financial launch sign-off.
  [Detailed evidence](audits/2026-10-31-stripe-production/README.md).

## 2026-10-31 Saved booking accent presentation

- [x] Found that saved `brand_color` was projected by the backend but never used
  by the public booking layout. Welcome now passes it for public booking and
  private preview; scoped theme variables colour progress, actions, selected
  states and focus without changing platform identity or semantic status colours.
- [x] Derived action shades preserve readable contrast on booking surfaces;
  malformed/absent values inherit defaults. Existing saved colours need no
  re-save, database migration or environment change.
- [x] Frontend **176 passed**, including actual page/layout wiring, public/private
  SSR scoping, input safety and numeric contrast checks. Client/SSR builds and
  whitespace pass. No backend, provider configuration or business records changed.
- [ ] Browser access still reports disabled in Work settings; actual desktop/mobile
  appearance and the reported live business remain unverified. Not deployed.
  [Diagnosis and verification](audits/2026-10-31-booking-accent/README.md).

## 2026-10-31 Google address suggestion clipping correction

- [x] Inspected the reported successful Places response/hidden-results screenshot.
  Found clipping on the search wrapper, guided setup card and default Locations
  SurfaceCard. Removed clipping for those search/form surfaces and consolidated
  widget styling in LocationEditor; only Locations opts into the new card flag.
  Existing manual recovery, selection, attribution and keyboard handling remain.
- [x] Focused location/loader/setup frontend **25 passed**; full frontend **172
  passed**, Node 24.19.0. Client and SSR production builds and whitespace pass.
  No backend, credentials, provider restrictions or saved location data changed.
- [ ] Browser use is disabled in Work settings. Requested enabling it; actual
  desktop/mobile predictions, selection and responsive visual verification remain
  outstanding. Not deployed or described as a verified production fix.
  [Diagnosis, scope and verification](audits/2026-10-31-google-suggestions/README.md).

## 2026-10-31 Worldwide SMS allowance (ADR-076)

- [x] Owner explicitly removed plan-level client phone-country restrictions.
  Capacity SMS delivery now charges one credit per rendered GSM/Unicode segment
  worldwide, using the existing included/prepaid allowance without destination
  gates or multipliers. Consent, valid numbers, owner/client preferences, provider
  settings, subscription restrictions and atomic quota checks remain intact.
- [x] Applies to existing paid `+1` snapshots and new subscriptions without
  rewriting snapshots, verified rate cards, fingerprints, Stripe Prices, prior
  debits or reservations. No migration or new environment setting is required.
  Previously suppressed messages are not automatically replayed.
- [x] Reproduced before correction: 7 failures / 5 passes. Global quota tests now
  **17 passed / 101 assertions**, including a US saved booking event sending to an
  Indian client through simulated live Twilio, duplicate processing, international
  quota exhaustion, included/prepaid splitting, carrier rejection and unknown
  outcome retention. Scoped formatting and whitespace checks pass.
- [x] Final full backend: **1,010 passed / 10,661 assertions**, 30 existing skips.
  No frontend, schema, runtime environment or external provider changes were made
  for this quota correction; all test provider requests were simulated.
- [ ] Correction not deployed; a fresh deployed booking SMS and callback round
  trip remain unverified. Provider country requirements and pending US/Canada
  toll-free approval remain operational limits, not plan coverage restrictions.
  [Implementation and deployment evidence](audits/2026-10-31-global-sms-quota/README.md).

## 2026-10-31 Deployed booking email/SMS diagnosis

- [x] Read-only Forge checks confirm deployed revision `cf5f7ec`, an installed
  minute scheduler, sync queue, and passing live Twilio configuration/pool/callback
  checks. Toll-free approval remains IN_REVIEW.
- [x] Reported booking SMS has consent and selection but is suppressed before any
  provider attempt: `destination_not_included`. Matching subscription snapshots
  include only `+1`; the controlled test recipient is `+91`. Twilio's records
  contain only the earlier delivered direct adapter test, not a booking send.
- [x] The booking email failed with `provider_not_configured`. Live SES sender and
  region are present, but AWS access key/secret are missing from both effective
  configuration and the live environment file. Local SES credentials are present.
- [x] Owner authorized transferring the existing three AWS settings to Forge.
  Saved only those settings and reloaded configuration; production now reports
  client email configured. Identity-inspection permissions are denied for this
  key; no IAM access was expanded. Temporary transfer file deleted.
- [x] One separately authorized branded test was sent from the deployed SES
  adapter and the owner confirmed receipt. Production email sending/receipt is
  verified after the configuration repair; the read-only IAM denial did not
  prevent sending. A fresh booking/reminder round trip was not created or tested.
- [ ] The diagnosed deployed revision still excludes Indian booking SMS through
  its captured `+1` coverage. ADR-076 above removes this gate in the prepared
  correction. No historical messages resent or financial snapshots rewritten.
  The email recovery itself changed configuration only and reran no product tests.
  [Evidence and recovery boundaries](audits/2026-10-31-production-notifications/README.md).

## 2026-10-29 Direct Locations navigation

- Added Locations beside Services in the shared desktop/mobile menu, retaining
  settings visibility rules and the existing authorized management route.
- Paid-limit actions now say Upgrade to add locations and open existing billing.
- Local location frontend tests: 16 passed on Node 24. Desktop/mobile browser
  checks and deployed upgrade/payment verification remain outstanding.


## 2026-10-29 Setup clarity and local integration recovery (ADR-075)

- [x] Photos & branding is a direct setup tab with matching Readiness wording,
  optional status, booking preview and an outlined skip button in a spaced footer.
  Empty photos, loading and actual failure are distinct; a persistent platform
  failure supplies its explanation and safe support reference without futile retries.
- [x] Removed manual staff status/work-branch reasons from Team and setup. Actor,
  before/after and retained visit IDs are audited automatically. Holds, tenant,
  revision, paid-limit and scheduling/qualification exception safeguards remain.
- [x] Applied exactly the additive photo/review migrations to local MySQL; read
  back both tables successfully. Unrelated pending Help feedback was untouched.
  Repaired the local test pricing catalog: two current cards added, two old cards
  retained and six matching test prices verified. No purchase or charge created.
- [x] Plan shows approved estimates during missing current mappings, disables new
  reviews/purchases and preserves independent saved-payment confirmation. Public
  catalog and purchase authority remain verified-only. Google uses supported light
  styling, terminal denial handling and manual recovery that preserves entered work.
- [x] Initial Google reproduction worked at port 8027 while port 8000 was
  referrer-denied; no quota exhaustion was established. Following explicit owner
  approval, created one separate **ClipperDesk – Local Browser** key in the
  existing project. Saved restrictions allow only the two exact local origins and
  Maps JavaScript/Places API (New). The old production key was not changed. Saved
  the new value only in ignored local environment configuration; all other parsed
  settings were unchanged and the temporary key file was deleted.
- [x] Rebuilt client/SSR assets with the local key; safe diagnostics confirm the
  built assets contain the current key and configuration is not cached. A
  temporary same-origin Chrome probe at port 8000 displayed CN Tower suggestions
  and selected/fetched the real address without provider errors. No business or
  client data was saved. This is local provider/origin evidence, not full
  reported-account certification; see the linked audit/screenshots.
- [x] Backend **993 passed / 10,560 assertions**, 30 existing skips; frontend
  **172 passed** from the preceding source-change regression run. Tests were not
  rerun for the subsequent key-only configuration update. Client/SSR builds,
  scoped formatting and whitespace pass.
  Desktop/390px evidence covers branding, photo failure/support, Plan estimates,
  simplified profile controls and Google/manual recovery. A sample status change
  saved without a reason. [Evidence and screenshots](audits/2026-10-29-setup-recovery/README.md).
- [ ] Not deployed. Full reported-account, production and broader
  browser/accessibility certification and existing launch
  gates remain outstanding.

## 2026-10-29 Optional salon presentation and completed-visit reviews (ADR-074)

- [x] Studied the supplied Fresha salon and live service/time workflow. Added an
  optional eight-photo salon gallery and public photo viewer; zero-photo pages
  use business information and initials. Team portraits, existing titles and
  biographies now appear in booking and Team. Staff policy, qualification,
  availability, timezone and deposit rules retain their canonical engines.
- [x] Owner image editing uses compact saved/selected previews, explicit saves,
  replacement/removal and one expanded gallery editor. Portrait editing opens on
  demand. Tenant/branch permissions, private storage, decoded image limits,
  orientation/metadata handling, stale revisions and draft recovery are enforced.
- [x] Completed visits offer one secure-link rating/detailed feedback submission.
  Public display requires explicit consent; clients can withdraw display. Only
  consented reviews affect public totals/paginated lists. Calendar managers read
  scoped private feedback and copy seven-day links; no messages/payment calls or
  SMS credits are triggered. Client merges/exports preserve review/consent data.
- [x] Local full backend **984 passed / 10,389 assertions**, 30 existing skips;
  frontend **151 passed**. Production client/SSR builds, scoped formatting and
  whitespace pass. Browser checks include no-photo/public gallery/profiles,
  next-day times, compact owner editors, review-link copy and private feedback
  save at desktop/390px, plus the owner review-link notice at 360px.
  [Detailed evidence and screenshots](audits/2026-10-29-booking-presentation/README.md).
- [ ] Not deployed. The initial implementation left the application database
  untouched; ADR-075 above records subsequent local schema recovery. Deployment
  requires the two new additive migrations and assets. Browser file-chooser uploads were blocked by
  extension file access; upload preview/retry has mounted/HTTP evidence. Target
  MySQL journeys, full browser/accessibility certification and production review-reporting
  policy (OPEN-25) remain outstanding. Payment collection and automated outreach
  remain excluded; existing launch gates are not waived.

## 2026-10-29 Twilio SMS launch preparation (ADR-073)

- [x] Reviewed live account, owned sender, service pool, callbacks, geographic
  permissions and deferred WhatsApp resources. Active Full account; owned toll-free
  +1 855 362 0201 remains **IN_REVIEW**. US/Canada geo permissions are enabled.
- [x] Added the existing number to the service alongside CLIPPERDESK and set
  service/number incoming webhooks and service delivery callback to the existing
  deployed routes. Read back saved values; verified phone association in Chrome.
  The previously configured API-style status URL returned 404 on deployment.
- [x] Local SMS now uses MessagingServiceSid. Grouped the same seven launch
  settings at the end of ignored `.env`: two credentials, sender, service, public
  callback base and two explicit live controls. No credential values committed.
  Legacy advanced options remain compatible; WhatsApp remains disabled.
- [x] User authorized one production SMS to their controlled Indian number,
  confirmed the exact received message, and Twilio reported **delivered**, one
  segment, no error. No appointment/customer record or WhatsApp send was created.
- [x] Added signed callback aliases, HTTPS handling, safe carrier error numbers,
  duplicate/late/early callback recovery, unambiguous shared-number opt-out
  handling and sender/transport queue guards before debit or send.
- [x] Read-only `communications:check-twilio --provider-read` validates live
  ownership, pool and callbacks and correctly blocks on pending toll-free approval.
  Schedule lists the minute communication sweep; local queue is sync and no
  local scheduler/queue worker was running at inspection. Did not dispatch backlog.
- [x] Communications: **60 passed / 437 assertions**. Full backend: **930 passed /
  9,939 assertions**, 30 existing skips. Scoped Pint and whitespace checks pass.
  No frontend files changed. [Audit, shared deployment block and WhatsApp requirements](audits/2026-10-29-twilio/README.md).
- [ ] Backend change and shared environment block not deployed. US/Canada
  delivery, deployed booking/reminder/callback/action-link journeys and STOP/START
  rehearsal remain unverified. Local requests using deployed callbacks do not
  update a separate local database. Carrier approval, OPEN-11/15 and existing
  client/owner/allowance controls remain launch gates; shared-number ambiguity is
  OPEN-24. Approval is not proof of deployment or an instruction to resend old work.

## 2026-10-28 Fresh checkout JSON identity root cause (ADR-072)

- [x] Owner reports a fresh successful 2-location/6-staff purchase still showing
  unconfirmed on Plan. Found an actual storage boundary missed by earlier SQLite
  fixtures: MySQL reorders pricing JSON keys; provider projection regenerated a
  different fingerprint for the same verified card, leaving the request submitted.
- [x] Fresh monthly/annual review → Stripe SDK creation → paid return tests fail
  before the fix and pass after it. A read-only local MySQL JSON expression also
  confirms key reordering; it read no customer rows and changed no database data.
- [x] Quotes reuse the verified card's saved identity. Provider application,
  renewal scheduling and change classification match the same immutable rate-card
  ID. Known legacy decoded hashes can recover confirmed affected checkouts while
  retaining all tenant, payment, price, quantity/cadence/currency/amount guards.
  Existing cards, Stripe prices, paid snapshots and invoices are preserved.
- [x] Focused Billing: **272 passed / 1,893 assertions**. Full backend: **918 passed
  / 9,892 assertions**, 30 existing skips. Scoped Pint and whitespace pass. An
  unrelated random-name HTML-escaping test assertion was corrected; no notification
  product behavior changed. No frontend code changed or frontend build was needed.
- [ ] Backend correction not deployed. Actual reported-account verification and
  fresh monthly/yearly deployed sandbox confirmations remain outstanding. Browser
  access remains disabled and prior Forge restriction is respected. No migration,
  Stripe setup change, real payment or production data modification was performed.
  [Reproduction, red/green evidence and rollout](audits/2026-10-28-billing-json-identity/README.md).


## 2026-10-28 Confirmed subscription and stale checkout consistency (ADR-072)

- [x] Owner reports successful payment and supplies screenshots showing Active,
  a matching Paid invoice and a conflicting unfinished-checkout notice. This is
  customer-supplied evidence; deployed storage/assets were not inspected directly.
- [x] Reproduced the contradictory local state. Matching confirmed attempt and
  purchased subscription evidence now completes only the stale workflow, clears
  its obsolete payment URL and appends one audit event without provider calls or
  subscription/invoice changes. Reuse covers billing visits, recovery and review.
- [x] The Plan tab shows Your subscription is active for confirmed results and
  Change your subscription for existing customers. Same-request confirmed props
  beat stale pending props; older partial reloads cannot reopen that purchase.
  Different unpaid requests remain protected and retain useful payment actions.
- [x] Full backend **910 passed / 9,750 assertions**, 30 existing skips; frontend
  **128 passed**. Production client/SSR builds, scoped Pint and whitespace pass.
  Module, decision, shared notification and deployment guidance are synchronized.
- [ ] The follow-up is not deployed. Browser access remains disabled; new rendered
  desktop/mobile checks and reported-account verification after deployment remain
  outstanding. No migration, Stripe setup change, real payment or paid-data reset.
  [Evidence and rollout](audits/2026-10-28-confirmed-checkout/README.md).


## 2026-10-26 Automatic payment return (ADR-072)

- [x] A submitted checkout initially shows Checking your payment and follows
  confirmed processing automatically with bounded checks. Applied payment shows
  Your subscription is active without a manual status action. An already-applied
  webhook return shows success immediately; open/unpaid Checkout stays resumable.
- [x] Automatic checks read only existing owned provider objects through the
  established lifecycle, with no checkout/customer creation, subscription replay
  or payable-session expiration. Stop on error/navigation/action-required state;
  respect Retry-After. Preserve safe test retirement and all financial history.
- [x] Success refreshes shared tenant/header/access, invoices, payment attention,
  quantities and allowances. Return query flags cannot grant access or expose
  another business's result. Ordinary workspace GETs make no provider calls.
- [x] Local full backend: **888 passed / 9,594 assertions**, 30 existing skips;
  frontend: **122 passed**, including actual Vue panel/notice mounting and bounded
  timer tests. Production client/SSR builds and scoped Pint pass. Shared customer
  guidance, module and decisions are updated in the same change.
- [ ] Not deployed or payment-certified. Browser access remains disabled; new
  desktop/mobile visual verification and completed deployed sandbox payments are
  outstanding. No real payment, paid-history reset, secret/catalog change or
  migration. [Evidence and deployment steps](audits/2026-10-26-payment-return/README.md).


## 2026-10-25 Stripe checkout restored after test price repair

- [x] Owner initially reported Start again succeeding but fresh confirmation
  returning checkout unavailable. After the catalog repair and fresh review below,
  the owner explicitly confirmed **Stripe payment page opens** on the deployed
  site. Checkout redirect recovery is confirmed by the owner; no completed payment
  or subscription activation is claimed from that confirmation.
- [x] Identified a diagnostic gap: the safe Stripe wrapper discarded the original
  exception, causing validation/configuration errors to resemble a temporary
  outage. New code retains the exception cause and a redacted pending-attempt
  classification (HTTP status, validated code, allowlisted parameter). Private
  logs retain the provider request reference; customer responses contain none
  of these diagnostic fields. Successful original-attempt retry clears the error.
- [x] Four HTTP/parameter/privacy/retry regressions pass, including billing-page
  response privacy. No additional attempt or subscription is created on failure.
- [x] Supplied deployed inspector output confirms a correctly owned current test
  customer, matching saved/configured credentials, and **all six monthly/annual
  prices returning resource_missing / 404**. The remaining failure is unavailable
  catalog mappings in the current account, not a stuck restart or invalid secret.
- [x] Provisioning preflights explicit price overrides before catalog writes and
  names unavailable variables. The inspector distinguishes mapping sources and
  missing prices from provider read failures, supplying actionable setup advice.
  Monthly/annual SDK regressions reproduce six missing prices, repair mappings,
  preserve paid terms/history, restart and open one fresh reviewed checkout.
- [x] Owner ran the existing --provision command on the deployed server and supplied
  its successful output: both cadence mappings verified/installed; existing
  subscriptions preserved. Current test catalog repair is confirmed by that output.
- [x] Local full backend after the follow-up: **874 passed / 9,377 assertions**,
  30 existing skips. Catalog/setup **30 / 238**, rejection/privacy **4 / 76**;
  scoped Pint and whitespace pass. No frontend code changed in this follow-up.
- [x] Owner confirmed Start again → fresh review → Continue opens the Stripe
  payment page after provisioning. The pending old quote was replaced through
  explicit review; paid subscriptions were preserved.
- [ ] Test payment completion and subscription activation remain unverified on the
  deployed system. Deployment of the diagnostic hardening is not verified. No live
  payment, secret/tax change, paid data reset or new migration was performed.
  See the [catalog recovery runbook](deployment/subscription-billing-stripe.md#confirmed-six-missing-prices-in-the-test-account-2026-10-25).

## 2026-10-25 Checkout preparation, payment recovery and customer wording (ADR-071)

- [x] Exact checkout Support references and Business IDs work in the read-only
  inspector. Optional provider checks read customer ownership and all six price
  mappings without printing credentials or mutating Stripe objects.
- [x] Unconverted test preparation can restart in the same test mode, including
  account/credential changes, while retaining history and strict paid-record
  exclusions. A fresh review is required before another checkout starts.
- [x] Card declines remain retryable; owned session evidence repairs legacy failed
  attempts. Verified existing invoices recover completed checkout payments;
  delayed failure does not permit a duplicate new subscription. Terminal unpaid
  first subscriptions release only the active binding before paid conversion.
- [x] Paid-change status recovery resumes original keys/parameters within 23 hours
  after reconciliation; partial schedule creation, pending invoice and changed
  period safeguards preserve original paid access and financial history.
- [x] Browser testing exposed fractional API timestamp versus whole-second storage
  leaving paid capacity pending. Activation and purchased quantities now commit
  together, with realistic clock regression tests and stale-event protection.
- [x] Reviewed public pricing, billing screens/dialogs and help wording for busy,
  non-technical customers. Outcome-specific subscription/payment language replaces
  capacity/provider-verification jargon. AGENTS.md/design-system persist this rule.
- [x] Full backend: **866 passed / 9,219 assertions**, 30 existing skips. Focused
  billing: **220 / 1,220**. After copy review: billing/Marketing/Help **373 / 4,909**;
  frontend **106 passed**; client/SSR builds, scoped Pint, whitespace and all 80
  published help article validations passed. Desktop/mobile isolated browser
  journeys verified restart, retained edits, annual review, unpaid return,
  Continue/Back and monthly paid activation.
- [ ] Not deployed or live-payment certified. Supplied production diagnostics
  establish matching test configuration and unsaved session, not the original
  provider rejection/account ownership. Forge access was declined; later browser
  access was disabled, preventing final wording/Open invoices visual verification.
  No real payment, secret change, production data reset or new migration.
  [Evidence and remaining checks](audits/2026-10-25-billing-flow/README.md).

## 2026-10-24 Public Help Center and contextual guidance (FR-21; ADR-070)

- [x] Audited current routes/screens/domain rules and published 80 focused guides
  across 14 categories, with explicit permission/plan/prerequisite differences,
  FAQs, recovery and unavailable-feature boundaries. Detailed inventories map
  setup/workforce/catalogue/billing/account and operational/CRM/commerce/reporting
  behavior to current code and requirements. No Phase 2 workflow is promoted.
- [x] Public `/help`, category/article pages, natural-question search with synonyms,
  prefix/typo matching, suggestions and related guides share reviewed file content.
  Authenticated header Help is contextual; actual-screen actions retain membership,
  location, authorization and subscription gates. Multiple businesses receive a
  safe chooser. Crawlable initial HTML, canonical/schema/sitemap and search noindex
  use existing public SEO policy.
- [x] Captured 30 genuine screens from isolated synthetic SQLite fixtures and
  integrated them into 28 guides. Intrinsic sizes, lazy images, expandable native
  dialogs, captions and checksum/dimension validation prevent fabricated or stale
  assets. Repeatable capture, content validation, feedback aggregates and an explicit
  list of remaining text-guided workflows are documented.
- [x] Article feedback uses revision/session-deduplicated yes/no records without
  tenant/account/IP/free-text fields. Search and feedback limits are separate;
  query input survives failures, Retry-After is visible and persistent suggestion
  failures stop requests. Negative votes offer a concrete search/support path.
- [x] Full local suite: **822 passed / 8,847 assertions**, 30 existing skips;
  **104 frontend tests**, production client/SSR builds, scoped Pint, whitespace and
  **21 public route budgets** pass. Focused Help: **37 tests / 323 assertions**.
  Local Chromium checks recorded **42 responsive/journey cases** across 320–1440px
  and **3 additional recovery cases**, including no-JavaScript article reading,
  keyboard/lightbox focus, real local feedback, 429 cooldowns and persistent failure.
  Fresh-catalogue search measured approximately 9–13 ms locally across 80 articles.
- [ ] Not deployed. Feedback's additive migration has not been applied to the
  primary database and must accompany normal deployment. Detailed form/refund/
  invitation/import/MFA/provider-return steps remain text-guided visual gaps.
  No real payment, customer message, primary data change, provider certification
  or independent WCAG/cross-browser certification. Existing general-launch and
  provider/region/privacy gates remain unchanged.
  [Coverage, evidence, limitations and maintenance](audits/2026-10-24-help-center/README.md).

## 2026-10-15 Customer-first billing recovery and shared notices (ADR-069)

- [x] AGENTS.md, design-system, documentation entry point and quality gates now
  require customer-first failure recovery and shared notification/action layout
  on every prompt. Neutral AppNotice replaces stacked billing warnings and is
  reused by Feedback alerts, ToastRegion and shared workspace notices.
- [x] Unpaid trial test setup can be retired when returning to live credentials,
  preserving history and requiring fresh review/confirmation. Paid/unknown/live
  outcomes remain protected. New purchase creates the correct live customer.
- [x] Independent named billing action limits fix shared status/restart budgets.
  One entry check, saved estimates, Retry-After countdown and a support reference
  replace blind polling/retry. Read-only redacted operator diagnosis identifies
  checkout/config modes and private cached-secret/.env mismatch.
- [x] Backend **785 passed / 7,286 assertions**, 30 existing skips; focused Billing
  **176 passed / 848 assertions**; **104 frontend tests**, client/SSR builds, Pint
  and whitespace checks pass. Synthetic desktop/390px/320px browser verification
  covers outage/wait, test-to-live restart through fresh Checkout, support fallback
  and separated 44px mobile actions. Browser-back no longer restores old review.
- [ ] Not deployed; production checkout/account/cache state remains unverified.
  A genuinely live session under test credentials still requires original-account
  operator recovery. No real payment, provider/credential or primary database
  change. [Evidence, scope and rollout](audits/2026-10-15-customer-billing/README.md).

## 2026-10-15 Abandoned checkout and billing portal recovery (ADR-068)

- [x] Status and continuation recheck the original owned Stripe checkout; Start
  again expires it before releasing the exact request. Completion races reconcile
  the existing payment. Estimates remain editable, including after an outage.
- [x] Committed attempts/idempotency and lost-response customer bindings survive
  recovery; wrong mode/account and ambiguous outcomes cannot start a second
  payment. Expiration uses provider lifetime; late events cannot unlock a newer
  request. Private verification fingerprints are excluded from public responses.
- [x] Portal failures remain inside billing with a retryable message; browser-back
  returns refresh billing. Existing paid subscriptions and financial records remain.
- [x] Backend **774 passed / 7,146 assertions**, 30 existing intentional skips;
  focused Billing **165 passed / 708 assertions**; **98 frontend tests**, client/SSR
  production builds, scoped formatting and whitespace checks pass. Synthetic
  browser review verified pending/edit/status/continue/back/restart/review and
  portal failure at desktop, 390px and 320px widths.
- [ ] Not deployed. The screenshot business is absent from the local database;
  its production state and original Stripe account were not changed or certified.
  No real payment, provider credential change or schema migration.
  [Evidence and credential recovery steps](audits/2026-10-15-billing-recovery/README.md).

## 2026-10-14 Platform-managed client notifications (ADR-067)

- [x] Owner email/SMS builders and branded-sender onboarding are retired in the UI
  and authenticated mutation routes. New events use immutable platform content
  and a shared sender; queued custom versions and historical callbacks remain.
- [x] Notifications offers top-level email/SMS switches, quiet hours, coverage cards
  and read-only sample messages; Delivery history retains tenant/branch/finance
  scopes. Audited revision-checked pauses stop waiting work and release its SMS
  reservation; re-enable never resends stopped records. Consent/STOP still wins.
- [x] SES sends ClipperDesk HTML with status-specific copy, visit/payment details,
  arrival guidance and labelled secure actions, plus plain text. Old captured text
  is escaped in a branded wrapper. Verified sender address/credentials are retained.
- [x] Additive local MySQL migration applied after a private settings snapshot:
  all 8 original settings rows and counts of 153 messages, 23 templates, 11 sender
  profiles and 80 intents are unchanged; both added switches default enabled.
- [x] Backend **750 passed / 7,021 assertions**, 30 existing skips; focused
  communications **48 passed / 390 assertions**; **98 frontend checks**, client/SSR
  builds, scoped formatting and whitespace checks pass. Synthetic desktop/390px
  browser inspection verifies workspace, preference saves and email/SMS examples.
- [ ] Not deployed; no real customer message sent or environment/provider credential
  changed. Real inbox/carrier/device certification and existing launch gates remain.
  [Evidence and rollout](audits/2026-10-14-platform-notifications/README.md).

## 2026-10-14 Setup usability and booking confirmation repair (ADR-066)

- [x] New Google signup enters the saved “Let’s prepare your business” introduction
  directly; email signup retains verification before setup. Stale intended
  navigation is ignored for new registration.
- [x] Owner-provider wording now explains team/calendar preparation; the existing
  online-provider question is removed. Search/manual address modes use one full
  address, a bordered search, optional map/arrival corrections, and an address
  card above profile fields. Every introduction step reminds owners they can edit.
- [x] New introductions prepare editable daily 09:00–21:00 location/owner hours
  without an hours questionnaire. Saved presets and established schedules remain.
- [x] Desktop/mobile preview renders the real public services page/catalog with
  private authorized branding. It cannot restore booking sessions, reserve times,
  initialize commerce, confirm or publish; explicit review/go-live remain separate.
- [x] Held/current location comparison ignores JSON object-key order while retaining
  strict values. Reviewed reordered snapshots confirm and replay once; actual
  address/policy changes still block. Full backend **746 passed / 6,956 assertions**,
  30 existing skips; **98 frontend checks** pass. Client/SSR builds, 17 route budgets,
  scoped Pint and whitespace checks pass. Synthetic desktop/mobile browser review
  confirms the controls and address placement; preview fits 320px.
- [ ] Not deployed. No real booking, customer message, primary database edit or
  production MySQL/provider certification performed. [Evidence and limits](audits/2026-10-14-setup-refinement/README.md).

## 2026-10-13 Public website content and SEO audit (ADR-065)

- [x] Audited all 32 curated marketing URLs and 15 public utility/auth/legal/
  retired/error URLs. Reviewed token-based booking/form/waitlist/invitation and
  receipt route families against implementation and isolated regressions.
- [x] Removed visible requirement evidence and excluded requirement mappings
  from all feature/solution/use-case response props. Replaced internal release/
  QA copy with customer workflows and accurate received-payment, deposit,
  communication, privacy and regulated-industry limits.
- [x] Quarantined the retained roadmap, changelog and coming-soon public/write
  endpoints with 410 responses, preserving stored records. Editorial publication
  now excludes blank/incomplete, future-review and internal/placeholder content
  across detail, listing, counts and sitemap. Article body H1s are demoted.
- [x] Shared server/client SEO updates metadata and JSON-LD across navigation;
  no-SSR responses have a real title. Errors fail closed without product schema;
  configured primary production host owns canonical/sitemap/entity identity.
  Public/auth/booking setup functions now use the injected route helper, fixing
  silent server-render failures from the browser-global helper.
- [x] 47 URLs at 360/768/1440 produced 141 browser visits without internal-copy,
  heading, metadata, overflow, empty-link, media or page-error violations.
  Pricing monthly/yearly/progressive/yearly-only interactions pass with isolated
  test rates. Mobile menu and focused final server HTML checks pass. The full
  browser sweep predates the explicit SSR-helper fix; a further full crawler
  pass after that fix was declined at permission and is not claimed complete.
- [x] Latest full suite: **741 passed / 6,868 assertions**, 30 existing
  integration/disabled-feature skips. **98 frontend checks** pass; client/SSR
  production builds, 17 frontsite budget entries and diff whitespace checks pass.
- [ ] **Not deployed; public launch remains NO-GO.** Live baseline still showed
  internal footer copy, old flat staff pricing and a failing changelog. Legal
  effectiveness/version acceptance, regional/provider certification, unfinished
  deposit/provider-refund journeys and independent operational release evidence
  remain unwaived. Production SSR supervision and a final live HTML crawl are
  required. [Complete page register and concerns](audits/2026-10-13-public-content/README.md).

Status date: 2026-10-14

## 2026-10-13 Google Maps and location intelligence (FR-02/03/05/06/09/13/19; ADR-064)

- [x] Existing guided onboarding and Locations share supported Places (New)
  business/address search, manual fallback, optional address/arrival corrections,
  a keyboard/touch entrance marker and customer preview. No coordinate-entry
  controls or additional onboarding system were introduced. Google does not
  overwrite operating hours, contacts or time zones.
- [x] Public booking automatically selects the only eligible branch; multiple
  branches use inline search and optional, explicitly requested nearby sorting.
  Branch changes preserve eligible services and recheck branch-specific staff /
  availability. Address, arrival notes, directions and a reusable lazy Google map
  use the central product design tokens across mobile and desktop.
- [x] Appointments retain their actual assigned location snapshot through
  confirmation, self-service, same-branch rescheduling, calendar and newly
  generated confirmation/reminder email/SMS. A changed held address requires
  fresh review. Tenant authorization, duplicate protection, primary selection,
  stale-write checks, existing hours and future-booking timezone guards remain
  in the existing business command. Billing rules were not changed.
- [x] Additive migration applied to local MySQL and the separate 8027 SQLite
  preview after private backups. All 23 MySQL locations' legacy fields and 141
  appointment assignments remain unchanged; all 141 received snapshots.
- [x] Verification: complete backend suite **730 passed / 6,545 assertions**,
  with **30 existing intentional skips**; **97 frontend tests** pass, including
  mocked Google failures and compiled Vue interaction tests. Privacy/SEO checks
  after the v1.1 disclosure update pass **33 tests / 542 assertions**. Client/SSR
  builds, 17-route asset budgets, scoped Pint and whitespace checks pass.
- [x] Real Places selection, entrance movement and Google map attribution work
  on the authorized 8027 origin. Synthetic one-/two-branch booking, branch
  service retention, staff/time review, lazy maps and 320/390/768/1440px layouts
  were checked without a real booking, message or customer geolocation grant.
- [ ] Production/staging Cloud keys, owned Map IDs, API/referrer restrictions,
  quotas/alerts, DNS/TLS and environment-specific provider/device certification
  remain manual deployment steps. Privacy v1.1 retains existing legal approval
  gates. WhatsApp remains disabled; relocation/amendment policy is OPEN-23.
  [Audit and screenshots](audits/2026-10-12-location-intelligence/README.md),
  [Google Cloud and rollback guide](deployment/google-maps.md).

## 2026-10-12 Progressive subscription pricing and public pricing page (FR-01/13; ADR-063)

- [x] Integer-cent progressive staff bands and annual ten-month amounts are shared
  by public/owner estimates, authoritative quotes and new graduated Stripe Price
  provisioning/verification. Base USD 29 and additional locations USD 19 remain.
- [x] Public discovery leads with starting price/trial in the shared SEO hero and
  a navy price panel. Features and transparent growth rates precede the optional
  collapsed estimator; copy removes repetition. Hero signup has no quantities.
- [x] Existing immutable flat rates/allowances remain readable and billable.
  Owners can explicitly review/confirm migration to current rates at renewal;
  no existing customer, provider object or financial record was migrated.
- [x] Verification: full suite 711 passed / 6,410 assertions with 30 existing
  intentional skips; 86 frontend tests, client/SSR builds, 17-route budgets,
  scoped formatting and whitespace pass. Browser checks at 320/390/768/1440 px
  verify counts, presets, annual charges, reset, invalid inputs and signup.
- [ ] Activate the new Stripe revision in the intended account/mode and certify
  real checkout/proration/renewal/tax behavior before production. Public prices
  correctly remain unavailable without verified current mappings.
  [Evidence and rollout](audits/2026-10-12-progressive-pricing/README.md).

## 2026-10-12 Public PNG logo (ADR-027)

- [x] Saved the owner-supplied 422×106 PNG unchanged as the configured primary
  logo and used it in the shared public header and privacy HTML fallback.
- [x] Verified the PNG loads without overflow at 320/390/768/1440px. Client/SSR
  builds, public asset budgets and 24 focused tests / 221 assertions pass.
  [Asset provenance and screenshots](audits/2026-10-12-public-logo/README.md).

## 2026-10-12 Privacy policy and Google branding remediation (FR-01/05/09–14/19/20; ADR-062)

- [x] Replaced the policy's old-brand/draft/internal-blocker copy with actual
  data categories, Google openid/profile/email disclosures, retention/deletion
  limits, controller/business roles, international rights and the owner-supplied
  Canadian postal contact and support@clipperdesk.com.
- [x] Privacy uses the existing interactive public header/footer and a complete
  HTML fallback when Vue SSR is unavailable. The public review banner is removed
  at the owner's request; a compact native contents disclosure replaces the sidebar.
- [x] Approval/date/provider/operations checks gate effective-date display,
  indexation and sitemap inclusion. The current publication check correctly fails;
  no environment, OAuth scope/credential, live provider or production deployment
  was changed. OPEN-10 and remaining OPEN-13/15 approvals remain applicable.
- [x] Related legal/company/security identity and provider facts corrected;
  Terms/refund remain separate review documents. Sign-in links the same policy.
- [x] Verification: 144 tests / 2,101 assertions pass with one existing intentional
  registration skip; production client/SSR builds, 17-route asset budgets, scoped
  formatting and diff whitespace checks pass. Browser checks at 320/360/390/768/1440
  show no overflow, one h1/main and working contents/menu/focus behavior.
  [Audit, evidence, blockers and Google resubmission checklist](audits/2026-10-12-privacy-policy/README.md).

## 2026-10-12 Forge billing delivery instructions (FR-01; ADR-056)

- [x] Checked current Forge Laravel/scheduler/queue documentation against the app's
  scheduled billing commands and synchronous, signature-verified webhook handler.
  Added exact toggle/worker/delivery verification guidance to the deployment runbook.
- [x] The public production billing webhook URL returned HTTP 400 to an unsigned
  empty-object POST. Reachability and rejection were observed; signed live delivery,
  correct endpoint secret, financial projection, scheduler and workers remain
  unverified. No production environment, Forge job or provider object was changed.

## 2026-10-12 Public capacity pricing (FR-01/13; ADR-061)

- [x] Rebuilt `/pricing` around one shared capacity catalog: visible unit rates,
  live monthly/yearly total, full yearly upfront charge, savings, input examples,
  six core-tool categories and concise counting/trial/billing FAQs. Retired public
  Starter/Pro offers, comparison and preferences; no unavailable-rate fallback.
- [x] Email/Google signup carries validated locations/staff/cadence to the initial
  unpaid owner calculator as preferences only. Provider-paid access still requires
  a fresh review/confirmation. Public payload and component schema omit Stripe
  identifiers, and ordinary page visits make no provider calls.
- [x] Applied the additive signup-preference migration to local MySQL after a private
  snapshot; original values for 22 intents were unchanged. Server deployment needs
  the normal migration step; no new Stripe setup or provider object was created.
- [x] Affected marketing/auth/registration/billing tests: **196 passed / 2,207
  assertions**, one existing intentional registration skip; frontend **75 passed**.
  Client/SSR builds, **17 public route budgets**, scoped Pint and whitespace passed.
  Desktop/mobile totals and signup handoff inspected; 320/390/768 px had no
  horizontal overflow. No browser account/payment/terms submission occurred.
  [Review and screenshots](audits/2026-10-12-public-pricing/README.md).

## 2026-10-12 Forge capacity setup diagnostics (FR-01; ADR-056)

- [x] Split the capacity setup command's generic prerequisite refusal into
  explicit commercial-approval, missing server-key and wrong key-type messages.
  Trimmed blank keys fail before provider access. Recovery instructions explain
  cached configuration and that `--force` permits only live provisioning.
- [x] Database configuration selects `Pdo\Mysql::ATTR_SSL_CA` on PHP 8.4+ and
  retains the legacy constant on older runtimes, addressing the reported PHP 8.5
  deprecation while preserving the existing certificate environment setting.
- [x] Focused capacity/setup tests: **61 passed / 261 assertions**, including
  ten prerequisite failures across `--apply`/`--provision` with `--force` and
  no provider writes or installed mappings. PHP 8.4.8 configuration smoke check
  preserved a supplied CA path. Scoped Pint and whitespace checks passed.
  PHP 8.5 execution and Forge configuration/deployment were not verified locally.
- [x] Updated the [deployment guide](deployment/subscription-billing-stripe.md)
  and module setup contract. No credentials, commercial gates, subscriptions or
  provider objects were changed by this repair.

## 2026-10-11 Restore administrator menus (FR-19/20; ADR-060)

- [x] At the owner's explicit selection, restored all retained LaraFast menus for
  verified active `platform_administrator` accounts: Users, Roles, Permissions,
  seven provider billing resources and the existing Content tools. Dashboard
  widgets now show user/business/canonical active subscription counts and growth.
- [x] User creation/editing and actual platform-role grant/revocation are reasoned
  and audited. Email changes clear verification; user deletion and self role
  revocation are blocked. Custom roles use the business-bound membership service;
  starter roles and the canonical permission catalog retain their protections.
  Financial/provider history is readable without direct edits or deletion.
- [x] All ten restored resource indexes return success in feature tests. Ordinary,
  support, auditor, revoked, expired and unverified identities remain denied.
  Affected platform/authentication/email/profile regression run: **109 passed /
  716 assertions**, one existing intentional registration skip on isolated SQLite.
  Scoped Pint and whitespace checks passed. No migration or frontend build needed.
- [x] Browser signed in with the existing local account without 2FA, displayed all
  menu groups and dashboard counts, and rendered Roles, Permissions and Invoices.
  [Restored menu screenshot](audits/2026-10-11-admin-menu/restored-menu.jpg).
  No real role/data mutation, account reset or live deployment was performed.

## 2026-10-11 Internal admin menu investigation (FR-19/20)

- [x] Reviewed ten related LaraFast documentation chapters and compared the local
  account, Filament resources, widget registration and `/platform` workspace.
  Read-only local account evidence confirms verified email and the correct active
  `platform_administrator` role. Browser navigation matches the four retained
  Content resources; missing identity/billing menus are explicitly disabled for
  all administrators, and dashboard widgets are not registered.
- [x] Recorded the split admin/platform interface and remaining platform module
  placeholders in the [investigation](audits/2026-10-11-admin-menu/review.md).
  No role or application behavior was changed by this review.
- [x] Admin/bootstrap/platform-operation regression tests: **23 passed / 177
  assertions**. This is local evidence; no live deployment was performed.

## 2026-10-11 Direct internal admin login (FR-19/20; ADR-059)

- [x] At the product owner's explicit request, removed required authenticator
  enrollment and second-factor challenges from `/admin/login`. Verified internal
  administrators enter `/admin` directly; the retired MFA setup URL redirects
  there. Email verification, active administrator roles, persistent Livewire
  authorization, 15-minute idle/eight-hour absolute session limits and legacy
  resource quarantine remain enforced.
- [x] Existing Fortify secrets/recovery codes are preserved. Separate `/platform`
  support MFA and salon authentication retain their existing requirements.
  No account recreation, credential reset or database migration was performed.
- [x] Affected platform/authentication/Google/account-notification/verification/
  registration/profile tests: **88 passed / 639 assertions**, one existing
  intentional registration skip on isolated SQLite. Scoped Pint and whitespace
  checks passed.
- [x] Browser verified the user's existing verified local account reaches the
  internal dashboard from the retired setup URL. This is local verification;
  live deployment and real mail delivery were not certified. See the
  [setup guide](deployment/platform-admin.md).

## 2026-10-11 Internal administrator login repair (FR-19/20; ADR-058)

Historical verification: the mandatory internal admin MFA portions below were
superseded by ADR-059 and the direct-login implementation above.

- [x] Repaired the `make:admin` / `/admin/login` mismatch: valid active
  administrator credentials now reach panel-local email verification and required
  authenticator enrollment. Operational pages remain inaccessible until both
  steps are complete. Pending Fortify secrets do not count as confirmed MFA.
- [x] Later logins challenge the shared encrypted Fortify authenticator or
  single-use recovery code. Persistent Livewire middleware retains identity,
  security readiness and platform session limits. Expiry returns to admin login;
  stale salon redirects are cleared and an existing salon session can view the
  admin login. Tenant membership and legacy-resource quarantine are preserved.
- [x] Bootstrap/security/tenant/platform/Google/account-email/verification/
  registration/profile regression run: **88 passed / 658 assertions**, one
  existing intentional registration skip on isolated SQLite. Scoped Pint and
  whitespace checks passed. No schema, dependency or frontend changes are needed.
- [x] At the user's explicit request, created the missing local internal admin
  using their supplied credentials. Browser login succeeded and rendered the
  admin verification screen. At that verification, email verification and
  authenticator enrollment were the remaining steps; real SES delivery and live deployment were not
  performed or certified. See the [setup guide](deployment/platform-admin.md).

## 2026-10-11 Capacity-only billing selection (ADR-057)

- [x] Removed the Existing plan options disclosure, Starter/Pro cards, feature
  comparison, tier-change dialog and tier offer payload from Subscription & billing.
  Plan now offers only the location/bookable-staff calculator and cadence selector.
- [x] Retired tier checkout/change POST actions with tenant-authorized 410 responses;
  old checkout GET links redirect to Plan. Capacity purchase/change, invoices,
  signed webhooks, reconciliation, cancellation and payment management remain.
  No database purge or automatic test-subscription migration was performed.
- [x] Billing suite: **95 passed / 422 assertions**. Client/SSR production builds,
  scoped Pint and whitespace checks passed. Isolated synthetic trial browser view
  shows the single USD calculator; no old tier section or comparison is present.
  [Screenshot](audits/2026-10-11-billing/capacity-only-plan.jpg).

## 2026-10-11 Last-step onboarding recovery (FR-02; ADR-053/055)

- [x] Traced the local final-step 500 to the pending slug reservation migration,
  rather than invalid signup answers. Saved a private snapshot of affected data
  and applied only `2026_10_10_000001_reserve_public_booking_slugs` to local MySQL;
  verified its table and migration record.
- [x] The affected owner's browser subsequently completed onboarding with the
  original saved answers and four selected services. Two authenticated completion
  replays returned the workspace redirect and retained four services, one staff
  profile and one location. Browser completion is retained; publication stays
  private. No account recreation or reservation bypass was introduced.
- [x] Added a regression covering missing-schema rollback, saved-answer recovery,
  migration replay and duplicate-free HTTP completion. Added the deployment
  recovery instructions and linked them from the Business setup specification.
- [x] Focused onboarding/setup/configuration/migration recovery verification:
  **73 tests passed / 496 assertions**; scoped PHP formatting and whitespace
  checks passed. This repair required no frontend or dependency changes.

## 2026-10-11 USD subscription rollout and billing redesign (ADR-056)

- [x] Recorded owner approval of USD 29/19/9 monthly and 290/190/90 yearly.
  New businesses use verified USD software pricing without changing operating
  currencies. Existing paid currency changes still require separate migration.
  Unavailable countries/draft rates are absent from the customer workspace.
- [x] Redesigned Overview/Plan/Invoices with keyboard-accessible tabs, compact
  trial/current plan and usage, focused billing management and bounded invoice
  history. Existing plan options use a disclosure. Zero allowances do not show
  false “limit reached” warnings; full location capacity is shown neutrally.
- [x] Audited Larafast billing/tenancy/config/deployment documentation against
  installed Cashier/Stripe and reused the Business-owned provider/portal/webhook
  journal/reconcilers. Added idempotent verified capacity catalog provisioning and
  correct-route managed endpoint setup with private secret recovery and live flags.
  Open Checkout resumes its exact URL; authenticated expiry releases its request.
- [x] Verified six approved prices in the local Stripe test account; installed two
  local immutable rate mappings and enabled local USD billing. Synthetic Canadian
  trial in an isolated database opened real Stripe sandbox Checkout at $56/month
  for 1 location + 4 staff. No payment was submitted. Expiry preserved the trial.
  Desktop and 390 px trial/plan views, tab keyboard actions and invoices inspected.
- [x] Backend **598 passed / 5,724 assertions**, **30 skipped**; billing subset
  **96 passed / 417 assertions**; frontend **75 passed**; Node 24 client/SSR build,
  scoped Pint and whitespace passed. Corrected the old date-sensitive billing
  fixtures without changing production entitlement history. Existing CSS/font
  build warnings remain.
- [ ] Live keys/endpoint delivery, tax policy, provider payment cases, production
  MySQL parallel billing and independent release certification remain environment
  gates. No live charge, real message or paid SMS credit certification occurred.
  Use [the setup guide](deployment/subscription-billing-stripe.md) on local/server.
  See [audit](audits/2026-10-11-billing/review.md) for source coverage and limits.

## 2026-10-10 Public booking experience and URL architecture (ADR-055)

- [x] Implemented the guest journey through service selection, staff/time,
  essential details with inline review, and centered confirmation/calendar/private
  management actions. Mobile continuation works; time groups, concise states,
  accessible skeletons and centered management headings are locally verified.
  Phone input uses a compact flag/dial code and a wider searchable country menu;
  international pasted numbers infer their country. The previous-visit question
  is removed in favor of private, unambiguous same-business contact/name matching.
- [x] Both configured booking-host `/{slug}` and main-domain `/book/{slug}` render
  one shared implementation without redirecting the current fallback. Centralized
  primary URLs cover setup/copy, services, publication, rebook/payment return and
  canonical metadata. Readable generated/custom slugs and historical aliases use
  one unique reservation namespace with deletion tombstones. The migration also
  removes historical raw flow secrets while retaining access digests.
- [x] Hold replacement/release, secret-validated resume, reviewed-essential HMAC,
  private actual eligibility/deposit evaluation, serialized confirmation and
  authoritative commit revalidation are implemented. Public slot projections
  exclude internal plans/configuration. Rescheduling selects actual availability
  and respects accepted policy cutoffs; waitlist matching checks the exact opening.
- [x] Final backend run: **583 passed / 5,626 assertions**, **30 skipped**, and
  **3 pre-existing billing failures**, also reproduced on unchanged HEAD in an
  isolated baseline. A separately created disposable MySQL database passed
  **14 parallel-process tests / 55 assertions**, including simultaneous public
  confirmations and cross-business slug claims. Frontend helpers: **75 passed**.
  Node 24 client/SSR builds, isolated route/config cache generation, Pint and
  whitespace checks passed. No dependency lock changes were required.
- [x] Chromium completed synthetic guest bookings on both local origins,
  refreshed held/confirmed flows, changed held times, inferred/search-selected
  phone countries and committed secure rescheduling. Centered confirmation has
  no horizontal overflow at 320/390/768/1440 px; 390 px management headings are
  centered. Fixtures use fake communications and isolated databases; no real
  customer data, message/payment or application-database migration was involved.
- [ ] Production DNS/Forge/SSL, real delivery/payment certification, paid public
  checkout (OPEN-16), target-topology performance and independent accessibility/
  browser release gates remain open. Local search measured 726 queries for the
  representative fixture and still needs profiling/load testing. This is not
  paid-launch approval or verified live infrastructure.
  [Audit and evidence](audits/2026-10-10-public-booking/README.md).
  [Deployment runbook](deployment/public-booking.md).

## 2026-10-05 Subscription & Billing integrated into the original checkout

- [x] Applied all 52 files from the user-supplied
  `subscription-billing-update.zip` to `/Applications/AMPPS/www/barber_app`.
  Package hashes and every original-file precondition matched before copying;
  original source files are retained in a local backup. Existing checkout edits
  were preserved. Imported PHP was formatted to the repository standard, billing
  requirement links were corrected and authorization provenance was clarified.
- [x] Original-checkout backend suite: **570 passed / 5,548 assertions**, with
  28 existing intentional Jetstream skips. After formatting, the billing and
  communications regression suite passed **128 tests / 685 assertions**.
  Frontend helpers: **70 passed**. Node 24 client/SSR production builds, all
  17 front-site asset budgets, scoped formatting and whitespace checks pass.
- [x] Saved a complete local MySQL dump before applying only the two new additive
  billing migrations. Verified the five new tables and billing columns, and
  compared existing-column fingerprints for businesses, subscriptions, invoices,
  payments, subscription changes and checkout attempts: existing records were
  unchanged. No account was migrated to capacity pricing.
- [x] Chrome using the existing local sign-in on port 8017 loads the refreshed
  billing overview and invoice details. The current Starter subscription and
  paid invoice remain visible; the business's unconfigured country truthfully
  shows pricing being prepared. At 360 px, the page and invoice drawer both
  retain a 360 px document width. No payment/provider refresh or subscription
  command was submitted during this browser check.
- [ ] Capacity billing, country approval and SMS purchases remain disabled;
  commercial approval, live provider/refund/dispute and production-concurrency
  gates remain open. Source integration is complete; it is not a paid launch.
  [Integration evidence](audits/2026-10-05-subscription-billing-import/README.md).

## 2026-10-05 Subscription & Billing review package (ADR-054)

- Validated in an isolated application copy; the original checkout was not
  modified because write access was not granted. These are package verification
  facts, not a production rollout or completed live certification.
- One core plan can be priced by purchased locations and global active bookable
  staff, with monthly/yearly immutable local rate cards. Existing subscriptions
  retain their terms until an owner reviews an explicit migration. The USD
  example remains unapproved/off; other country prices are not invented.
- Owner calculator, bound review/confirmation, pending verified expansion,
  renewal reductions/interval changes, exact component projections and stable
  provider keys are prepared. Hosted payment and signed/authorized reconciliation
  own access. Initial uncertain checkout recovers its original attempt/key.
- Included SMS uses actual rendered segments and destination multipliers, pooled
  monthly anniversary windows even annually, and complete atomic reservations.
  Optional prepaid credits grant once on exact owned paid/async taxed sessions.
  Automatic purchases remain off. Routine SES email remains included.
- Paid text purchases have a separate default-off gate pending certified
  refund/dispute reversal operations; those automatic reversals are not built.
  Draft examples never become public purchases without approved verified mappings.
- Earlier billing workspace improvements are retained: bounded invoice history,
  exact money/status/payment method and billing details, tenant-safe invoice
  details, provider-state ordering, safer cancellation/reactivation and URL flags
  that never assert payment success.
- Verification: 570 backend tests passed, 28 existing Jetstream tests intentionally
  skipped, 5,548 assertions; 70 frontend helper checks passed; client and SSR
  production builds passed with bundled Node 24. Fresh isolated migrations and
  synthetic billing fixtures succeeded. At 360 px the calculator has no horizontal
  overflow; desktop monthly and mobile yearly breakdowns were visually checked.
- Stripe SDK transport checks assert pending payment/fixed proration/component
  quantities and finite taxed renewal phases. They use a fake HTTP transport;
  no real payment, SMS, email, account migration or live provider object was made.
- Still required before release: approved local costs/rates, provider/tax/3DS/
  async/refund/dispute certification, production-database concurrency and existing
  independent accessibility/security/release gates. OPEN-22 records commercial
  and SMS refund/dispute decisions. The restored billing module resolves its
  affected part of OPEN-14.

## 2026-10-05 Business setup implementation

- [x] Business setup now provides six current operational essentials, one
  recommended next action, labeled starter provenance, direct profile/hours/
  service/team/booking editors and optional branding/import/provider work.
  Completion leads into Calendar. The four saved introduction decisions remain;
  owners can explore, resume, keep suggestions or remove every starter service.
  Public phone/address can be added before online publication.
- [x] Readiness checks current service values, active branches/staff, qualified
  dated assignments, branch membership, resource eligibility and overlapping
  opening/working hours in the next four weeks. Internal bookings do not require
  online visibility, branding or provider connections. A shared backend projection
  avoids disconnected completion flags; a 51-service fixture stays below 18 queries.
- [x] Starter preparation is private. Explicit preview review and Go live replace
  automatic publication under ADR-053. Online service paths, public contacts,
  policies and slugs remain publication gates; pause/resume is explicit. Existing
  published businesses retain their state. Preview shows eligible services,
  opening week, base-price context and client policy links.
- [x] Hardened initialization locks, atomic rollback, terminal retry, existing
  history protection, commerce preservation and type-change invalidation.
  Profile/commerce/slug saves are atomic and revision-checked. Weekly hours bind
  a reviewed exact payload to revisions, upcoming appointment versions and
  current holds; replay audits once and retains booked visits. Setup service and
  team writes reuse their canonical commands. Tenant and business-wide settings
  authority are enforced on the server; branch managers retain scoped workspaces.
- [x] Full backend: **513 passed / 5,311 assertions**, 28 existing intentional
  legacy skips. New readiness/recovery/authorization tests: **34 passed / 165
  assertions**; frontend: **59 passed**. Node 24.19.0 client/SSR builds,
  17 route asset budgets, scoped PHP formatting and whitespace checks pass.
  The notification history test now fixes its clock rather than relying on
  the review date. Browser evidence covers 320/390/768/1024/1280/1366/1920 widths,
  dirty protection, validation, service/team/hours saves, optional work and
  explicit preview/publication/pause/resume in isolated synthetic data.
- [ ] This does not certify live provider delivery, production concurrency or
  regional legal/payment launch. OPEN-13/15/16/19/20/21 remain. No real business
  publication, client message, primary-database fixture, migration or dependency
  was introduced. [Evidence and six-perspective review](audits/2026-10-04-business-setup/README.md),
  [Business setup specification](modules/business-setup.md) and ADR-053.

## 2026-10-04 Client notifications implementation

- [x] Replaced the configuration-heavy page with searchable Automations, versioned
  template drawers, scoped Delivery history and separately saved Channels & timing.
  Ten connected event rules are distinguished from two prepared deposit templates.
  Email/SMS previews, real supported variable insertion, sample segment estimates,
  current-version drafts/publication and guarded unsaved changes are implemented.
- [x] Added 25-record history filtering, safe failure reasons and serialized,
  reasoned manager retry. Client records show six recent outcomes; Calendar shows
  latest appointment communication and links to filtered history. Tenant, branch,
  own-calendar, financial and contact scope are backend-enforced. No credentials,
  historical message bodies or secure action URLs are projected.
- [x] User-selected AWS SES now delivers new client email using existing configured
  credentials and mail sender; Twilio retains the mobile contract. Signed,
  configured-topic SNS delivery callbacks, safe unknown-outcome holds and legacy
  callback compatibility are implemented. Credentials were not changed or printed.
  Actual SES delivery connection is not yet configured; SMS remains simulated.
- [x] Fixed obsolete/late reminder suppression, future action-link expiry, captured
  SMS sender readiness and explicit client channel withdrawals. Client profiles
  accept retained list/map preferences and preserve opt-outs on save. Receipt
  notification links privately display issued immutable receipts, including older
  appointment-target links, without changing financial history.
- [x] Full backend: **479 passed / 5,132 assertions**, 28 existing intentional
  legacy skips. Communications: **44 passed**; frontend: **57 passed**.
  Node 24.19.0 client/SSR builds, 17 route asset budgets, scoped PHP formatting
  and whitespace checks pass. Synthetic browser evidence covers 320/360/390/768/
  1024/1280/1440 widths, editor/publication, settings/filter states and operational
  handoffs. No real client send, main-database fixture mutation, new dependency or
  application migration was performed. Concurrent Reports work was preserved.
- [ ] Live SES/SNS and Twilio certification, country/domain/legal/retention gates
  remain open. OPEN-21 records prepared deposit dispatch/action scope alongside
  OPEN-16. No additional reminders, marketing, unsupported mobile channels or
  Phase 2 benefits were promoted. See [six-perspective review and screenshots](audits/2026-10-04-client-notifications/README.md),
  [Communications specification](modules/communications.md) and ADR-052.

## 2026-10-04 Reports implementation

Applied directly to the intended `/Applications/AMPPS/www/barber_app` checkout.
The isolated copy was used only for preparation. Reports provides a historical overview, grouped searchable reports,
location-local presets/comparisons, complete SQL aggregates, responsive charts,
record drilldowns, shared Calendar capacity and privately streamed CSV exports.
Financial bases, own-only scope and historical schedule limitations are explicit.

Preparation verification in the isolated copy: 458 backend tests passed (28 existing skips; 4,962 assertions),
52 frontend tests passed, and the production client/server build passed. A 5,001-sale
SQLite fixture returned 30 details with complete totals in 10 queries and a
20,041-byte response. Desktop/tablet/mobile, native CSV and bounded print flows
were inspected with synthetic data. This is not deployment or production-load
evidence. See [Reports evidence](audits/2026-10-04-reports/README.md),
[specification](modules/reports.md) and ADR-051.

Original-project verification: **469 backend tests passed / 5,054 assertions**
(28 existing skips), **56 frontend tests passed**, Node 24.19.0 client/SSR builds,
17 asset budgets, scoped formatting and whitespace checks pass. Caches cleared;
only the Reports index migration applied and all three indexes verified. All 22
visible Reports projections pass read-only local MySQL checks. Chrome confirmed
the new overview, Sales detail and record drawer in the actual Pine & Palm Studio
app on port 8000 using the existing sign-in. Environment/business records were
preserved; concurrent Communications edits remain intact. Original-app evidence
is recorded in the linked Reports audit.

## Business-type starter categories (2026-10-04)

- [x] New onboarding previews and prepares small category sets for all 12
  supported business types, including empty groups. Only selected starter
  services are created, mapped to the proper categories. Categories remain
  editable through Services; completed sessions/existing catalogues are not
  reseeded. Tenant case-insensitive reuse retains names, ordering and archive
  choices. Generated IDs/counts extend the existing onboarding/audit evidence.
- [x] Browser review confirmed a single selected hair service produced Hair,
  Styling, Colour and Treatments, then saved a category rename in Services.
  Verification: **18 onboarding tests / 181 assertions**, **440 repository tests /
  4,837 assertions**, 28 existing skips; client/SSR production builds pass.
  No migration/dependency introduced. [Evidence and scope](audits/2026-10-04-starter-categories/README.md).
  Decision: ADR-050; specification: FR-02/FR-04 in Services.

## Services catalogue operational redesign (2026-10-04)

- [x] Restored the Services implementation specification and accepted ADR-049.
  One navigation entry combines a compact catalogue, category management and
  attached add-ons. Instant name/category search, combined filters, persisted
  category order, natural duration, price exceptions and 25-row pagination
  support large catalogues. Setup warnings include branches without eligible staff.
- [x] Overview, Team & locations and Booking & rules provide explicit saves,
  searchable qualification, staff price/time/online variants, branch prices,
  booking notice, deposits, tax-policy context and upcoming appointment review.
  Inactive references, recorded currency, commission references, segment/resource
  identities and historical appointment/sale snapshots remain intact.
- [x] Business/branch authorization, revisions, exact upcoming version signatures,
  reasoned impactful changes, hold protection, booking-compatible locks and
  transactional UUID replay protect configuration writes. Dirty navigation and
  unconfirmed-save recovery are guarded. Existing-service CSV changes now require
  the reviewed editor; imports cannot overwrite live pricing or reactivate rows.
- [x] Calendar and public booking project qualified staff variants and branch prices.
  Public selection removes unavailable branch selections and orphan add-ons;
  unqualified services are hidden. Checkout requires a parent for newly added
  add-ons and retains booked snapshots. Queue continues through canonical service
  timing/capacity resolution; Activity shows useful price/time/count summaries.
- [x] Isolated synthetic browser review exercised creation, zero-price setup,
  errors/focus, dirty discard, categories/order, duplication preview, search,
  pagination, overrides, upcoming impact and Calendar/public estimates. Sampled
  320, 360, 390, 768, 1024, 1280 and 1440 widths have no observed document
  overflow; 320/360 drawers have no horizontal overflow. No real appointment,
  payment, invitation or access change was submitted.
- [x] Repository backend suite: **426 passed / 4,745 assertions**, 28 existing skips.
  Final Services feature check: **19 passed / 139 assertions**. Frontend helpers:
  **48 passed**, including seven catalogue checks. Client/SSR builds, 17 front-site
  asset budgets, scoped PHP formatting and whitespace checks pass. One command
  replay migration was added and applied locally; no dependency was added.
  [Review, screenshots and practical limits](audits/2026-10-03-services/README.md).
- [ ] OPEN-19/20 retain dated-configuration editing and undefined service-tax,
  image-upload, completed-consultation and advanced segment/resource workflows.
  Membership/package benefits remain Phase 2. Public paid-deposit confirmation,
  production concurrency/load and independent accessibility certification retain
  their existing release gates.

## Team & availability operational redesign (2026-10-03)

- [x] Restored the Team implementation specification and accepted ADR-048.
  One navigation entry combines the operational directory, weekly coverage,
  upcoming time off and manager-only access, with focused staff profiles.
  Shared Calendar projections provide daily status, booking gaps, upcoming
  visits/shifts and reserved-time visibility; overdue service blocks Available now.
- [x] Managers configure weekly/split hours, copied patterns, recurring/one-time
  breaks, full/partial/multiple-day leave and dated replacement hours. Exact,
  expiring review binds proposal and revision, lists affected future appointments,
  requires reasons for retained visits, protects active holds and rechecks inside
  booking-compatible locks. Expired dated rules are preserved outside editing.
- [x] Branch/timezone/overlap validation, stale revisions, role authorization,
  private leave redaction and own-profile isolation are enforced server-side.
  Employment/bookability and login/access branches remain independent. Service
  capabilities, duration and price use versioned assignments; appointment and
  financial history remain intact. Permissioned commission statements load via
  business-scoped staff binding and show separate recorded-currency balances.
- [x] Minimal creation, actual business roles/capability groups, invitation status,
  login-only accounts, dirty-draft guards and idle/stale availability refresh were
  implemented. Query-count coverage verifies bounded loading from one to thirteen
  staff; directory appointment context is limited to two weeks.
- [x] Chrome review at 320, 390, 768, 1024, 1366, 1440 and native 1512 widths
  exercised directory/profile/coverage/services/access flows, keyboard focus,
  empty search, mobile time fields and drawer overflow. A synthetic break saved
  through the UI appeared in both Calendar and Walk-in Queue. A conflicting leave
  proposal was reviewed and discarded; no invitation/access grant was submitted.
- [x] Final repository suite: 407 passed / 4,606 assertions, 28 intentional skips.
  Team feature coverage: 23 tests / 184 assertions; frontend: 41 passing helpers including 7 Team
  tests. Client/SSR builds, 17 asset budgets, scoped PHP formatting and whitespace
  checks pass. Evidence and limits: [Team audit](audits/2026-10-03-team/README.md).
  OPEN-19 and existing external release gates remain in force.

## Checkout & sales operational redesign (2026-10-03)

- [x] Restored checkout implementation specification and accepted ADR-047.
  Compact visit selection, source-priced service basket, qualified service/retail
  search, stock-aware quantities, permissioned reasoned adjustments, item/order
  discounts, configured taxes and staff tips lead into authoritative quote review.
- [x] Saved items remain immutable. Verified same-appointment deposits, partial
  payment, atomic split recording and pay later retain original financial rules.
  Aggregate locks precede exact-payload replay; stock, commissions, receipt and
  audit effects commit with settlement. Zero/full-prepaid completion creates no
  fake tender. Private contacts/provider evidence/product costs are redacted.
- [x] Revenue-gated paginated history has actual performer/method/status and
  branch-local date filters. Detail separates original totals from net receipts
  and append-only refunds. Reasoned original-method manual returns enforce
  cumulative item/quantity limits and stock disposition. Immutable completed-sale
  receipts print/save as PDF; the existing consent-gated receipt event is reused.
- [x] Pending recording commands persist exact keys/payloads and freeze changes
  until a definitive result. Unsaved visit switching is guarded. Desktop/tablet
  keep due visible while scrolling; phone has a fixed due/payment shortcut.
  Local Chrome owner review exercised synthetic service/product edits, deposit,
  split completion, receipt, partial sale, history/pagination, refund/restock,
  empty search and discard. Sampled 320/390/768/1024/1440 CSS widths have no
  document overflow. Other role/location protections are HTTP-tested.
- [x] Final suite: **384 passed / 4,422 assertions**, 28 existing intentional skips;
  **34 frontend tests pass**. Client/SSR builds, 17 front-site asset budgets,
  scoped PHP formatting and whitespace checks pass. No migration/dependency added.
  [Audit, screenshots and practical limits](audits/2026-10-03-checkout/README.md).
- [ ] Live card/provider refund execution remains uncertified under OPEN-13/16.
  Phase 2 benefit instruments remain deferred. OPEN-18 records pending saved-sale
  amendment/cancellation and controlled allocation-transfer rules; this workspace
  does not expose those commands. Production races/load, physical payment/print
  devices, outbound receipt delivery and independent accessibility remain unverified.

## Clients operational CRM redesign (2026-10-03)

- [x] Restored Client records implementation specification and accepted ADR-046.
  Compact directory, guarded normalized name/phone/email/reference search,
  relationship/staff filters, allowed sorts, 30-row pagination, important-note
  context and explicit duplicate-contact review implemented.
- [x] Operational profile prioritizes the next booking, important visible notes,
  explicit preferences, recent past visits and payment follow-up. Editing retains
  version/reason, validation and unsaved-change protection; notes retain staff or
  recorded tenant-audit actor attribution. Existing forms, consent, private files,
  privacy cases, communication outcomes and reviewed merge remain available.
- [x] Exact authorized visit/service aggregates are independent of 20-row history
  pages. Completed-sale net receipts, refunds, tips and open balances remain separate
  per currency; transactions paginate 20 rows and omit provider evidence. Contact,
  finance, sensitive data, own-history and assigned-location restrictions are
  applied before serialization. Hidden contact edits preserve canonical values.
- [x] Canonical Client handoffs open Calendar/rebook and Queue review drawers.
  Rebooking uses current eligible services/staff, excluding unavailable services
  and requiring staff selection where needed. Exact Calendar links retain the
  appointment's branch-local date. No benefit-program placeholder is introduced.
- [x] Local owner browser review verified synthetic creation, duplicate warning,
  note/preference saves, payment pagination, keyboard focus/Escape/tabs and both
  handoffs. Directory/profile sampled 320/390/768/1024/1440 CSS widths; phone visit
  and payment histories retain local scrolling without sampled document overflow.
  Role/location restrictions are tested through HTTP, not a complete visual role matrix.
- [x] Final suite: **370 passed / 4,246 assertions**, 28 existing intentional skips;
  **30 frontend tests pass**. Client/SSR builds, 17 front-site asset budgets, scoped
  PHP formatting and whitespace checks pass. Directory query growth is constant
  from one to 30 clients. No new migration or dependency required.
  [Audit, screenshots and practical limits](audits/2026-10-03-clients/README.md).

## Walk-in Queue operational redesign (2026-10-03)

- [x] Compact numbered queue with explicit NEXT, shared live wait clock,
  service/staff context, past-arrival-estimate awareness, search and filters that
  preserve actual order. Staff availability, current services and bounded recent
  completions connect to authorized Calendar/checkout workflows.
- [x] Qualified-staff forecasts use real working windows, breaks/leave, closures,
  bookings, holds, blocks and other-location work. Arrival/refreshed forecasts
  share the ordered method. Full resource/staff fit is checked on selection and
  atomic start; unknown finishes and expired checks cannot create a partial visit.
- [x] Minimal client intake and saved-contact reuse, canonical conversion,
  add/start replay, transactional lifecycle/history, Calendar synchronization,
  branch service qualification, redaction and assigned-location overrides verified.
- [x] Visible idle polling every 30 seconds and one 15-second display clock;
  input/dialog/mutation pauses preserve the working view. Expanded team context
  remains live. Desktop sticky labels/team, tablet disclosure and phone cards
  reviewed at measured 360/390/768/1024/1280/1440/1920 widths without sampled
  document overflow. Synthetic add/assign/start/complete workflows, saved client
  lookup, keyboard loop/Escape and empty-branch isolation checked in Chrome.
- [x] Final results: 358 repository tests / 3,941 assertions; 28 existing intentional skips.
  All 26 frontend helper tests pass; client/SSR build and scoped PHP formatting pass.
  Query growth stays bounded from one to 40 entries. No new migration is required.
  [Audit, screenshots and practical limits](audits/2026-10-03-walk-in-queue/README.md).

## Calendar operational redesign (2026-10-03)

- [x] Staff-first Team day, Day/Week and Agenda; compact toolbar, status cards,
  sticky references, native creation/quick-view drawers and deliberate phone agenda.
- [x] Read-only working windows, breaks/leave, blocks, active holds and cross-location
  commitments. Filtering/searching never turns reserved capacity into an open slot.
  Inactive/former staff visits remain visible; new booking choices remain active/assigned.
- [x] Slot prefill, bounded existing-client lookup, permitted lifecycle/checkout,
  reviewed drag/reassignment/resize, remembered selections and quiet idle refresh.
  Contact/note/finance redaction and own scope are enforced before serialization.
- [x] Existing-client booking resolves and normalizes saved mobile contacts before
  validation, displays the saved number, clears stale phone errors on selection,
  and exposes an optional appointment phone when the saved number needs attention.
  Permanent contact corrections use the existing client profile workflow.
- [x] Canonical client identity survives contactless booking, replay and replacement;
  replacements retain inactive client records. Overnight leave/closure exclusions
  are enforced by the booking validator as well as the Calendar projection.
- [x] Final verification: 348 repository tests / 3,796 assertions, 28 intentional
  skips; 23 focused Calendar tests / 279 assertions; 21 frontend helper tests.
  Production client/SSR build, targeted PHP formatting and whitespace checks pass.
- [x] Local Chrome review at measured 320/390/770/1280/1680 CSS widths covers populated
  and empty schedules, filters/search, overlap lanes, drawers, slot prefill and drag/
  no-show review. No sampled document overflow or runtime console errors remain.
  [Evidence and practical limits](audits/2026-10-03-calendar/README.md).


## Daily workspace dashboard redesign (2026-10-02)

- [x] Dashboard now prioritizes recorded current work, upcoming visits, unresolved
  arrivals, confirmation/forms and unpaid checkouts. Compact counts filter the
  schedule; direct lifecycle actions and an appointment drawer retain context.
  Calendar and checkout links open the exact record. Permission capabilities,
  staff linkage and assigned locations determine schedule, contacts, notes,
  queue, readiness and finance visibility; own access without staff fails closed.
- [x] Opening/exceptional hours and staff windows reuse the existing resolvers.
  Breaks/leave affect scheduled hours. Financial definitions are explicit and
  retain governed sources. Inventory remains outside this visible release under
  ADR-036. No attendance, tasks, client memberships or generated insights are
  fabricated. Idle visible refresh, local-day rollover, bounded active-priority
  appointment details and exact totals implemented.
- [x] Checkout reads/writes now enforce location access and older unpaid links
  are retained. Calendar handoffs redact restricted fields; schedule changes
  preserve unreadable contact/notes, note edits require permission and printed
  schedules enforce assigned locations. Version/idempotency/audit/outbox and
  append-only financial workflows remain authoritative.
- [x] Isolated browser fixtures rendered owner, manager, reception, professional
  and finance scopes; tested confirmation, exact calendar/checkout handoffs,
  drawer Escape/focus restoration and first/last Tab loop, phone disclosure and a closed-day empty state.
  Desktop/768px tablet/360px phone had no page overflow. Full suite: **337 passed,
  3,654 assertions, 28 existing intentional skips**. Frontend: **14 passed**.
  Client/SSR builds, 17 asset-budget entries and scoped whitespace checks pass.
  Availability query count stays constant from one to 21 staff after warmup.
  [Audit, screenshots and remaining limits](audits/2026-10-02-daily-workspace/README.md).

## Brand color and account menu correction (2026-10-02)

- [x] Navigation and signed-in header identity now use the public frontend's
  brand-primary navy; action-primary indigo remains unchanged. The account
  popover has compact icon rows, wrapping name/email and permission-aware billing
  grouping, with a separate Sign out row.
- [x] Public home/product/pricing brand colors checked; shop owner Reports and
  account popover rendered at desktop and 360px mobile. Enter, arrow navigation,
  Escape/focus restoration and long account details checked. No page overflow
  found. Client/SSR builds, 17 asset-budget entries, 9 frontend tests and diff
  checks pass. Other roles and multiple billing-workspace variants are source
  reviewed only. [Evidence](audits/2026-10-02-brand-account-menu/README.md).

## Blue navigation and header follow-up (2026-10-02)

- [x] Primary-blue desktop/mobile navigation, inverse branding and selection/focus
  states implemented in shop and platform layouts; content backgrounds retained.
  Signed-in headers use a subtle blue wash and clearer identity/account styling.
- [x] Shop owner desktop dashboard/clients, 360px client list/navigation and 768px
  header rendered; account/menu Escape restores focus and no page overflow found.
  Client/SSR builds, 17 asset-budget entries, 9 frontend tests and diff checks pass.
  Protected platform shell is source/build verified only.
  [Evidence](audits/2026-10-02-blue-shell/README.md).

## Workspace surface hierarchy follow-up (2026-10-02)

- [x] Refined shared workspace surfaces, navy text/label contrast, table headings,
  breadcrumbs and indigo record avatars; mobile navigation uses the same tokens.
- [x] Fresh owner-role rendering: clients and dialog at 1280×800, clients and
  navigation at 390×844, services at 768×1024, and empty dashboard at 1280×800.
  Client/SSR builds, 17 asset-budget entries, 9 frontend tests and diff checks pass.
  [Evidence and inspection limits](audits/2026-10-02-surface-hierarchy/README.md).

## StepES-inspired presentation follow-up (2026-10-02)

- [x] Implemented white navigation, shared breadcrumbs, compact record tables,
  labelled search/filter toolbars, dashboard cards and progressive report filters.
  Mobile amounts, row actions, metadata and publishing badges were visually fixed.
- [x] Fresh owner-role browser inspection covered all 12 workspace modules at
  desktop/mobile sizes, selected tablet/narrow-width states, client validation,
  service drawers, long names and public booking's first step. Exact states and
  source-only exclusions are in the [follow-up audit](audits/2026-10-02-stepes-inspired-refinement/README.md).
- [x] Full PHP suite rerun: 321 passed / 3,394 assertions / 28 skips; frontend
  tests: 9 passed; final client/SSR builds, 17 asset-budget entries and diff checks
  passed. Visual review used isolated synthetic data, with no real payment/sending.
- [ ] Newly observed existing report defect: previous-period calculations retain
  the current UTC query bounds. Domain correction and date-boundary tests remain.
  Protected platform screens, other roles, 200% text, other browser engines and
  live providers were not freshly verified in this follow-up.

## Platform presentation refinement (2026-10-02)

- [x] Reviewed the full source inventory (76 Vue pages, 103 shared Vue sources,
  20 Blade views and 294 routes). Shared semantic typography, spacing, controls,
  headers, dialogs, errors and responsive navigation now use a compact contract.
- [x] Refined operational workflows, guided/business setup, notifications,
  billing, public booking/self-service, account, platform operations and public
  acquisition language. Appointment/booking terminology is defined in ADR-042;
  user-entered data and stored dashboard preferences remain compatible.
- [x] Readable audit presentation is scoped and read-only. Reports/receipts use
  readable reference names, currency and business-local time. Visit duration
  excludes cleanup while the existing capacity reservation remains unchanged.
- [x] Browser inspection covered all 12 shop modules at desktop/mobile sizes,
  with tablet, narrow-width and 200% text passes, four roles, populated/empty
  states, validation and dialogs. All 11 platform modules, active content lists,
  four onboarding steps and representative public/account flows were inspected.
  Exact rendered states and source-only exclusions are in the
  [coverage audit](audits/2026-10-02-platform-refinement/README.md).
- [x] Complete PHP suite: 321 passed / 3,394 assertions, 28 intentional skips.
  Frontend tests: 9 passed. Client/SSR production builds and 17 frontsite asset
  budget entries pass. This is local evidence, not live-provider certification.
- [ ] OPEN-16 records a pre-existing incomplete public Stripe deposit interface.
  Deposit-required review now accurately states that online payment is unavailable
  and cannot imply a paid/confirmed appointment. Provider completion/recovery,
  token/security states, generated invoice PDFs, physical devices, cross-browser
  and independent accessibility verification remain explicitly unverified.

## Essential SMS client notifications (2026-10-01)

- [x] Owner and public-booking surfaces now expose email and SMS only. The
  Client notifications workspace explains platform versus registered branded
  text senders without presenting deferred channels, fallback controls,
  promotional texting or a conversation inbox.
- [x] The operational policy covers booking status, material appointment
  changes/cancellation, deposit and receipt events, requested waitlist offers,
  deliberate turn-approaching queue updates and one reminder normally 24 hours
  before the appointment. Feedback/rebooking mobile marketing is disabled.
- [x] SMS remains explicit opt-in rather than preselected. Consent evidence is
  append-only and rechecked at delivery; inbound STOP/START compliance remains
  active. Waitlist SMS selection is treated as an explicit request for that
  opening notification.
- [x] A server-side enabled-channel allow-list prevents creation of deferred-
  channel messages and suppresses old queued messages before provider access.
  Existing provider adapters, consent and communication history are preserved
  for a deliberate later release rather than deleted.
- [x] Existing businesses are migrated to SMS, no fallback, no two-way inbox,
  no mobile marketing and one 24-hour reminder. Rescheduled appointments use a
  schedule-specific reminder key so an obsolete suppressed reminder cannot
  block the replacement.
- [x] Focused communications coverage passes 23 tests / 155 assertions and
  public-booking coverage passes 11 tests / 100 assertions. The complete suite
  passes 315 tests / 3,358 assertions with 28 intentional skips. Client and SSR
  production builds pass on Node 24.
- [ ] Live SMS is not enabled or certified by this change. OPEN-11 and OPEN-15,
  country-specific sender registration, public HTTPS callbacks, legal wording,
  STOP/START rehearsal and actual-device delivery remain launch gates.

## Branded business-account email and Amazon SES foundation (2026-09-20)

- [x] Password registration now sends a ClipperDesk verification email; verified
  owner provisioning sends a separate workspace/trial welcome, and first
  booking-page publication sends a one-time owner confirmation.
- [x] Verified users receive a new-browser/device sign-in alert by default.
  Password reset/change, old-and-new email change handling, two-factor enable/
  disable, recovery-code regeneration and recovery-code use each have a
  dedicated security message and clear recovery action.
- [x] Team invitations, invitation acceptance, access/role/location changes,
  revocation and restoration notify the affected team member. Owners are also
  notified when support access is approved, entered or revoked and when the
  platform suspends, closes or restores their workspace. Billing owners receive
  deduplicated trial, activation, plan-change, cancellation, renewal,
  restriction, recovery and termination messages through the existing billing
  notice schedule.
- [x] All Laravel notification email uses one responsive, plain-text-compatible
  ClipperDesk theme with Account, Security and Billing sender streams. Queued
  state-change mail waits for the database commit and uses bounded retries;
  verification and reset links remain immediate.
- [x] Laravel's Amazon SES transport is runtime-complete with the official AWS
  SDK, temporary-token and optional SES configuration-set support. Local/test
  remains non-sending unless explicitly changed.
- [x] A metadata-only delivery ledger retains tenant/user scope, message class,
  sender stream, masked/hashed destination, attempts, accepted/failed state and
  provider ID without storing a message body or plain recipient address. A
  scheduled retention command prunes expired sign-in fingerprints.
- [ ] Production mail is not certified by this local change. OPEN-11, verified
  domains, SES production access, SPF/DKIM/DMARC/custom MAIL FROM, bounce and
  complaint event destinations, suppression operations, queue monitoring and a
  live deliverability/rendering rehearsal remain required.

## Historical multi-channel messaging foundation (2026-09-20; user-facing scope superseded by ADR-041)

The following records the verified foundation as it existed on 2026-09-20.
ADR-041 now keeps non-SMS channels, fallback and the inbox dormant and removes
them from current owner/client surfaces without deleting historical evidence.

- [x] The owner workspace now presents two clear sender experiences: shared
  ClipperDesk messaging for business-labelled outbound notifications and an
  entitled business-branded client line for approved WhatsApp/SMS identities,
  direct replies and a tenant-scoped inbox. Sender identity is independent of
  usage credits and changing it does not rewrite communication history.
- [x] Appointment, walk-in and waitlist operations can select email plus the
  client's currently consented preferred SMS/WhatsApp route. SMS and WhatsApp
  have separate opt-in evidence, transactional purpose remains separate from
  marketing consent, and STOP/START keywords update durable suppression and
  consent evidence immediately.
- [x] Smart fallback queues only the preferred mobile message and holds the
  alternate channel until a definitive failure. Consent, template and sender
  readiness are rechecked before release, preventing optimistic duplicate
  WhatsApp/SMS outreach.
- [x] Branded sender profiles keep provider credentials encrypted and outside
  owner-facing payloads. Inbound replies route only through an exact active
  business sender; shared production inbound is intentionally disabled because
  it cannot identify a tenant safely. Sandbox inbound requires one explicitly
  configured Business.
- [x] Matched branded conversations include a reply composer. Replies are
  idempotent, consume the same visible allowance and recheck consent, plan,
  sender ownership and WhatsApp's 24-hour customer-service window immediately
  before provider delivery.
- [x] Transport promotion is configuration-only: `fake` makes no network call,
  `twilio_test` uses zero-charge SMS test credentials, `whatsapp_sandbox`
  requires an explicit Sandbox switch and may consume Twilio units, and `live`
  requires a separate production-send switch. Live authentication supports a
  restricted API key while webhook signatures retain a dedicated/Auth Token.
- [x] New booking and operational events dispatch immediately after their
  transaction commits, so local first delivery no longer depends on a running
  scheduler. The minute schedule now recovers both pending outbox events and due
  message retries, while an atomic message-state gate prevents duplicate
  provider calls. The Sandbox screen presents a three-step booking test guide
  and explicitly explains why a shared Sandbox identity cannot be selected as a
  business-branded line. Provider authentication/configuration failures are
  translated into owner-readable recovery guidance and can be retried from the
  delivery activity after the setup is corrected.
- [x] Starter and Pro currently include 100 and 1,000 mobile messages per
  billing period. Pro enables branded sender and two-way entitlements.
  Additional-credit purchasing and pricing remain deliberately deferred until
  the core provider workflow is externally certified.
- [x] The focused communications suite passes 20 tests / 159 assertions,
  including transport locks, fallback, inbound STOP/idempotency and credential
  non-exposure. The complete application suite passes 304 tests / 3,324
  assertions with 28 intentional skips. Client and SSR production builds pass
  on Node 24.
- [ ] Live sending is not certified or enabled. Complete provider sender and
  template approvals, country-specific SMS registration, public HTTPS callback
  verification, regional legal/privacy/quiet-hour review and end-to-end tests
  under ADR-039, OPEN-11 and OPEN-15 first.

## Team seats, secure invitations and owner activity (2026-09-14)

- [x] Team setup now creates the working StaffProfile and, when selected, an
  expiring login invitation in one owner workflow. A provider may still remain
  bookable without a login; accepting access links the canonical Membership,
  User and StaffProfile instead of creating a duplicate person.
- [x] Owners can choose Owner, Manager, Receptionist, Professional or Accountant
  starter access, or select an exact set of workspace modules. Client-facing
  titles remain an editable standard-role combobox and never grant permissions.
  Managers cannot grant Owner or any capability beyond their own role.
- [x] Invitation email uses a hashed, single-use, seven-day token. Existing
  identities sign in and return to the invitation; new invitees create their
  own password on the invitation page. Token possession verifies the invited
  email. Temporary passwords are not generated, stored or emailed.
- [x] Owners can change another member's role, module access and assigned
  locations, revoke login access with a required reason, and deliberately
  restore a former member with a second recorded reason. Revocation ends active
  sessions and tokens immediately while retaining the StaffProfile and
  historical attribution.
- [x] Team setup shows current plan seat usage, pending invitations and recent
  activity. A dedicated, permission-gated Activity log supports search and
  access/appointment/client/payment/configuration filters over append-only,
  redacted AuditEvent records.
- [x] Dedicated team-access coverage passes 4 tests / 83 assertions. The
  adjacent access, activation and shell checks pass 39 tests / 447 assertions;
  the complete application suite passes 296 tests / 3,257 assertions with 28
  intentional skips. Client and SSR production builds and all 17 frontsite
  budget entries pass on the bundled Node runtime.
- [ ] Production sender-domain certification and live invitation deliverability
  remain pre-launch operational checks. Current automated coverage uses the
  application notification contract and local test transport.

## Authenticated workspace design refinement (2026-09-13)

- [x] Shared workspace density now uses 40px desktop controls with 44px
  mobile/coarse-pointer targets, quieter borders, consistent surfaces, compact
  page hierarchy and a 240px grouped navigation sidebar. Branding and readable
  body text remain intact. ADR-037 records the density standard.
- [x] Authenticated select controls use a shared enhanced native-option
  component with search, multiple selection, disabled/selected states,
  viewport-aware popovers, keyboard navigation and required-field focus/error
  feedback. Services and provider creation use drawers with scrolling bodies
  and reachable action footers. Client section tabs have roving keyboard focus.
- [x] Calendar details and attention are collapsed initially; toggling the panel
  restores/reclaims the side column. Appointment selection opens actions and
  supports Enter/Space. Close/Escape returns focus to the toggle. Mobile brings
  the panel into view above the schedule. The clipped 07:00 label was corrected
  and verified in Day, Week and Team views.
- [x] Dashboard metrics, client search/list, service catalogue, calendar filters,
  setup controls, billing summaries, tables and empty states use the refined
  hierarchy. Reports retain applied filters when switching report type and
  display readable column names, scoped location/staff/service names and local
  times, with full source references available on demand.
- [x] Inventory is hidden from the shared desktop/mobile menu at the user's
  request. Underlying routes, implementation and entitlements remain intact.
- [x] Verified application suite: 292 passed / 3,174 assertions / 28 intentional
  skips. Final frontend checks: nine tests passed, client and SSR builds passed,
  all 17 frontsite budget entries passed, and diff whitespace checks passed.
  Visual/browser coverage includes owner dashboard, calendar and appointment
  actions, services, team drawer, clients/forms, business/booking/location setup,
  walk-in dialog, checkout empty state, billing and account forms. Representative
  mobile layouts were checked at 360px.
- [ ] Broader role, high-volume, cross-browser and assistive-technology testing
  remains outside this owner-session review. Platform administration received
  shared styling/build coverage, not an authenticated visual review. Live
  payments and destructive actions were not exercised.

Evidence and individual findings: [workspace refinement audit](audits/2026-09-13-workspace-refinement/README.md).

## Front-desk operations and setup refinement (2026-09-13)

- [x] The calendar now has genuinely distinct Day, Week and Team views plus a
  separate Today shortcut. Its continuous 07:00–20:00 location-time grid uses
  proportional start positions and durations, preserves a visible empty-day
  grid, marks the current time, and places overlapping visits in separate lanes.
- [x] Selecting a visit opens one consistent action panel for lifecycle status,
  reschedule, duration, staff reassignment, service changes, internal notes,
  duplicate/rebook, no-show, cancellation and completed-visit checkout. Failed
  dialog actions remain open with feedback; successful actions close cleanly.
  Cancelled and superseded appointment versions leave the active schedule but
  remain available through explicit status filters and append-only history.
- [x] Staff and client cancellation now start with a controlled, broad reason
  list and reveal free text only for Other. Client-requested choices are stored
  as client cancellations, business-caused choices as shop cancellations, and
  the resolved reason remains in auditable history and reporting.
- [x] Checkout is appointment-first and currently records only externally
  received manual tender (cash, UPI received, bank transfer or other). A full
  payment completes the existing canonical Sale once, issues a receipt, queues
  the payment-receipt email event, removes the visit from the ready list and
  feeds the implemented revenue/payment/location/staff reports. An additive,
  idempotent schema repair restores the sale-line service reference for
  databases whose earlier commerce migration was recorded without that column.
- [x] Walk-ins now choose an existing Client through tenant-scoped search or
  create a new Client immediately on queue entry. Queue, later Appointment,
  communications and Client history retain the same canonical client link.
- [x] Transactional appointment and receipt email is selected by default when
  an address exists and stops only after an explicit appointment/client email
  opt-out. WhatsApp and SMS are not presented by this release.
- [x] Location setup clearly lists every location, edits one at a time, creates
  another canonical Location when the plan permits, and always explains the
  location allowance with a direct plan path. Team setup uses one editable
  title combobox backed by a broad standard service-business role vocabulary;
  descriptive titles do not grant application permissions. New locations get
  an editable distinct-name suggestion, and duplicate names return inline
  validation instead of a database error page.
- [x] Reports display only the currently source-backed appointment, commerce,
  staff, client and cash reports. Product-sales and stock reports stay hidden
  until the inventory workflow is promoted into the user-facing release.
- [x] Focused operations coverage passes 39 tests / 439 assertions. The complete
  local suite passes 292 tests / 3,174 assertions with 28 intentional skips;
  client and SSR production builds and all 17 frontsite budget entries pass.
  The implementation/UX audit is recorded in
  [`audits/2026-09-13-operations-workflow/README.md`](audits/2026-09-13-operations-workflow/README.md).

## Adaptive onboarding and booking experience (2026-09-13)

- [x] New verified owners now enter a four-decision guided experience for
  business type, operating shape, first location and starter services. Large
  image choices, chips, regional defaults and schedule presets replace the
  former expectation that owners complete the full Business setup form first.
- [x] The versioned, retry-safe starter provisioner persists onboarding answers
  and creates an editable primary Location, local hours, owner StaffProfile,
  availability, category-aware starter Services, commerce settings and a
  collision-safe booking slug through the canonical tenant models.
- [x] Historical behavior: valid starter configuration was previewed and published
  immediately. **Superseded on 2026-10-05 by ADR-053:** preparation stays private,
  operational readiness leads to Calendar, and owners explicitly review/go live.
- [x] Business setup replaces Salon setup in owner-facing navigation. A
  persistent header status opens a focus-managed readiness drawer with required
  and recommended tasks, while every optional or advanced setting remains
  editable in the existing focused workspaces.
- [x] The public booking entry is now image-led and business-branded, with
  category filters, clear service cards, location/provider/date choices, a
  sticky visit summary, mobile summary controls and secure tenant-private
  logo/cover delivery. An industry image is the honest fallback until the
  business uploads its own artwork.
- [x] Public booking session state now carries its real expiry, rejects stale or
  legacy browser state, silently starts a fresh availability session when safe,
  and returns clients to refreshed times when a temporary hold ends. Server
  hold expiry and capacity revalidation remain unchanged.
- [x] Existing onboarding sessions were backfilled as guided-complete, so this
  release does not seed, overwrite or republish existing or partially
  configured tenants. New-session generation remains idempotent and audited.
- [x] The dedicated journey passes 4 tests / 89 assertions. The complete local
  PHP suite passes 285 tests / 3,102 assertions with 28 intentional skips, and
  client plus SSR production builds pass on Node 24. The combined design audit
  and screenshots are in
  [`audits/2026-09-13-onboarding-time-to-value.md`](audits/2026-09-13-onboarding-time-to-value.md).

## Stripe upgrade and interval-switch stabilization (2026-09-13)

- [x] Owner upgrades and billing-interval switches now open a focused Stripe
  Customer Portal `subscription_update_confirm` flow. Stripe presents the exact
  proration/effective date and owns payment failure plus 3-D Secure handling;
  ClipperDesk no longer creates an unresolvable local pending change before the
  customer confirms.
- [x] The server still selects and allow-lists the local catalog Price. Owner
  self-service omits lower-ranked plans and rejects downgrade requests at the
  backend; generic Portal sessions use a separate managed configuration with
  subscription changes disabled.
- [x] Signed subscription webhooks remain authoritative. A tenant-scoped return
  status endpoint can reconcile the mapped Subscription directly from Stripe
  when the webhook is delayed, then refresh the plan, interval, entitlements,
  billing period and latest invoice from the same projection path.
- [x] Metadata-identified Portal configurations converge automatically with the
  active local catalog. Annual-to-monthly and decreasing-price changes are
  scheduled at period end; other upgrades use Stripe's immediate invoiced
  proration behavior.
- [x] Replacing a legacy direct-update attempt safely supersedes its stale
  `pending_provider_plan_change` record only after Stripe returns a usable
  hosted confirmation session.
- [x] The full local PHP suite passes: 281 tests / 3,013 assertions with 28
  intentional skips. Client and SSR production builds pass on Node 24; Pint
  and whitespace validation pass for the changed billing surfaces.
- [ ] Complete one live Stripe test-mode upgrade, monthly-to-annual switch and
  annual-to-monthly scheduled switch before release. This remains an external
  certification gate, not an unverified implementation claim.

## Current state

The repository is a Larafast boilerplate being adopted as the base for
ClipperDesk, a barber shop and salon management SaaS. The Phase 1 product is
documented and its reusable product-shell, permanent identity, and tenant/access
foundation plus FR-01 subscription/entitlement, FR-02 through FR-05 business
configuration, the FR-06/FR-07 availability/hold/booking-commit core, and the
FR-06/FR-08 operational calendar, Appointment lifecycle, and walk-in queue are
implemented. FR-09/FR-10 public booking, secure self-service, and waitlist plus
FR-11/FR-12 Client CRM, protected context, forms, consent, attachments,
duplicates, and privacy cases are also implemented. FR-13 application-owned
email/SMS/WhatsApp communications, shared and branded sender modes, smart
fallback, tenant-safe inbound replies, local-time reminders, consent/
suppression, delivery evidence, callbacks, diagnostics, and safe replay are
implemented.
FR-14/FR-15 commerce and FR-16 through FR-18 Inventory, Commission/Tip,
dashboard, reporting, export, and Phase 1 metric instrumentation are implemented
and locally verified. FR-20 platform administration and the support-grant
workflow are implemented and locally verified.

## Public brand and industry acquisition refresh (2026-09-11)

- [x] The homepage now uses a photography-led editorial direction, a stronger
  beauty-and-wellness brand voice, clear trial and industry journeys, and real
  operational stories instead of a software-diagram-led presentation. Its
  repeated five- and six-step explainer grids have been consolidated into one
  concise brand rhythm and a three-moment editorial working-day narrative.
- [x] The shared public header, footer, buttons, conversion band, cards and page
  heroes use the same modern visual system across product, use-case, pricing,
  resource, editorial, company and security pages. Those page families now use
  photography-led split heroes, image-led discovery cards, editorial workflow
  rows, decision panels and trust/status treatments instead of relying on
  repeated text-only card grids.
- [x] The public header now uses a restrained floating navigation surface,
  clearer active-page treatment and a spacious responsive menu with direct
  Product, Industry, Use case, Pricing, Resource, Company, Security and account
  paths. The existing Escape, route-change, outside-click and focus-restoration
  behavior remains intact.
- [x] The solution hub publishes 13 differentiated, indexable industry pages:
  salons, barbershops, independent stylists, spa and sauna, nail salons,
  medspas, massage, fitness and recovery, physical therapy, health practices,
  tattoo and piercing, pet grooming, and tanning studios.
- [x] Regulated-industry pages keep explicit product boundaries and do not claim
  clinical records, diagnosis, prescriptions, insurance workflows or regulatory
  compliance that the product does not provide.
- [x] Thirteen industry images and six original editorial photographs are
  delivered as optimized WebP assets, and every image remains below the 550 KiB
  component budget. The deterministic sitemap contains 32 canonical public
  URLs.
- [x] The complete marketing suite passes 66 tests / 1,436 assertions. Client
  and SSR production builds pass on Node 24, and the frontsite budget gate
  passes for all 17 checked route entries. Browser QA verified the homepage,
  industry pages, product hub/detail, use-case and resource page families in
  the local preview.
- [x] The canonical acquisition position now describes ClipperDesk as
  appointment scheduling and service-business management software across
  beauty, wellness, personal care, fitness, recovery, health and pet-service
  businesses. Generic homepage, product, use-case, pricing, resource, blog and
  company copy no longer frames salons and barbershops as the only market;
  dedicated industry pages remain specific and retain their approved scope
  limits.
- [x] All 32 curated public URLs have unique, useful search titles and meta
  descriptions, canonical URLs, indexable SSR output and image-aware social
  metadata. The shared JSON-LD graph consistently identifies the Organization,
  WebSite, WebPage and SoftwareApplication, including the visible feature set
  and supported business audience without invented ratings, customers or
  certifications. `robots.txt` explicitly permits OAI-SearchBot and
  ChatGPT-User alongside general crawlers and publishes the canonical sitemap.

## Stripe subscription standardization (2026-08-29)

- [x] ADR-029 makes Stripe the sole active SaaS subscription provider while
  preserving the Business-owned normalized billing and entitlement domain.
- [x] Hosted Checkout, Customer Portal, exact server-side Price allow-listing,
  tenant-scoped idempotent checkout attempts, and signed/deduplicated/ordered
  webhook projection are implemented.
- [x] Trial notice/expiry, dunning/recovery, cancellation grace, plan changes,
  safe over-limit downgrades, read-only restricted access, RBAC separation,
  owner billing UX and platform support visibility are implemented.
- [x] Paddle runtime code, route, provider adapter, webhook processor, catalog
  command, frontend components and JavaScript dependency are removed.
  Historical provider rows and applied migrations remain evidence.
- [x] Focused billing/access coverage includes catalog provisioning, live-mode
  safety, LaraFast command compatibility, lifecycle state, workspace decision,
  onboarding, Location, role separation and operational route tests. The 2026-
  08-30 Wave 1 acceptance run passes 79 tests / 589 assertions with one
  intentional skip.
  Production client and SSR builds pass on Node 24. The complete PHP run reports
  265 passed / 2,345 assertions / 28 intentional skips; its only failure is the
  pre-existing frontsite budget check referencing two evidence images already
  deleted in the working tree before this change.
- [x] The managed Stripe catalog and corrective migrations are applied in the
  inspected local environment. The affected NorthFace Checkout was recovered
  from its stored Stripe Session using authenticated provider evidence and now
  projects Starter/active state, its current period, confirmed attempt, default
  Location, and Owner Location assignment.
- [x] New verified-owner onboarding now provisions that default Location
  idempotently. `WorkspaceAccessService` aligns navigation and backend entry
  checks across Membership permission, plan entitlement and assigned Location;
  expected plan/setup/permission denials render a polished product state rather
  than a raw 403 response.
- [x] Pending Checkout reconciliation runs through the authenticated status
  endpoint and every five minutes. Stripe `unpaid`/`paused` states map to
  read-only restriction; missing webhook readiness fails closed before a new
  payment is started.
- [x] Webhook projection converges when a subscription event arrives before its
  Checkout completion, refuses late activation from a superseded attempt, and
  understands both direct and current nested Stripe invoice ownership fields.
- [x] Selecting a different plan expires the prior Stripe-hosted Checkout
  before its local attempt is superseded, so an abandoned URL cannot remain a
  second payable subscription path. The local attempt is reserved under a
  subscription row lock, so a concurrent request fails safely while Stripe
  Checkout is being prepared instead of creating another Session.
- [x] Corrective migration `2026_08_30_000003` is applied locally. It repairs
  active Owner Location assignments, safely reactivates an existing default
  Location where needed, and does not broaden employee Location access.
- [x] The inspected local environment now reports Stripe server credentials,
  webhook verification, and Checkout readiness as configured without exposing
  their values. Live Checkout, Portal, test-clock, webhook retry, and settlement
  certification in the deployment target remain launch gates.

## Onboarding and Salon setup stabilization (2026-08-30)

- [x] Email registration now establishes a fresh authenticated web session,
  ignores stale protected intended URLs, and deliberately enters verification;
  verified owners continue to their idempotently provisioned Salon setup.
- [x] Settings is presented as guided Salon setup with six connected work areas,
  explicit required readiness states, optional improvements, and useful Staff
  and Availability summaries instead of duplicate empty sections. Its staff
  action uses the registered `shop.module` route, with a route-integrity
  regression test preventing verification-time blank screens.
- [x] The complete 249-country ISO catalog drives editable currency, locale,
  time-zone and phone defaults. Business and commerce currency/tax settings are
  synchronized, historical currency changes fail safely, and tenant money
  surfaces consume the shared regional projection.
- [x] One E.164 phone contract now covers setup, Client CRM, Calendar, Walk-in
  Queue, public booking/waitlist, privacy correction and secure contact update.
- [x] Authorized front-desk users can manually add a Client with exact-duplicate
  reuse and conservative review behavior. Unauthorized roles remain denied.
- [x] The original direct Stripe plan-update path was superseded on 2026-09-13
  by the focused hosted confirmation flow documented above. Lower-plan choices
  are absent from owner self-service and rejected server-side.
- [x] Registration QA has no console errors or horizontal overflow at desktop
  and 390 px. Current suite and build evidence is recorded in the newest status
  section rather than duplicated here.
- [ ] Live Stripe test-mode plan-change/recovery/Portal certification remains a
  release gate even though the local Stripe readiness checks now pass.

## Wave 2 business activation (2026-08-31)

- [x] The oversized first-bookable-path form is no longer the primary owner
  experience. Salon setup is a launch task centre with canonical deep links to
  focused Location, Team & availability, and Services workspaces.
- [x] Location activation reuses the provisioned default Location, confirms its
  public address/contact/time zone, replaces its normal weekly hours atomically,
  assigns the Owner Membership, applies the Location plan limit when a new row
  is actually needed, advances onboarding, and records audit evidence.
- [x] Team activation creates or safely reuses a provider by normalized email,
  keeps StaffProfile separate from optional User/Membership login access,
  validates the weekly schedule, applies the staff limit, assigns Location and
  optional Services, advances both staff readiness steps, and records audit
  evidence.
- [x] Services now has a dedicated catalogue/editor rather than a placeholder.
  It server-derives currency/tax context, validates tenant-owned Location and
  provider assignments, persists effective booking segments without deleting
  segment records referenced by historic appointments, supports safe archive
  and restore, and exposes delivery-path readiness.
- [x] The sidebar routes directly to Team & availability and Services. The
  former `first-bookable-path` endpoint remains temporarily for compatibility,
  but the product no longer depends on it for activation.
- [x] The Wave 2 acceptance test proves one verified/paid Owner can configure a
  Location, non-login provider and Service through the focused HTTP workspaces,
  retry all three writes without duplicates, preview/publish, discover a real
  slot, hold it, and receive a confirmed public booking and Client record.
  It also covers cross-tenant and role denial.
- [x] Focused Wave 2/regression coverage passes 36 tests / 342 assertions with
  one intentional registration skip. The dedicated exit test passes 2 tests /
  71 assertions. Client and SSR production builds pass on Node 24.
- [x] The whole PHP suite now reports 266 passed / 2,418 assertions / 28
  intentional skips. Its only failure remains the pre-existing frontsite budget
  test for two product-shell evidence PNGs deleted in the working tree before
  Wave 2; no Wave 2 or ProductShell regression remains.
- [ ] Advanced Epic 3/4 follow-ups remain intentionally outside this Wave 2
  exit: bulk service actions/templates, rich resource editing, provider profile
  edit/invite controls, split-shift/break/leave visual editors, and optimistic
  concurrency/version UI. The underlying domain models and existing impact
  preview routes remain available for those increments.

## Enterprise public homepage (2026-08-27)

- [x] The public homepage now presents ClipperDesk as one connected salon and
  barbershop operating system through a detailed product-led hero, five-step
  operating loop, booking-to-reporting journey, three alternating product-proof
  sections, audience fit, trial/pricing bridge, FAQ, and closing conversion band.
- [x] The final visual combines the selected clean enterprise composition with
  a custom orbital operating-system model and three matching conceptual 3D
  illustrations for scheduling, client context, and checkout/reporting. These
  replace literal product screenshots and device frames, sit directly on the
  white canvas without grey stage panels, and use compressed WebP delivery.
  Restrained ambient float, pointer depth, module hover/focus state, and a
  reduced-motion fallback provide professional movement without adding a heavy
  3D runtime.
- [x] In-app browser verification covered the 1440 px desktop homepage and
  390 px mobile layout, CTA destinations, image loading, mobile navigation,
  FAQ disclosure, horizontal overflow, and browser console output. The final
  design comparison is recorded in `design-qa.md` with a passed result.
- [x] The focused homepage tests passed with 41 assertions; the complete
  marketing suite passed 55 tests / 857 assertions. The 17-route front-site
  budget check and client/SSR production builds also passed.

## ClipperDesk design-system and identity overhaul (2026-08-25)

- [x] ADR-027 supersedes the former Good Hours presentation identity with
  ClipperDesk while preserving durable provider, migration, schema, cache, seed,
  and calendar identifiers where changing them would break compatibility or
  historical evidence.
- [x] `config/brand.php` now centralizes public product/company identity, copy,
  asset paths, support identity, URLs, booking host, and a server-to-client brand
  projection. Inertia titles, SEO metadata/schema, email, notifications, PDFs,
  public booking, auth, billing, Filament, and application shell surfaces consume
  shared values where practical.
- [x] `resources/css/app.css` now defines the ClipperDesk semantic system for
  brand, canvas, surface, text, border, action, navigation, focus, status,
  disabled, typography, spacing, radius, shadow, and DaisyUI compatibility roles.
- [x] The identity uses deep navy, indigo action, restrained cyan accent,
  cool-gray canvases, white working surfaces, and self-hosted Manrope. The
  revised SVG identity is a flat interlocking C/D monogram with no enclosing app
  tile; horizontal, inverse, mark, favicon, and social-preview variants exist.
- [x] The public footer is a light neutral continuation of the page. Public
  acquisition, auth, booking, tenant work, platform administration, billing,
  configuration, generated documents, and error surfaces share the same tokens
  without forcing the same layout.
- [x] Representative in-app browser checks covered the homepage, pricing, login,
  registration, booking, 404, dashboard, calendar, Clients, Staff, billing,
  configuration, platform administration, and mobile navigation. Every checked
  page had no horizontal overflow or visible Good Hours copy; controls were
  labelled. Mobile billing interval, invoice-document, and dashboard-report
  targets discovered during QA were raised to the 44px interaction target.
- [x] Final verification: Pint passed, the client and SSR production builds
  passed, and front-site budgets passed for 17 route entries. The PHP suite
  reported 262 passed / 2,371 assertions / 28 intentional skips after the
  Google authentication delivery; its sole
  unrelated failure is the existing fixed-date scheduling case at
  `CalendarWalkInOperationsTest.php:274`, which tries to create an August 17
  appointment after that date has passed.

## Google authentication and enterprise auth screens (2026-08-26)

- [x] ADR-028 replaces the unsafe arbitrary-driver Larafast Socialite path with
  three explicit, guest-only, rate-limited Google routes using OAuth state and
  Google-asserted verified email.
- [x] Existing accounts link safely by normalized verified email, conflicting
  Google links are rejected, provider tokens are not retained, database
  uniqueness prevents identity drift, and configured TOTP challenges remain in
  the login path.
- [x] New Google owners complete a ten-minute server-side Business-details and
  legal-acceptance step before the existing exactly-once verified-owner tenant,
  membership, and trial bootstrap runs. Password reset remains an independent
  recovery path.
- [x] Login and registration now use a photography-led two-panel auth shell on
  desktop and a focused single-column form on smaller screens. The technical
  dashboard mockup was replaced with real-business editorial imagery and page-
  specific brand stories; the Google-first hierarchy, secure-access context,
  semantic error/status treatments, labelled controls and appropriate
  autocomplete remain intact.
- [x] The refreshed login, registration, public header and responsive menu were
  reviewed in the local browser. Focused authentication, Google, product-shell,
  public-shell and technical-SEO coverage passes 39 tests / 361 assertions;
  client and SSR production builds plus the 17-route frontsite budget gate pass.
- [x] The local MySQL hardening migration ran successfully. Seven focused Google
  authentication tests and the 17-case tenant-isolation suite passed; production
  client/SSR builds and the 17-route front-site budget check passed.

## Prompt 13 launch-readiness decision

**NO-GO for limited paid launch and general availability.** The complete
versioned evidence is in
[`release/2026-08-16-limited-paid-launch/`](release/2026-08-16-limited-paid-launch/README.md).
Local regression, dedicated MySQL concurrency, production builds, dependency
advisory remediation, a production-mode Chromium smoke pass, and a synthetic
MySQL dump/restore pass. They do not replace production provider, topology,
legal, accessibility, browser-matrix, monitoring, or operational sign-off.

Prompt 13 hardening added HTTP correlation/security/no-store controls, updated
the PHP/frontend dependency locks to zero known advisories at the dated lookup,
made the demo tenant's trial/subscription journey complete, and restored the
Checkout & Sales screen to the authenticated application shell. Final local
suite: **201 passed, 1,450 assertions, 28 intentional skips in 17.27 seconds**. Dedicated MySQL:
**12 passed, 48 assertions**; availability search 212.75 ms/786 queries,
booking commit 20.79 ms/63 queries, and 32-event calendar 9.52 ms/9 queries.

Critical launch blockers are live Stripe certification, OPEN-10
retention/privacy authority, India legal/accounting review, and production
backup/RPO/RTO/DR/rollback evidence. High blockers are external penetration
testing plus upload malware scanning, target-topology load/burst evidence,
production observability/on-call/status operation, Resend/Twilio certification,
and independent WCAG/supported-browser verification. There are no approved
risk waivers and no named human sign-offs.

Documentation foundation:

- [x] Complete Word PRD reviewed, including all 32 rendered pages
- [x] Complete PRD transcribed to canonical Markdown
- [x] Product, architecture, domain, quality, module, and roadmap documents
  initialized
- [x] Dependency-aware implementation prompts prepared
- [x] ClipperDesk name, mark, voice, palette, typography, and configurable
  message identity accepted in ADR-027; trademark/domain/sender approval remains
  OPEN-11
- [ ] Exact first-country order, currencies, tax posture and privacy regimes
  confirmed for the United States, Canada, United Kingdom and selected Europe
- [x] ADR-039 supersedes ADR-019's communications direction with email, SMS and
  WhatsApp, shared/branded senders, consent-safe fallback and explicit transport
  promotion; regional legal and provider approval remains open under OPEN-15
- [x] Larafast reuse and removal audit completed; recommendations await approval
- [x] Phase 1 implementation started with the product-shell foundation

Implemented product-shell foundation:

- [x] Authenticated responsive shop shell with every PRD Section 10 destination
- [x] Separate public booking and secure self-service shell
- [x] Separate, role-gated, visibly marked platform-administration shell
- [x] Semantic tokens and reusable page, action, form, table, card, dialog,
  toast, skeleton, empty, loading, error, success, and destructive patterns
- [x] Focus-visible, reduced-motion, labelled landmarks, mobile focus-managed
  navigation, and 44px touch-target conventions
- [x] Honest requirement-linked placeholders with no fake salon workflow data
- [x] ClipperDesk SVG mark/lockups, Manrope type system, navy/indigo/cyan
  semantic palette, product voice, auth identity, shell branding, and public
  booking language
  integrated without changing domain workflow scope
- [x] Prompt 01–09 UI/UX adoption review completed against the canonical design
  guide: all existing user-facing Vue pages were reviewed; shared shells,
  dashboard, calendar, queue, billing, configuration, booking/self-service,
  Client CRM/forms/privacy, and platform-readiness surfaces were updated and
  browser-verified at desktop and representative mobile widths
- [x] Dashboard offers Command desk, Rhythm board, and Guided front desk views
  over the same tenant-scoped operational data, with a per-user device-local
  preference and no change to authorization or scheduling truth
- [ ] Prompt 09 has no dedicated business-facing communications settings or
  delivery-log Vue page; its implemented HTTP diagnostics and provider behavior
  remain backend/operations capabilities until a requirement promotes that UI
- [x] Brand domains and sender addresses are configuration-driven; final domain
  acquisition, trademark clearance, and authenticated sending remain OPEN-11

Implemented tenancy, identity, access, and audit foundation:

- [x] Explicit Business tenant context and Business-owned Location lineage;
  shop URLs carry a Business public ULID and resolve active Membership before
  child bindings/policies
- [x] User, Membership, and StaffProfile separation with unambiguous factories
  and cross-Business/location database constraints
- [x] Owner, Manager, Receptionist, Barber/Stylist, and Accountant starter
  roles plus exact custom Business roles and direct Membership grants
- [x] Policy permissions for calendar all/own, Client view/contact/edit/note,
  sensitive notes, attachments, forms, merge, privacy, appointment deletion,
  discounts, refunds, revenue, commissions, inventory, settings, billing,
  staff, audit, and exports
- [x] Expiring, revocable, single-use, token-hashed invitations bound to email,
  Business, role, optional StaffProfile, and validated Locations
- [x] Membership removal denies the next request, deletes database sessions and
  applicable Sanctum tokens, rotates remember tokens, and writes audit evidence
- [x] Append-only application audit skeleton with actor/tenant/target/source,
  correlation, reason, before/after, and sensitive-key redaction
- [x] Tenant-aware job payload/middleware, private-file namespace, cache-key,
  search-envelope, and export-name conventions
- [x] Separate expiring platform roles; platform administration requires
  verified email plus confirmed TOTP and cannot enter a tenant without
  Membership
- [x] Magic-link and unrestricted social-login routes remain disabled; ADR-028
  enables only a stateful, verified-email Google path with short owner signup
  continuation, unique account binding, no retained OAuth token, password-reset
  recovery, and the existing TOTP challenge
- [x] Plain test execution isolated to SQLite `:memory:`; legacy disabled Team
  tests now skip instead of failing
- [x] Tenant-isolation evidence matrix recorded in
  [`tenant-isolation-matrix.md`](tenant-isolation-matrix.md)

Implemented FR-01 subscription and entitlement foundation:

- [x] Stripe is the sole ClipperDesk SaaS subscription provider behind the
  Business-owned provider contract (ADR-029); Paddle runtime code, routes,
  components, command and JavaScript dependency are removed while historical
  financial rows and applied migrations remain intact
- [x] The approved Starter (USD 50 monthly / USD 500 annual) and Pro (USD 100
  monthly / USD 1,000 annual) catalog is centralized in `config/billing.php`
  with environment-specific, command-managed Stripe Price mappings and
  effective-dated, server-enforced entitlements
- [x] The LaraFast product/price command is standardized on the Business-owned
  catalog: `--provision` idempotently creates or updates managed Products,
  creates immutable replacement Prices for amount changes, transfers stable
  lookup keys, commits local mappings before archiving prior Prices, and
  requires explicit `--force` for live-mode mutations
- [x] `billing:sync-stripe-catalog` previews without writes by default and, with
  `--apply`, verifies active recurring interval, currency and amount in Stripe
  before synchronizing local plan, price and entitlement history
- [x] Verified owner registration creates one locked registration intent and,
  only after verification, exactly one Business, Owner Membership, and dated
  trial even when the verification event is replayed
- [x] Business-owned normalized plans, monthly/annual effective prices,
  subscription state, append-only changes, invoices, payments, coupons,
  provider events, retry notices, usage, and entitlement overrides
- [x] Responsive owner billing surface shows trial, renewal, cancellation,
  dunning, usage and plan-change state; the review page starts Stripe-hosted
  Checkout and the Stripe Customer Portal owns sensitive payment-method,
  invoice and billing-address controls
- [x] Checkout creates a tenant-scoped, expiring attempt with an idempotency key;
  it accepts only an exact configured plan/interval/amount/Stripe Price match,
  safely reuses a live duplicate attempt, and never trusts browser completion as
  paid evidence
- [x] Checkout, subscription, invoice and payment-failure webhooks are
  signature-verified, application-marked, tenant-matched, deduplicated,
  retry-safe and ordered by provider occurrence time
- [x] Failed-renewal warning, retry/grace, read-only restriction, safe payment
  recovery, termination, and dated export-availability behavior
- [x] Feature and numeric entitlement catalog with server checks reusable by
  HTTP actions/APIs, domain services, jobs, and imports
- [x] Mobile-message usage is atomically reserved per billing period at the
  delivery boundary, reused across retries, and fails closed before provider
  delivery when the plan allowance is exhausted
- [x] Over-limit downgrades schedule for period end, snapshot usage/limits,
  preserve existing records, and deny only increasing operations after effect
- [x] Stripe webhook signature verification, event ID/payload
  deduplication, provider-time ordering, failed-event replay, and scheduled
  reconciliation contracts
- [x] Existing Business roles are backfilled when a permission is introduced;
  missing permissions fail closed rather than raising a framework exception
- [x] Staff scheduling policy failures are returned as in-app form feedback;
  dashboard actions are permission-aware and the account profile renders
  without a tenant context
- [x] Legacy User/Cashier and Lemon Squeezy production routes/listeners remain
  quarantined without deleting unknown legacy data; they do not own current
  subscription access
- [x] Stripe migration audit recorded in
  [`audits/2026-08-29-stripe-subscription-migration-audit.md`](audits/2026-08-29-stripe-subscription-migration-audit.md)

Implemented FR-02 through FR-05 business configuration:

- [x] Resumable business-details, hours, services, staff, availability,
  booking-rules, import, preview, and publish workflow
- [x] Explicit readiness blockers and optional improvements, with no vague
  completion percentage
- [x] Locale, currency, IANA time zone, week start, tax posture, cancellation,
  terms/privacy, private branding, and globally unique booking-slug aliases
- [x] Location normal/special hours, holidays, closures, reusable resource
  quantities/hours/maintenance, and persisted affected-appointment previews
- [x] Service/add-on categories, active/processing/cleanup segments, price,
  tax, deposit, notice, visibility, eligibility, qualification, and resource
  rules
- [x] Staff profiles/invitations foundation, Location/service assignments,
  staff variants, split schedules, breaks, leave, sickness, temporary changes,
  and overlap/travel-impossible schedule rejection
- [x] Effective service and capacity resolvers plus immutable historical
  configuration snapshots
- [x] Tenant-aware CSV import jobs for clients, staff, services, and products
  with templates, mappings, validation/error preview, duplicate review,
  progress/count summaries, replay safety, and private error exports; reviewed
  Client rows now project into the authoritative CRM aggregate
- [x] Production-like Pine & Palm Studio demo reaches publishable readiness in
  a recorded 24 minutes through `GoodHoursDemoSeeder`
- [x] Booking-engine boundary frozen as the read-only
  `AvailabilityConfiguration` and `AppointmentImpactSource` contracts; no
  search, capacity hold, commit, or calendar behavior was introduced by Prompt
  04

Implemented FR-06/FR-07 availability and booking core:

- [x] One shared rule engine for Location/special hours/closures, interval,
  notice/advance, Service eligibility and immutable effective values, Staff
  qualification/schedule/break/leave/personal block/Location/travel overlap,
  Resource hours/maintenance/quantity/segment occupancy, Appointments, and
  unexpired Holds
- [x] Preferred Staff with explicit any-qualified fallback plus per-segment
  qualified-provider handoff and staff release during processing
- [x] Advisory bounded availability query and commit-time revalidation through
  the same engine
- [x] Stable replay-safe capacity Holds with deterministic expiry and
  stale-snapshot rejection at confirmation
- [x] Direct and Hold-based atomic Appointment commit including every Service
  Line, Segment, Resource Claim, immutable configuration snapshot, and initial
  status-history record
- [x] Deterministic MySQL Staff/Resource root locking, pooled quantity checks,
  half-open UTC overlap rules, five-attempt deadlock retry, and Business-scoped
  command idempotency
- [x] Scheduling-backed Appointment impact source for Location, Staff, Service,
  and Physical Resource changes
- [x] Domain error codes/messages do not disclose private break, leave,
  maintenance, Appointment, or schedule details
- [x] Architecture guard prevents current controllers, Filament, and Vue source
  from importing Appointment persistence instead of use-case commands

Implemented FR-06/FR-08 calendar and walk-in operations:

- [x] Authenticated today/day/week/staff calendar with Location, Staff, Service,
  and status filters plus printable daily schedule
- [x] Accessible text/border/icon cues for Appointment state, walk-ins, blocks,
  late work, and work in service; no status depends on color alone
- [x] Create/multi-service, move/drag confirmation, resize, reassign,
  add/remove service, duplicate, rebook, internal-note, block, cancel/no-show,
  and controlled lifecycle actions
- [x] Optimistic version checks and Business-scoped operation keys for replay
  and concurrent stale-edit rejection
- [x] Linked replacement Appointments preserve the terminal original and run
  every new time/provider/service claim through commit revalidation
- [x] Manager override is limited to notice/advance policy warnings and requires
  permission, acknowledgement, reason, append-only change evidence, and audit;
  capacity/integrity conflicts remain non-overridable
- [x] Evidence-based walk-in estimates, queue position/reasoned reorder,
  assignment, notification intent, safe Appointment conversion/service start,
  abandonment, and actual-wait history
- [x] Late arrival, service overrun, staff-unavailable, and unexpected-closure
  impact/recovery records with internal notification events
- [x] Every local front-desk time is parsed in the selected Location IANA time
  zone and stored/compared in UTC
- [x] Idempotent `FrontDeskDaySeeder` simulates 8 appointments, 2 waiting
  walk-ins, and 1 block across realistic statuses

Implemented FR-09/FR-10 public booking and waitlist:

- [x] Passwordless mobile Location, Service/add-on, any/preferred Staff,
  local-date/time, details, policy, consent, and confirmation journey
- [x] One authoritative availability/Hold/commit path with policy-version and
  commit-time capacity revalidation; no duplicate public booking rules
- [x] Correct effective price/duration/deposit presentation, explicit add-on
  lines, cancellation/terms/privacy snapshot, and fail-closed unconnected
  deposit state pending Prompt 10
- [x] Booking reference, downloadable calendar event, refresh-safe flow state,
  privacy-safe conversion events, and public rate limits
- [x] Hashed, expiring, purpose-bound Appointment links for view, reschedule,
  cancellation, rebook, contact, waitlist join/leave, and payment status
- [x] Shop controls for online availability, Staff-selection mode, exact/from
  pricing, new-client eligibility, cancellation cutoff, offer batch size, and
  link lifetime with versioned policy snapshots
- [x] Tenant-scoped waitlist preferences, active duplicate prevention,
  availability-backed matching, controlled batches, expiry, retained offer
  history, versioned leave, and atomic first-valid claim
- [x] Contact/cancel/reschedule changes revoke older secure links and return a
  fresh view link; references are never an authentication mechanism

Implemented FR-11/FR-12 Client CRM and consent:

- [x] Booking, walk-in conversion, and reviewed Client CSV import create or
  conservatively match a tenant-owned Client with searchable normalized
  identity and retained display values
- [x] Same-contact spelling variations create review candidates, never fuzzy
  automatic merges; exact same identity safely reuses one profile
- [x] Responsive role-filtered Client directory/profile with birthday,
  encrypted preferences, communication choices, preferred Staff/Services,
  referral, tenant-scoped tags, consent state, visit summary,
  Appointment/service/performer history, and explicit unavailable financial
  history until checkout owns it
- [x] Encrypted authored allergy, sensitivity, formula, hair/skin/treatment,
  patch-test, preference, warning, and general Notes with narrower sensitive
  permission and preserved deactivated-Staff attribution
- [x] Optimistic Client versions reject stale concurrent edits; contact changes
  preserve history and revoke future vulnerable Appointment links
- [x] Permissioned, previewed, reasoned Client merge locks both profiles,
  selects one survivor, preserves every current relationship/tag and immutable
  submission snapshot, retains the losing identity, and writes safe audit
  evidence
- [x] Staff-facing form builder, six published starter forms, Service
  association, immutable template versions, pre-Appointment request/due state,
  Calendar/profile completion cues, and hashed expiring one-use public links
- [x] Immutable exact form wording/fields, encrypted answers/signature/identity,
  Client, Appointment, version, and submission-time evidence; later publishing
  cannot rewrite prior submissions
- [x] Tenant-private JPEG/PNG/PDF attachments and before/after images with MIME,
  size, SHA-256, visibility, retention class, and revocable expiring access
- [x] Tracked export, correction, Consent withdrawal, and
  deletion/anonymisation review cases with deadlines, reviewer/result/audit,
  private minimized export artifacts, and link rotation
- [x] ADR-018 safely bounds unresolved OPEN-02/OPEN-10: destructive processing
  enters `blocked_policy`, records retained-data evidence, and applies no
  deletion/anonymisation until launch policy authorizes an executor

Implemented FR-13 reliable communications:

- [x] ADR-039 supersedes ADR-019's India-only launch direction: the target
  regions are the United States, Canada, the United Kingdom and selected Europe;
  email, SMS and WhatsApp remain behind application-owned contracts. Exact
  country launch order and regional certification remain open under OPEN-15.
- [x] Versioned tenant templates cover confirmation, pending, approval,
  rejection, reminders, changes, cancellation, deposits, receipts, waitlist,
  queue, feedback, and rebooking with allow-listed variables, validation,
  preview, fallbacks, locale fallback, and an approved WhatsApp Content SID gate
- [x] Operational events converge on one immutable intent and at most one
  encrypted-recipient message per event/channel/recipient; bounded attempts
  reuse the stable provider idempotency key
- [x] Reminder offsets and overnight quiet hours resolve in the governing IANA
  time zone before UTC persistence and never push a reminder past its
  Appointment; cancellation/reschedule and consent changes are checked
  immediately before provider access
- [x] Transactional/legal basis remains distinct from explicit marketing
  consent; SMS and WhatsApp always require channel opt-in; unsubscribe, STOP,
  START, marketing/all suppression, invalid destination, bounce, and complaint
  paths are durable
- [x] Tenant-aware queued jobs carry Business and correlation UUID; provider
  callbacks verify signatures, deduplicate event IDs/payload hashes, and ignore
  older states that would rewind delivery
- [x] Client/source history, privacy export, and merge registries include
  content-minimized communication evidence; support diagnostics omit destination
  and content and replay only through a bounded, reasoned, audited idempotent
  tenant-settings path without bypassing the pending ADR-009 support grant
- [x] Purpose-bound short-lived action records are revocable/consumable and
  reconstruct signed URLs without storing raw bearer tokens

Implemented FR-16 through FR-18 management foundation:

- [x] Tenant Product Category/Product catalog with SKU/barcode, integer-minor
  sale/cost/tax inputs, status, aggregate and Location stock, low-stock
  threshold, exact version-1 CSV import/export, and row-level rollback/errors
- [x] Locked, replay-safe stock receipt, reasoned manual adjustment, completed
  Sale deduction, and refund/void `restock`/`write_off`/`customer_keeps`
  disposition through an append-only before/after movement ledger
- [x] Effective-dated Service percentage, Product percentage, and fixed-Service
  rules plus discounted-line calculation, immutable earned/reversal/adjustment
  Commission and Tip entries, Staff statement, and queued payroll export
- [x] Permission/location/staff-filtered today dashboard with every visible
  count/value linked to its source report and explicit UTC freshness/Location
  IANA time zone
- [x] Complete Phase 1 report catalog with shared date/Location/Staff/Service/
  status filters, stable prior-period comparison, source IDs/drill links,
  queued CSV, printable summaries, and payment/Sale reconciliation
- [x] Central metric version `1.0.0` plus allow-listed idempotent acquisition,
  activation, booking, reliability, revenue-protection, operations, retention,
  usage, and support event definitions that reject direct contact values
- [x] Tenant-aware export jobs persist and re-authorize the requesting
  Membership, Location/Staff scope, and normalized filters before writing a
  private hashed artifact

## Verified repository baseline

- Backend manifest targets PHP 8.3 and Laravel 13.
- `composer.lock` currently records Laravel 13.25.0, Filament 5.7.6, Inertia
  Laravel 2.0.25, Livewire 4.4.0, Cashier 16.7.0, and Ziggy 2.6.3.
- Frontend lock data records Vue 3.5.34, Inertia Vue 3.6.1, Tailwind CSS
  4.1.14, DaisyUI 5.1.27, and Vite 8.2.1. Frontend tooling requires Node
  22.12 or newer; `.nvmrc` pins the verified Node 24.19.0 baseline.
- Existing boilerplate includes Jetstream Team code, but Team/invitation and API
  token features are disabled. Registration no longer creates a personal Team;
  retained Team tests skip explicitly while the disabled legacy schema awaits a
  separately reviewed cleanup/backfill decision.
- Authentication, social login, magic links, multiple billing integrations,
  invoices, a Filament admin panel, global roles/permissions, marketing pages,
  blog, roadmap, and changelog are present but not approved as salon behavior.
- Booted route evidence reports 202 routes. The repository has 38 migration
  files and 35 feature-test files. Counts include the FR-13 provider callbacks,
  template/settings, support diagnostic/replay, and action-link surfaces.
- The configured local environment uses MySQL, sync queues, database sessions,
  file cache, and UTC. The public storage link and Sentry DSN are absent.
- `User` implements `MustVerifyEmail`; Spatie Business scoping is enabled on
  Membership-backed roles; Business, Location, Membership, StaffProfile,
  StaffInvitation, AuditEvent, and legacy Invoice policies are registered.
  Normalized Business billing is active. Unapproved billing/provider resources
  and tables remain quarantined legacy boilerplate.
- The real `.env` is ignored and untracked. The tracked examples contain empty,
  null, variable, or obvious provider placeholders, and a tracked-source scan
  found no recognized live token pattern.
- The repository's `CLAUDE.md` package-version summary is stale and must not be
  used as version authority.

## Verification baseline (2026-08-10)

- `php artisan about`: application boots on Laravel 13.8.0 and PHP 8.4.8.
- Safe isolated test command using in-memory SQLite: 41 passed, 10 failed, 6
  skipped, 117 assertions in 5.50 seconds. All failures are Team tests while
  Team support is disabled. API-token and Team-invitation tests skip because
  those features are disabled.
- Plain `php artisan test` was not run because `.env.testing` is absent,
  `phpunit.xml` does not override the database, local configuration points to
  MySQL, and most feature tests use `RefreshDatabase`. This is a data-loss risk
  until test isolation is enforced.
- `vendor/bin/pint --test` fails with 19 files requiring formatting. The audit
  did not rewrite them.
- `npm run build` passes both client and SSR builds (1,194 client modules and 98
  SSR modules). CSS optimization emits two warnings for the `@property` rule.
- `composer audit --locked --no-dev --format=plain` reports 45 advisories
  affecting 19 packages, including hicd-severity findings.
- `npm audit --json` reports 19 vulnerable packages: 2 critical, 14 high, and 3
  moderate. Fixes are reported available.
- Full evidence and classifications are in
  [`audits/2026-08-10-larafast-adoption-audit.md`](audits/2026-08-10-larafast-adoption-audit.md).

### Product-shell verification (2026-08-10)

- `DB_CONNECTION=sqlite DB_DATABASE=:memory: php artisan test
  tests/Feature/ProductShellTest.php`: 17 passed, 194 assertions in 0.63s.
  Evidence covers public pages, authenticated route boundaries, all ten shop
  placeholders, unknown-route denial, ordinary-user platform denial,
  platform-admin access, the reusable pattern reference, semantic focus tokens,
  and reduced-motion CSS.
- `npm run build`: client and SSR builds passed; client transformed 1,205
  modules and SSR transformed 112 modules. DaisyUI still emits the two known
  CSS optimizer warnings for its `@property --radialprogress` rule.
- Targeted Pint run over the changed PHP middleware, routes, and test passed
  after formatting `routes/web.php`.
- Browser checks passed at 360x800, 768x900, and 1440x950. Shop and public
  pages reported no horizontal overflow at 360px. No visible action in the
  360px shop/public checks was smaller than 44x44; the corrected platform menu
  trigger measured 44x44.
- Both shop and platform mobile drawers moved focus to the first destination,
  exposed dialog/modal semantics, closed on Escape, and returned focus to the
  trigger. Keyboard focus rendered a 3px `#1677cc` solid outline with 3px
  offset. The loaded stylesheet exposed the reduced-motion media rule.
- Browser-computed contrast samples were 15.52:1 for strong heading text,
  5.95:1 for primary semantic text, and 4.8:1 for muted footer text. Public
  controls had accessible names, main/header/footer landmarks were present,
  and the final browser run reported zero console errors.
- The interface-pattern browser check verified destructive-dialog labelling,
  initial focus on Cancel, Escape close, and a polite success toast with a
  labelled dismiss button. The local PHP 8.4 preview server emitted the known
  vendor deprecation for `Tightenco\Ziggy\Ziggy::__construct()` nullable typing;
  it did not affect route rendering.
- Screenshot evidence: [`evidence/product-shell/`](evidence/product-shell/)
  contains public booking at 360px, shop dashboard at 360px, 768px, and 1440px,
  platform administration at 1440px, and the interface-pattern reference at
  1440px.

### Superseded Good Hours identity verification (2026-08-11)

- `DB_CONNECTION=sqlite DB_DATABASE=:memory: php artisan test
  tests/Feature/ProductShellTest.php`: 18 passed, 207 assertions in 0.88s.
  This historical coverage included the Good Hours name, tagline, mark, public and
  authenticated identity, platform distinction, and permanent brand tokens.
- `npm run build`: client and SSR builds passed after the brand integration;
  client transformed 1,210 modules and SSR transformed 113 modules. The build
  retains public font URLs for runtime resolution and emits the two existing
  DaisyUI optimizer warnings for `@property --radialprogress`.
- Browser checks passed for public booking at 360x800, the shop shell at
  360x800, 768x900, and 1488x1058, and platform administration at 1440x950.
  No checked viewport had page-level horizontal overflow. Mobile actions met
  the 44px target, and the desktop identity capture ran at device-pixel ratio
  1.
- The shop navigation drawer moved focus into the dialog, closed on Escape,
  and returned focus to its trigger. Visible keyboard focus measured a 3px
  solid `rgb(11, 110, 173)` outline with a 3px offset. The reduced-motion rule
  remained present in the loaded stylesheet.
- Public-shell computed contrast was 14.72:1 for the strong heading, 5.01:1
  for muted footer text, and 5.24:1 for white primary-action text. The checked
  public state exposed header, main, and footer landmarks, no unnamed controls,
  and zero browser-console errors.
- Side-by-side full-view and focused-region comparisons passed. Exact source,
  implementation, viewport, interaction, responsive, accessibility, and
  comparison-history evidence is recorded in the project-root
  [`design-qa.md`](../design-qa.md). Supporting captures are under
  [`evidence/product-shell/`](evidence/product-shell/).

### Tenancy, identity, access, and audit verification (2026-08-11)

- `php artisan test`: 78 passed, 16 skipped, 410 assertions in 6.33 seconds.
  The skips are explicit disabled-feature coverage for Jetstream Teams/team
  invitations, user-created Sanctum tokens, and configuration-dependent public
  registration.
- Platform-access tests cover the five starter-role matrices, different roles
  for one User in two Businesses, exact custom roles, direct grants, assigned
  Locations, same-tenant access, unauthorized roles, cross-tenant identifiers,
  invitation expiry/revocation/replay, former-employee sessions and tokens,
  private files, jobs, cache keys, search envelopes, exports, platform access,
  and append-only/redacted audit events.
- `vendor/bin/pint --test` passes for the full repository.
- `npm run build` passes client and SSR production builds (1,204 client modules
  and 111 SSR modules). The two known DaisyUI `@property --radialprogress`
  optimizer warnings remain non-fatal.
- Fresh migrations execute in the isolated SQLite `:memory:` suite. A separate
  file-backed SQLite check confirmed the platform-access migration rolls back
  cleanly; continuing the repository-wide rollback then reaches an unrelated
  pre-existing Cashier migration whose indexed `stripe_id` column cannot be
  dropped in its current order. MySQL 8 foundation migration compatibility is
  now verified below; concurrency/locking verification remains required before
  any scheduling or payment concurrency claim.
- The full control-to-test mapping is recorded in
  [`tenant-isolation-matrix.md`](tenant-isolation-matrix.md).

### Subscription and entitlement verification (2026-08-11)

- `php artisan test`: 95 passed, 16 skipped, 530 assertions in 7.67 seconds.
  Skips remain the explicit disabled Jetstream Team, Team invitation,
  user-created API-token, and configuration-branch coverage.
- `php artisan test tests/Feature/Billing/SubscriptionLifecycleTest.php`: 15
  passed, 88 assertions in 0.82 seconds. Coverage includes verified exactly-once
  onboarding, monthly/annual conversion, saved-method evidence, cancellation,
  support cancellation, reactivation, retry/grace/restriction/recovery,
  over-limit downgrade, HTTP/job/import checks, effective dating/audit,
  duplicate/out-of-order events, installed Stripe SDK signature verification,
  invoices/payments, cross-tenant denial, coupons, export window, notices, and
  reconciliation replay.
- `php artisan test tests/Feature/RegistrationTest.php
  tests/Feature/Database/FoundationMigrationRecoveryTest.php`: 4 passed, 1
  skipped, 36 assertions in 1.00 seconds. This covers the complete register,
  pending-intent, signed-verification, exactly-once Business/Owner/trial,
  logout, and credential sign-in flow plus resumable partial-DDL recovery.
- `vendor/bin/pint --test` passes for the full repository.
- `npm run build` passes client and SSR production builds (1,205 client modules
  and 112 SSR modules). The existing DaisyUI `@property --radialprogress`
  optimizer warning and runtime-resolved self-hosted font URLs remain non-fatal.
- Fresh SQLite `:memory:` migrations pass with the normalized billing schema and
  seeded trial entitlement definitions. On MySQL 8.0.42, the repaired
  foundation migrations resumed the existing partially applied schema without
  dropping data: platform access completed in 187.58 ms and subscription
  entitlements completed in 165.09 ms after a MySQL-safe coupon index-name fix.
  Both migrations now report `Ran`.
- A rollback-only MySQL smoke test returned `intent=yes`, `business=yes`,
  `subscription=trialing`, and `login=yes`; no smoke-test tenant was retained.
  Concurrency/locking verification remains required before a production
  scheduling or payment concurrency claim.
- No Stripe sandbox credentials exist locally. Evidence therefore covers the
  installed SDK signature contract and deterministic application contract, not
  live Checkout, billing portal, subscription schedule, test-clock, mail, tax,
  or settlement behavior. Those remain paid-launch gates.

### Business-configuration verification (2026-08-11)

- `php artisan test`: 110 passed, 16 skipped, 612 assertions in 8.40 seconds.
  Skips remain the explicit disabled Jetstream Team, Team invitation,
  user-created API-token, and configuration-branch coverage.
- `php artisan test
  tests/Feature/BusinessConfiguration/ConfigurationFoundationTest.php`: 15
  passed, 82 assertions. Evidence covers explicit readiness, the 24-minute
  demo, and the guided first-bookable-path interface; permission and tenant denial; slug uniqueness/aliases; local/DST hours,
  closures, and resource maintenance; split and impossible schedules;
  staff-specific effective values and immutable snapshots; add-on resource
  quantity; persisted Appointment-impact adapter results and published-change
  gating; staff and resource window/exception resolution; import replay, malformed files, private errors, duplicates, and
  entitlement denial; and the exact booking-facing contract.
- Fresh SQLite `:memory:` migration passed for the configuration schema,
  including composite tenant foreign keys. No MySQL booking-concurrency claim
  is made because this prompt creates no capacity-hold or Appointment commit
  tables; Prompt 05 must supply MySQL 8 locking evidence for those operations.
- `vendor/bin/pint --test` passes for the full repository.
- `npm run build` passes client and SSR builds (1,209 client modules and 113 SSR
  modules). The known DaisyUI `@property --radialprogress` warning and
  runtime-resolved self-hosted font URLs remain non-fatal.
- `GoodHoursDemoSeeder` is idempotent and supplies one active Location, six
  local opening days, three barber-chair units, a segmented/deposited/taxed
  Service, a qualified scheduled Staff Profile, reviewed preview evidence, and
  a 24-minute publish record. Its owner password is random and not a reusable
  shared credential.

### Availability and booking-core verification (2026-08-11)

- `php artisan test
  tests/Feature/SchedulingOperations/BookingEngineTest.php`: 12 passed, 69
  assertions in 1.00 seconds on isolated SQLite. Coverage includes shared
  search/commit policy, preferred/any Staff, notice/advance, replay, expiry,
  Hold confirmation/staleness, Resource quantity, staff-free/resource-busy,
  processing occupancy, segment provider handoff, all-or-none rollback,
  closure/break/maintenance, private error content, travel overlap, stale
  search, explicit add-on lines, segmented Staff duration variants,
  spring and repeated-hour fall daylight-saving changes, and local midnight.
- `php artisan test
  tests/Architecture/SchedulingWriteBoundaryTest.php`: 1 passed, 1,368
  assertions in 0.06 seconds across current controller, Filament, and Vue
  source files.
- MySQL concurrency evidence ran on local MySQL 8.0.42/InnoDB in the dedicated
  `barber_app_booking_test` database, never the development `barber_app`
  database. Seven test cases with 29 assertions passed. Independent forked PHP
  workers purged inherited connections, opened separate PDO connections, and
  waited behind a pipe start barrier. Scenarios cover online-online,
  online-reception, staff-free/resource-busy, quantity two with three
  contenders, shared multi-segment handoff, Hold expiry versus commit, exact
  duplicate replay, and stale search.
- Representative local MySQL measurements: a one-day any-qualified query
  returned 20 slots in 210.52 ms using 746 statements; a direct atomic
  Staff/Resource commit completed in 15.53 ms using 55 statements. Both meet
  provisional response targets locally. The search statement count is explicit
  read-amplification debt, not launch load evidence.
- Fresh MySQL migrations exposed and corrected MySQL's 64-character identifier
  limit in one platform invitation foreign key and business-configuration
  import/foreign-key names. All scheduling foreign keys/indexes use explicit
  short names. Fresh migration then completed through all 34 migrations.
- `php artisan test`: 122 passed, 23 skipped, 681 assertions in 9.21 seconds.
  The seven MySQL cases skip in the ordinary isolated suite and were run
  separately with the explicit dedicated-database gate above. Existing skips
  remain disabled Jetstream Team/invitation/API-token and configuration-branch
  coverage.
- `vendor/bin/pint --test` passes for the full repository.
- `npm run build` passes client and SSR builds (1,210 client modules and 113 SSR
  modules). The existing DaisyUI `@property --radialprogress` warning and
  runtime-resolved self-hosted font URLs remain non-fatal.

### Calendar and walk-in verification (2026-08-12)

- `php artisan test
  tests/Feature/SchedulingOperations/CalendarWalkInOperationsTest.php`: 7
  passed, 93 assertions. Coverage includes controlled lifecycle/replay/stale
  editing, linked replacement/override, blocks/calendar cues/performance,
  walk-in estimate/reorder/notify/collision/start, operational exceptions and
  closure recovery, role/cross-tenant HTTP denial, Location-time conversion,
  and an idempotent production-like front-desk day.
- The dedicated MySQL 8.0.42/InnoDB suite now passes 9 tests and 38 assertions,
  including two independent processes racing a stale lifecycle version and a
  32-Appointment calendar projection. One edit succeeds and one fails with
  `STALE_APPOINTMENT`; the projection measured 7.08 ms and 9 SQL statements.
  Availability measured 204.68 ms/786 statements and direct commit measured
  15.86 ms/57 statements in that run.
- Responsive browser checks used the seeded 8-appointment, 2-walk-in, 1-block
  day at 1440x950, 768x900, and 360x800. Calendar and queue had no page-level
  horizontal overflow and no visible control under 44px. Dialogs initially
  focus Cancel, close on Escape, and return focus to their opener. Non-color
  status cues, representative 5.01:1-or-better text contrast, and an empty
  browser error/warning log were verified.
- `npm run build` passes client and SSR production builds (1,211 client modules
  and 115 SSR modules). The existing DaisyUI `@property --radialprogress`
  warning and runtime-resolved self-hosted font URLs remain non-fatal.
- `php artisan test`: 127 passed, 25 explicitly skipped, 746 assertions in
  11.58 seconds. `vendor/bin/pint --test` passes for the full repository.
  Later prompt evidence must not weaken these operational tests.

### Public booking and waitlist verification (2026-08-12)

- `tests/Feature/PublicBooking/PublicBookingWaitlistTest.php`: 9 tests cover
  passwordless Hold/confirmation and replay, policy drift, elapsed observation
  time, required-deposit fail-closed behavior, expiring/revoked/purpose-bound
  links, contact/cancel versioning, waitlist deduplication/batching/claim,
  secure join/leave, tenant/identifier tampering, shop policy controls, and
  offer expiry/requeue, and public rate limiting.
- Public plus booking/calendar regressions pass 28 tests and 252 assertions.
  The production build passes client and SSR compilation with only the existing
  DaisyUI `@property` and runtime font-resolution warnings.
- The dedicated MySQL 8.0.42/InnoDB suite passes 11 tests and 45 assertions.
  It proves MySQL JSON key-order normalization cannot falsely stale an unchanged
  Hold and two parallel waitlist claimants produce exactly one confirmed
  Appointment. The latest local run measured availability at 231.09 ms/786
  statements, direct commit at 17.75 ms/57 statements, and a 32-event calendar
  at 9.00 ms/9 statements.
- In-app browser QA completed a real Pine & Palm journey from Service selection
  through confirmation and secure self-service. The final page exposed the
  booking reference, calendar link, and every purpose-bound action; the checked
  1280x720 surface had no horizontal overflow, unnamed visible controls, or
  target under 44px, and no console error/warning. Existing product-shell and
  calendar evidence cover the shared responsive shell at 360px and 768px;
  external Safari/Firefox device-lab certification remains a launch-hardening
  gate.
- Browser testing discovered and fixed snapshot comparison that treated
  observation time and MySQL JSON object key order as policy changes. Regression
  evidence now covers elapsed confirmation time and MySQL-native JSON storage.
- `php artisan test`: 136 passed, 27 explicitly skipped, 836 assertions in
  12.79 seconds. The skipped MySQL cases passed separately above; remaining
  skips are deliberate disabled-feature/configuration branches.

### Client CRM and consent verification (2026-08-12)

- `tests/Feature/ClientRecords/ClientCrmConsentTest.php`: 8 tests and 106
  assertions pass. Coverage includes exact matching and same-mobile spelling
  candidates; encrypted, versioned preference edits and Appointment-link
  revocation; tenant-scoped tags/preferred Staff/Services; merge preview and
  preservation of Appointment, Consent, Note, Form Request, immutable
  Submission, Attachment, Privacy Request, tag, and preferred-Service
  relationships; authenticated form-builder publishing, template changes after
  submission, Calendar completion state, and one-use form links;
  sensitive-role/access-audit and cross-tenant denial; private and expired file
  links; and all four privacy workflows with export-content
  inspection/minimisation.
- Client-import, public-booking, scheduling, calendar/walk-in, platform-access,
  and architecture regressions pass together with the new Client suite. Public
  booking assertions prove Appointment→Client creation and contact update of
  the same identity; configuration assertions prove reviewed imports create
  authoritative CRM profiles.
- The dedicated MySQL 8.0.42/InnoDB suite passes 12 cases and 48 assertions:
  all established booking/calendar/waitlist races remain safe, and two
  independent Client writers starting at version 1 yield exactly one version-2
  update while the other receives the stale-edit result. Fresh MySQL migration
  includes every Client composite foreign key, preferred-Service pivot, and six
  starter forms. The latest representative run measured search at 247.50 ms /
  786 statements, commit at 21.51 ms / 61 statements, and a 32-event calendar
  at 10.82 ms / 9 statements after adding form-completion projection.
- In-app browser QA completed the authenticated directory/profile, stored a
  synthetic protected allergy note, created an Appointment-bound secure form
  request, and completed its one-use public form. The 390×844 profile measured
  390px content/viewport width with no horizontal overflow; its back action was
  44px, changed selects/file inputs were named, and the responsive shop
  navigation remained usable. Browser QA discovered and fixed runtime page
  context and starter-publish default issues before completion. The final
  builder pass loaded the Allergy declaration’s two fields, exposed every
  supported answer type and named control, and retained a 1280px/1280px
  viewport/content width without horizontal overflow.
- `php artisan test`: 143 passed, 28 explicitly skipped, 932 assertions in
  14.48 seconds. Every MySQL-marked case passed separately above; all remaining
  skips are deliberate disabled-feature/configuration branches.
- `npm run build` passes client and SSR production builds. Only the existing
  non-fatal DaisyUI `@property --radialprogress` optimizer and runtime font URL
  warnings remain. Formatter, route, migration-status, and final diff checks
  also pass in the final Prompt 08 verification pass.

### Reliable communications verification (2026-08-14)

- `tests/Feature/Communications/ReliableCommunicationsTest.php`: 10 tests and
  83 assertions pass. Coverage includes duplicate event convergence across two
  channels, allow-listed/missing variables and safe fallbacks, cross-tenant
  template denial, quiet-hour boundaries, spring/fall DST, transactional/
  marketing/WhatsApp consent, unsubscribe/suppression, invalid destinations,
  consent change after queueing, cancelled reminders, bounded retry/outage
  recovery, terminal ambiguous WhatsApp handling, signed/duplicate/out-of-order
  callbacks, content-minimized
  diagnostics, bounded safe replay, revocable action links, and tenant/
  correlation jobs.
- The complete SQLite suite passes: 153 passed, 28 explicitly skipped, 1,015
  assertions in 14.32 seconds. Skips remain deliberate disabled legacy features
  and separately proven MySQL booking/concurrency cases.
- Resend/Twilio production credentials were not used. Provider sandbox sender,
  template, signature, callback-burst, and deliverability certification remain
  external Prompt 13 launch evidence, not claims made by local contract fakes.

### Money and commerce verification (2026-08-15)

- FR-14 and FR-15 now have an application-owned, append-only commerce ledger:
  deposit policy/snapshot, pending online payment intent, verified provider
  event inbox, immutable payment/refund/correction records, sale and source
  line snapshots, receipt reproduction, reconciliation tasks, and daily cash
  close. Appointment capacity remains a Hold until verified payment success;
  finalization failure creates a visible reconciliation task.
- `tests/Feature/MoneyCommerce/MoneyCommerceTest.php`: 5 tests prove
  integer-minor-unit inclusive-tax calculation, deposit plus cash/card split
  tender and exact replay, partial refund, receipt reproduction, excessive
  discount denial, reasoned cash variance, none/fixed/percentage/full/new/
  threshold/prior-no-show deposit policy, cross-tenant payment denial, manager
  waiver preservation, duplicate provider events, late failed event after
  success, and payment-success/missing-flow recovery task.
- Public booking now displays a frozen deposit/cancellation/fee snapshot and
  requires a completed deposit intent rather than failing as "not connected".
  The Stripe adapter uses a separate appointment webhook secret and does not
  treat browser return pages as payment evidence. Live Stripe test-mode and
  settlement reconciliation have not been run.
- ADR-020 records the implemented India/INR/en-IN calculation behavior and the
  appointment gateway/method set. ADR-039 supersedes it for target-market
  direction; regionalisation remains required. Subscription and appointment
  Stripe flows use separate bounded contexts, provider records and webhook
  secrets.

### Inventory, commissions, reporting, and metrics verification (2026-08-15)

- `tests/Feature/InventoryCommissionReporting/InventoryCommissionReportingTest.php`
  passes 8 tests / 93 assertions on both isolated SQLite and the dedicated
  MySQL 8/InnoDB `barber_app_booking_test` database. It covers exact-once Sale
  deduction/replay, restock and customer-keeps void/refund disposition, CSV
  opening stock/export, receipts, reasoned manual adjustment, discounted and
  fixed Commission, effective rule changes, Tip/refund offsets, manager
  adjustment, Staff statement, every report catalog key, local-midnight
  boundaries, role/Staff/Location limits, cross-tenant export denial,
  dashboard/report/source/payment reconciliation, filter parity, private queued
  CSV, printable totals, and instrumentation minimisation/idempotency.
- The dedicated MySQL realistic-volume case inserts 2,000 completed Sales and
  returns 2,000 drillable rows plus `collected_minor=1,800,000` in 27.37 ms
  using 8 SQL statements. The guard is 15 statements and 2.5 seconds. This is
  indexed local query evidence, not sustained/concurrent production load or
  target-hosting certification.
- The focused regression with `MoneyCommerceTest` passes 13 tests / 123
  assertions on SQLite. The complete repository suite passes 175 tests / 1,211
  assertions with 28 intentional skips in 15.36 seconds; `phpunit.xml` sets a
  256 MB process ceiling for the expanded suite. Client and SSR production
  builds pass with the known
  DaisyUI `@property` and runtime font-resolution warnings only.
- CSV and printable summary totals use the same normalized filters and report
  service as the screen. Export rows retain source IDs/drill values, version,
  freshness, time zone, SHA-256 content hash, requesting Membership, and
  Business/Location/Staff scope snapshot. Queue execution re-authorizes the
  active Membership before reading source records.

## Implemented FR-20 platform administration and support operations

- [x] Safe Business search/summaries cover owner verification, onboarding,
  plan, usage, trial/subscription, invoice, payment/failure counts, and
  privacy-safe activity volumes without message content, payment secrets,
  authentication data, or Client notes.
- [x] Explicit platform administrator, support operator, and security auditor
  capability matrix; every platform role requires verified email, confirmed
  TOTP, active assignment, 15-minute idle, and eight-hour absolute sessions.
- [x] Administrator-only Business activation/suspension/closure, trial
  extension, coupon assignment, plan change, immediate cancellation, feature
  flags, notices, and single-Business export initiation write reasoned audit
  evidence.
- [x] Verification and invitation resend use normal notification workflows;
  replacement invitations rotate the token and revoke prior pending evidence.
- [x] Platform-internal append-only account notes have explicit visibility and
  bounded retention dates.
- [x] Support access requires approval by a different administrator, one
  Business, ticket, reason, enumerated scopes, and expiry within four hours.
  Entry keeps the operator identity, uses separate support endpoints, never
  satisfies Membership middleware, shows a tenant banner, and ends on exit,
  supersession, expiry, or revocation with immutable audit evidence.
- [x] Failure summaries minimize billing/payment/notification/job content.
  Reviewed Stripe/payment/communication replay uses a reason plus unique
  operation key and duplicate requests return the first replay result. Generic
  failed jobs remain inspection-only.
- [x] Queue, communication, webhook, reconciliation, and honest backup health
  summaries exist. Backup remains `not_configured`, not falsely healthy.
- [x] Three Business entries in fifteen minutes raise a high cross-tenant
  alert. Bulk/cross-tenant export input is rejected, raises a critical alert,
  and creates no export request; valid requests carry exactly one Business
  lineage snapshot.
- [x] Larafast Filament User/Role/Permission and legacy billing/catalog
  resources plus discovered legacy widgets were audited and quarantined from
  the approved platform workflow.
- [x] Focused SQLite evidence: `PlatformOperationsTest`, `TenantIsolationTest`,
  `AuditEventTest`, and `SubscriptionLifecycleTest` pass 47 tests / 268
  assertions. The complete repository suite passes 185 tests / 1,290
  assertions with 28 intentional disabled-feature/MySQL-integration skips in
  15.72 seconds. Client and SSR production builds pass with only the existing
  DaisyUI `@property` and runtime font-resolution warnings.

## Phase 1.5 public front-site

### Prompt 14 discovery and SEO audit

- [x] Every anonymous executable route was inventoried and classified as
  acquisition, tenant booking, transactional, authentication, legal, content,
  webhook, private application/admin, framework utility, or error behavior.
- [x] The existing Home, public shell, legacy pages, CTAs, claims, components,
  assets, metadata, schema, sitemap, robots, content rendering, instrumentation,
  accessibility, responsive behavior, and production bundle baseline were
  audited. No broad public-page implementation occurred in Prompt 14.
- [x] ADR-024 accepts a curated acquisition IA and explicit separation from
  tenant booking and secure/private tasks. Route, indexation, linking, content,
  CTA and legacy-route contracts are in [`frontsite/README.md`](frontsite/README.md).
- [x] The verified/qualified/remove/decision-needed claim and entity ledger is
  in [`frontsite/content-and-claims.md`](frontsite/content-and-claims.md).
- [x] Prompt 14 evidence and severity-ranked remediation ownership is in
  [`audits/2026-08-16-frontsite-discovery-seo-audit.md`](audits/2026-08-16-frontsite-discovery-seo-audit.md).
- [x] Focused baseline: 30 tests passed / 309 assertions with one intentional
  skip; Node v24.19.0 production client and SSR builds passed. The baseline
  mobile Home had no horizontal overflow but contained extensive Larafast,
  fabricated-proof, dead-link, metadata/schema, legal and content-safety
  publication blockers.
- [x] Prompts 15–27 now have implementation and verification evidence below.
- [x] OPEN-12 records the missing marketing analytics/provider/consent/
  retention authority. No third-party tracker was installed.

### Prompt 15 public design system and navigation

- [x] `MarketingLayout` now provides skip navigation plus semantic header,
  primary navigation, main and footer landmarks while remaining separate from
  authenticated and tenant-booking shells.
- [x] Responsive navigation is route-aware and auth-aware; the controlled
  mobile menu exposes expanded state, closes on Escape/outside interaction/
  route change, returns focus, locks background scroll and fits small
  viewports. Only currently executable named routes are exposed.
- [x] The sticky public header uses a warm, lightly elevated cream surface with
  standard ink/pine navigation and a matching light mobile panel. Deep pine is
  reserved for the footer so the page is not visually top-heavy.
- [x] Footer boilerplate, fake social/service/newsletter links and theme control
  were removed from the active marketing shell. Global language now identifies
  ClipperDesk and its salon/barbershop booking-to-checkout purpose.
- [x] Reusable public container, section heading, CTA, card, proof frame,
  comparison table, FAQ/disclosure, breadcrumb and conversion-band contracts
  are implemented in one marketing namespace and documented in the design
  system.
- [x] Public CTA uses `Start your trial` for anonymous visitors and `Open
  dashboard` for authenticated users, with a stable privacy-safe context
  attribute but no tracker.
- [x] Prompt 15 verification: 3 focused tests / 34 assertions pass; production
  client and SSR builds pass. Browser checks at 360×800 and 1440×900 found no
  shell overflow, verified landmarks and real footer destinations, and proved
  mobile Escape/focus-return/scroll-unlock behavior. Evidence:
  [`prompt-15-shell-mobile.png`](evidence/frontsite-2026-08-16/prompt-15-shell-mobile.png)
  and [`prompt-15-shell-desktop.png`](evidence/frontsite-2026-08-16/prompt-15-shell-desktop.png).
- [x] Prompt 16 is unblocked. Homepage boilerplate remains visible only because
  page composition is explicitly owned by Prompt 16, not by the shell phase.

### Prompt 16 homepage positioning and conversion

- [x] The root page is now a complete ClipperDesk narrative led by “Run your
  salon or barbershop from booking to checkout,” one working trial action and
  an explicit existing-customer Login path in the shared shell.
- [x] Six verified outcome groups cover getting booked, protecting the
  calendar, running the day, getting paid, knowing clients and knowing the
  business. The workflow carries one governed record from availability through
  checkout/reporting without advertising Phase 2 behavior.
- [x] The page uses two reviewed synthetic product captures from the Prompt 01
  evidence set, with factual captions, meaningful alternatives, intrinsic
  dimensions, eager hero proof and lazy below-fold booking proof. No customer
  logo, testimonial, rating, usage count, integration logo or fabricated metric
  remains.
- [x] Visible answers define ClipperDesk, its audience, managed work, difference
  from booking-only tools, import support, and live provider qualifications.
- [x] Home metadata now has a unique natural title, description and configured
  canonical. Core copy and links are SSR-compatible; Prompt 23 still owns the
  final cross-site metadata/schema engine.
- [x] Focused Homepage/shell/registration/public-booking verification passed 17
  tests / 187 assertions with one intentional skip. Production client + SSR
  build passed; the Home client chunk fell from the 96.31 kB audit baseline to
  14.48 kB (5.47 kB gzip), excluding the shared app chunk and two optimized
  evidence images.
- [x] Fresh browser checks at 360×800 and 1440×900 found one `h1`, no horizontal
  overflow, no broken media and no console warnings/errors. All four CTA
  placements resolved to registration. Evidence:
  [`prompt-16-home-mobile.png`](evidence/frontsite-2026-08-16/prompt-16-home-mobile.png)
  and [`prompt-16-home-desktop.png`](evidence/frontsite-2026-08-16/prompt-16-home-desktop.png).
- [x] Prompt 17 is unblocked. Homepage contextual links to later hubs remain
  deliberately absent until those routes have substantive pages.

### Prompt 17 product and feature architecture

- [x] `/features` and four substantive details are implemented: online
  booking; calendar and walk-ins; client management; and checkout/reporting.
  Homepage outcome cards now link to those real destinations.
- [x] Staff/resource scheduling is consolidated into the calendar cluster;
  deposits/inventory/commission into the completed-commerce cluster; and
  reminders into booking/client context. No thin module-per-page or keyword
  permutation was published. Decisions are in
  [`frontsite/feature-clusters.md`](frontsite/feature-clusters.md).
- [x] Each detail has a unique definition, four-step workflow, requirement
  evidence, three concrete proof statements, two visible limitations, two
  adjacent feature links, breadcrumb, canonical metadata and contextual trial
  CTA. Provider, retention, medical-compliance and throughput limitations are
  stated where relevant.
- [x] Unknown/unapproved feature slugs return 404. Phase 2 AI, payroll, loyalty,
  gift-card and forecasting routes/content are not generated.
- [x] Prompt 17 verification: 11 focused tests / 184 assertions passed with the
  existing Home/shell checks; production client and SSR builds passed. Browser
  checks found one `h1`, valid hub/detail links, active Product navigation, no
  console warnings/errors and no 360px overflow. Evidence:
  [`prompt-17-features-mobile.png`](evidence/frontsite-2026-08-16/prompt-17-features-mobile.png)
  and [`prompt-17-feature-detail-mobile.png`](evidence/frontsite-2026-08-16/prompt-17-feature-detail-mobile.png).
- [x] Prompt 18 is unblocked.

### Prompt 18 industry and business-type solutions

- [x] `/solutions` now links four differentiated, supportable pages for
  barbershops, salons, independent stylists and small non-medical spas.
- [x] Each solution has a distinct fit statement, three operation-specific
  pressure points, a four-step representative day, three relevant feature
  paths, requirement evidence, two honest limitations, canonical metadata,
  breadcrumb and contextual trial CTA.
- [x] Hair-salon and beauty-salon intent is consolidated into the salon page;
  nail salons remain deferred for lack of distinct research/proof; medical spa
  is rejected. The candidate matrix is in
  [`frontsite/industry-solutions.md`](frontsite/industry-solutions.md).
- [x] No city/country, directory, marketplace, customer-story, review,
  regulatory-compliance, stereotype or stock-image page was created. The spa
  page explicitly disclaims healthcare/HIPAA claims.
- [x] Prompt 18 verification: 14 focused tests / 259 assertions passed with
  feature/home regressions; production client and SSR builds passed. Fresh
  360×800 browser checks found one `h1`, all four hub links, three relevant
  feature links, the medical qualifier, no overflow and no console warnings or
  errors. Evidence:
  [`prompt-18-solutions-mobile.png`](evidence/frontsite-2026-08-16/prompt-18-solutions-mobile.png).
- [x] Prompt 19 is unblocked.

### Prompt 19 use-case and problem pages

- [x] `/use-cases` now curates four non-overlapping problem pages: reducing
  scheduling conflicts, managing booked/walk-in demand, protecting time with
  deposits, and keeping client history together. Candidate consolidation and
  deferral rationale is recorded in
  [`frontsite/use-case-pages.md`](frontsite/use-case-pages.md).
- [x] Every page provides an early direct answer, three diagnostic symptoms,
  four useful operating steps that stand without the product, four verified
  ClipperDesk steps, requirement evidence, two visible limitations and exact
  feature/business-fit links. No unsupported statistic, migration-service,
  guaranteed no-show, regulatory or AI claim was introduced.
- [x] Prompt 19 route/content regression verification passed 18 tests / 344
  assertions with feature and solution pages. A fresh 360×800 browser check
  found one `h1`, the operating qualifier and no horizontal overflow.
- [x] Prompt 20 is unblocked.

### Prompt 20 public pricing and trial conversion

- [x] `/pricing` reads active/effective Starter and Pro amounts, currency,
  intervals and entitlements through one server presenter. It shows commercial
  values only when the complete approved Stripe `price_…` catalog is available;
  incomplete, expired, mixed-currency or non-Stripe state renders a truthful
  unavailable panel instead of partial prices.
- [x] Monthly/annual controls are semantic radios. Annual savings are computed
  from current rows; the comparison table uses current entitlement values; and
  trial, tax, cancellation, appointment-payment separation and live Stripe
  certification limits are visible. No Vue/content file owns a price.
- [x] Pricing CTAs carry only allow-listed plan/interval identifiers. The
  server revalidates them against the current catalog, stores the preference on
  the owner registration intent, and presents it later to billing review
  without choosing a provider price or charging at signup.
- [x] Prompt 20 pricing tests passed 4 tests / 77 assertions, including complete
  catalog, calculated savings, expired/unavailable state and query/POST
  tampering. Registration and the 30-test subscription lifecycle regression
  also pass. A fresh 360×800 browser check found one `h1`, the accessible
  interval control, complete prices and no horizontal overflow.
- [x] Prompt 21 is unblocked. Live Stripe checkout remains a Prompt 13 blocker.

### Prompt 21 trust, company, and legal pages

- [x] `/company` and `/security` now provide specific, evidence-backed identity
  and control summaries without inventing an operator, address, certification,
  security mailbox, SLA, uptime history, customer proof, or support workflow.
- [x] Terms and privacy use the public shell but are visibly marked as review
  drafts and remain `noindex`. On 2026-08-25 they were expanded into
  substantive, versioned, owner-labelled counsel-review documents with a shared
  responsive/printable legal layout, table of contents, metadata and stable
  canonicals. Registration route names remain unchanged.
- [x] `/refund-policy` now provides a separate `noindex` review draft covering
  subscription cancellation/refunds, appointment deposits, Stripe refund
  eligibility and initiation, original-method handling, provider/bank timing,
  no-shipping disclosure, disputes and the subscription-versus-appointment payment
  boundary. Pricing, subscription checkout and the public footer link to it.
- [x] The 2026-08-25 provider-policy review is recorded in
  [`audits/2026-08-25-legal-policy-review.md`](audits/2026-08-25-legal-policy-review.md).
  It confirms the page structure addresses Stripe's published website fields,
  but the site is not eligible for provider/legal sign-off while the operator,
  direct customer-service contact, approved timelines and end-to-end Stripe
  refund executor remain unavailable.
- [x] Contact, status, standalone cookie, accessibility-statement, and
  security-reporting pages were not fabricated without an accountable intake
  or approval process.
- [x] The accountable-owner, approval, and indexation matrix is recorded in
  [`frontsite/trust-and-legal-matrix.md`](frontsite/trust-and-legal-matrix.md).
  OPEN-10, OPEN-11 and OPEN-13 remain production-publication blockers.

### Prompt 22 resources, guides, and editorial system

- [x] `/resources`, two maintained operating guides, `/blog`, and only eligible
  `/blog/{slug}` records use the public shell and useful related links. Legacy
  rows default to draft and are not silently published.
- [x] Article eligibility requires active/published state, a reached publication
  time, owner, author, review date, excerpt, image, and SEO fields. Stored
  Markdown is rendered server-side with raw HTML stripped and unsafe protocols
  disabled; inactive, draft, incomplete, and future records return 404.
- [x] The ownership, freshness, correction, and content-safety contract is in
  [`frontsite/editorial-system.md`](frontsite/editorial-system.md). Stored-XSS,
  publication-gate, guide, and empty-state regressions pass.

### Prompt 23 technical SEO, indexation, and structured data

- [x] One server policy emits HTML robots metadata and `X-Robots-Tag` for
  approved public, auth/booking/legal, secure/private, utility, and error route
  families. Canonicals are absolute, query-free, and page-owned.
- [x] `/sitemap.xml` is deterministic and curated; `/sitemap` redirects with
  301; generated `/robots.txt` advertises only that sitemap. The 23 base URLs
  exclude auth, tenant booking, secure tokens, legal drafts, roadmap,
  changelog, provider, admin, and test surfaces.
- [x] Central JSON-LD contains only factual Organization, WebSite, WebPage,
  SoftwareApplication, eligible Article/Guide, and visible current offer data.
  The unused legacy fabricated schema producer was removed. Real
  branded 404/410/500/503 pages fail closed with noindex directives.

### Prompt 24 GEO, AEO, and AI-assisted search

- [x] Visible answers, metadata, and schema share one canonical definition:
  “ClipperDesk is the daily operating system for salons and barbershops.” Page
  ownership prevents thin duplicate answers across Home, features, solutions,
  use cases, pricing, company, security, and resources.
- [x] The entity and question authority sheet is in
  [`frontsite/entity-facts.md`](frontsite/entity-facts.md). No bot-only page,
  hidden content, `llms.txt`, fake locale, AI feature, review schema, or
  unsupported global/compliance answer was introduced.

### Prompt 25 performance, accessibility, and international readiness

- [x] Public HTML currently declares `en-IN`; one reviewed locale exists without
  a fake selector or `hreflang`. ADR-039 supersedes ADR-025's target-market
  direction, so equivalent regional legal, commercial, provider, copy and
  reciprocal metadata review is required before the intended locales can be
  indexed.
- [x] Skip navigation, landmarks, focus visibility, reduced-motion handling,
  touch targets, semantic disclosures/radios/tables, responsive wrapping, print
  rules, intrinsic image dimensions, and lazy below-fold evidence are present.
- [x] Production client and SSR builds pass on Node v24.19.0. The shared app JS
  is 275.72 kB (94.86 kB gzip), public CSS is 258.85 kB (39.02 kB gzip), Home
  is 12.78 kB (5.06 kB gzip), and public route chunks remain below 10 kB except
  Home. `npm run check:frontsite-budgets` passes all 17 public route entries.
  Independent WCAG, real-device/browser, field-performance, and load evidence
  remain external launch controls.

### Prompt 26 conversion, analytics, and internal linking

- [x] Public CTAs use one authenticated-aware trial/dashboard contract. Pricing
  stores only server-validated plan and interval preferences; query attribution
  is never trusted or persisted as functional checkout state.
- [x] A vendor-neutral, storage-free DOM boundary emits bounded CTA-click and
  user-initiated interval-change events. It sends no network request and loads
  no tracker. Verified owner onboarding records `trial.qualified_started`
  exactly once through existing first-party instrumentation.
- [x] The CTA matrix, event dictionary, privacy boundary, and link graph are in
  [`frontsite/conversion-analytics-linking.md`](frontsite/conversion-analytics-linking.md).
  OPEN-12 still blocks any analytics vendor, pixel, replay, fingerprinting,
  retention, or paid-attribution implementation.

### Prompt 27 final front-site and SEO launch audit

- [x] The full 23-page base sitemap crawl returns 200, exactly one self-
  canonical per page, and `index, follow`; eligible articles extend the count.
  Query-like attribution never changes or leaks into canonical identity.
- [x] Browser sweeps at 320, 360, 390, 768, and 1440 widths found one `h1`, a
  main landmark, no horizontal overflow, no empty links, and no broken loaded
  media on sampled Home, hub, detail, guide, pricing, resource, legal, and 404
  surfaces. Pricing interval selection and mobile navigation behavior work.
  Final evidence: [`prompt-27-resources-mobile.png`](evidence/frontsite-2026-08-16/prompt-27-resources-mobile.png)
  and [`prompt-27-pricing-desktop.png`](evidence/frontsite-2026-08-16/prompt-27-pricing-desktop.png).
- [x] The complete repository suite passes 252 tests / 2,247 assertions with
  28 intentional disabled-feature/MySQL-integration skips in 18.94 seconds.
  Production client/SSR builds and front-site budgets pass. No lint or static
  TypeScript command is configured. `git diff --check` passes after legal-copy
  whitespace cleanup.
- [x] No unresolved in-scope P0/P1 front-site defect remains. Phase 1.5 is
  technically ready for controlled staging and named-owner review, but public
  production launch/indexation is **NO-GO** until the external gates in the
  final audit close. The overall product remains **NO-GO** under Prompt 13.
  Final register: [`audits/2026-08-16-frontsite-final-launch-audit.md`](audits/2026-08-16-frontsite-final-launch-audit.md).

## Important baseline risks

- The 2026-08-16 dependency update remediated the then-known Composer/npm
  advisories and fresh registry checks returned zero. Continuous scanning and
  review of the large transitive update remain production controls.
- Full SQLite rollback remains blocked after the platform-access migration has
  rolled back by the pre-existing 2019 Cashier customer-column migration's
  index/drop ordering.
- Jetstream Team is superseded by accepted ADR-006 and is no longer created at
  registration, but legacy Team models/tables/actions remain preserved pending
  a separately reviewed cleanup/backfill decision.
- Stripe is selected for both ClipperDesk SaaS subscriptions and eligible
  appointment payments, but these remain separate bounded contexts, webhook
  secrets and normalized aggregates. Overlapping legacy User/Cashier and Lemon
  Squeezy tables/resources remain quarantined until a reviewed backfill proves
  they contain no data requiring preservation.
- The legacy invoice download now enforces User ownership, global model
  unguarding is removed, unsafe magic/social routes are disabled, and platform
  roles are separated. Other provider billing/admin resources remain legacy
  boilerplate and are not approved tenant billing behavior.
- Boilerplate product, price, blog, roadmap, AI, and marketing features are
  quarantined by the Prompt 14 audit; their visible replacement and safe
  indexation are owned by Prompts 15–27 while destructive deletion remains
  bounded by OPEN-09.
- Atomic Staff/Resource capacity and booking idempotency are proven on local
  MySQL with parallel processes. This is not sustained-load, target-topology,
  failover, replica, queue, or payment-idempotency evidence. Availability search
  currently repeats authoritative reads (746 statements for 20 measured
  slots), and any-qualified commits lock every eligible candidate Staff member.
- India commerce and `en-IN` public-site behavior remain in the current
  implementation, but ADR-039 supersedes that target-market direction. They are
  not approved for the intended United States, Canada, United Kingdom or Europe
  launch until OPEN-15 regionalisation and review are complete.
- Resend sender/domain authentication and Twilio WhatsApp sender/Content SID
  approvals are not configured or externally certified; production sending
  remains blocked by those provider controls and OPEN-11.

## Next recommended work

Do not begin paid launch. Execute the blocker plan in the versioned release
record: choose the exact first countries; regionalise and certify
Stripe/Resend/Twilio in their target environments; approve tax/privacy/
retention and messaging consent/quiet-hour rules with named reviewers; add upload malware
scanning; optimize and load-test availability, checkout, and webhook bursts on
the target database/queue/storage topology; configure and exercise monitoring,
on-call, status communications, backups, restore, DR, and rollback; and run an
independent WCAG plus Chrome/Safari/Edge/Firefox matrix. Then repeat Section 7
and the complete Section 17 representative-shop test without direct database
work or product-team assistance. OPEN-09/10/11 remain explicitly retained.


## 2026-11-07 Three-month trial

New account trial calculation changed to three calendar months without month-end
overflow. Pricing and legal templates use a shared 3-month label; billing retains
the actual saved end date. Existing records are not extended. Deployment and
desktop/mobile visual verification remain outstanding.

Pricing trial CTA refinement: “Start your free trial” carries a compact, static
lightning badge reading “3 months free” at the top right. The contrasting lime
badge has no animation or urgency claim. Visual verification remains pending.

Trial badge palette refinement: pricing and signed-out desktop/mobile header
trial actions use pale indigo, navy text and a gold lightning icon. Authenticated
subscription/dashboard actions omit the badge. Supersedes the lime palette above.

New-signup verification: RegistrationTest passes locally (6 passed, 45 assertions;
1 configuration-dependent skip). Verified-email signup asserts the saved trial
end equals its start plus three calendar months without overflow; repeated
verification retains the existing account. Not verified on production.

## 2026-11-08 Marketplace discovery foundation (local only)

- Added `/marketplace` with distinct customer branding, service/name and location
  address search, public salon cards, pagination and canonical booking handoff.
  Existing appointment payments remain manually recorded; no gateway added.
- Discovery requires explicit operator-reviewed slug enrollment and active,
  published online-booking businesses with active locations. Enrollment is empty
  by default; no existing businesses were automatically listed.
- Local discovery suite: **4 passed / 84 assertions**. Client/SSR build passes on
  Node 24 (existing CSS/font warnings). Browser checked desktop1440 and phone390;
  no horizontal overflow at either width. Phone query submission and broader-search
  recovery verified. Fixed a framework hero-class collision observed visually.
  [Desktop screenshot](audits/2026-11-08-marketplace/desktop.png).
- Customer accounts/dashboard, messaging, nearby maps, live-time/price/rating
  filters, owner listing controls and final Business-front branding remain
  unimplemented. Populated listing/complete booking journey, notices during an
  outage, real customer sends and deployed verification remain outstanding.
  Scope, sequencing and open policy questions: [marketplace](modules/marketplace.md).
  No deployment, production enrollment or financial/provider action performed.


## 2026-11-09 Marketplace local growth candidate and account refinement

Supersedes the earlier foundation-only implementation notes above for this local
working tree. MPG-01–10 now have a local implementation: all13 Solutions audiences,
reviewed many-to-many service concepts/geography, tenant-safe public supply/work
projection with retry/reconciliation, bounded versioned discovery, registry-backed
local hubs and independent provider readiness, initial HTML with real SSR/outage
fallback, conditional schema/canonical/sitemaps, default-off indexation, consented
source evidence and owner-only appointment/ledger outcomes. Owner shared links,
discovery origin and booking entry remain distinct; missing/expired/withdrawn
source evidence remains Unknown. Aggregate Search Console import is implemented;
no Google data or connection is claimed. Booking holds/commit, timezone/DST,
manual collections and append-only ledger history remain authoritative.

Customer profile photos now use private normalized raster storage and the existing
verified session. Selecting the avatar opens the picker. A small corner × shows
on hover/focus (available on touch), with a tooltip and shared Keep photo / Remove
photo confirmation. Cancel/failure preserves the saved picture and other profile
drafts. Header/rail use the saved photo or initials; the account chevron is centred.
My bookings, Inbox, Profile and Conversation use the compact shared customer shell:
less padding,36px desktop buttons/40px fields and44px mobile targets. Repeated
promotional/advice cards and the separate photo-settings block were removed.
Cookie choices use Accept optional cookies / Reject optional cookies with existing
purpose, opt-out and privacy boundaries intact.

Verified locally:109 serial exact PHP class selections with latest rechecks yield
**1,310 passed /31 skipped /14,166 assertions**. The separate built live SSR SEO
run passes9/141.31 skips include14 production-MySQL concurrency cases and optional
configuration; SQLite does not certify concurrency. **237 frontend tests pass**;
final account backend recheck36/535. Client+SSR Node24 build and25-entry frontsite
budgets pass. Synthetic100-business/1,000-offer retrieval+suggestions uses4 SQL
queries and no live availability matching.12-path local raw HTML crawl passes;
all synthetic pages remain noindex. Scoped formatting and whitespace checks pass.
An existing duplicate receipt event producer was found and consolidated under
ReceiptService; the repeated manual payment HTTP regression now passes.

Final avatar hover/dialog, compact customer pages, owner publication/report notices
and full booking visual journey remain unverified because CUA returned exactly
“Local browser use is disabled in Work settings”. Earlier real local hub/cookie
screenshots are retained with dates/limitations; they do not prove this final UI.
No production deployment/indexing/ranking/customer acquisition/revenue was verified.
All growth flags remain safe by default. Market/cohort/origin, revised disclosure
approval and production-engine/browser release checks remain operator gates.

[Implementation audit and evidence](audits/2026-11-08-marketplace-local-growth/README.md)
· [Stage-E review/release package](release/2026-11-08-marketplace-local-growth/README.md).


### 2026-11-09 Marketplace → booking branding continuity

PublicBookingLayout now reuses the actual MarketplaceLayout on Marketplace provider
booking routes through all four steps. Header/logo/account navigation, ivory canvas
and footer match discovery. The business’s logo/media/catalogue/policies and saved
accent remain in the booking content; the accent cannot recolour the shared shell.
Duplicate booking-header links/status copies were removed. Direct owner booking
and private preview keep their existing presentation and canonical booking rules.

Verified locally:239 frontend tests;14/197 Marketplace refinement/photo backend;
33/283 public booking/waitlist;9/144 real built SSR SEO/private/fallback tests.
Client+SSR build and25-entry frontsite budgets pass; whitespace checks pass.
The actual desktop/mobile BeGreat handoff remains visually unverified because CUA
returned “Local browser use is disabled in Work settings”. No deployment or
indexation flag was changed. [Evidence](audits/2026-11-09-marketplace-booking-shell/README.md).

### 2026-11-09 Business Messages and Marketplace email/private-page follow-up

Business navigation now reads Messages and opens a focused white/slate Business
inbox: customer/reference search, All/Unread, bounded previews/unread totals,
explicit Refresh and shared desktop conversation/mobile return. Listing/publication/
booking-entry panels moved to Business setup → Marketplace listing with existing
full-business settings authorization. Scoped reads/replies, encrypted messages,
paging, pause and idempotent drafts remain intact. Shared AppLayout now injects
Ziggy's per-app route helper so actual Business SSR can render.

New saved messages create a durable email alert after commit: customer → one active
verified main owner; business → the currently matching verified booking customer.
Recipients/pause/read state are rechecked. Emails contain no message body/CRM data
or bearer link; sign-in resumes a validated conversation path. Duplicate jobs,
rollback and unknown-send handling preserve messages/history. An every-minute
recovery sweep processes queued new alerts only; no historical backfill. The
additive UUID migration was applied to the local development MySQL database.
`MARKETPLACE_MESSAGE_EMAIL_ENABLED=false` disables alerts without deleting history.

Marketplace sign-in/client email now embeds its PNG instead of requiring an inbox
proxy to fetch a local hostname; its surround uses consistent ivory rather than
mixed blue/ivory. Secure Manage booking/actions, waitlist and existing client forms/
completion/error pages share Marketplace branding. Customer receipt HTML adopts
Marketplace presentation without changing its issued financial snapshot or owner/PDF
rendering. Existing guest link, booking, timezone and manual collection rules remain.

Verified locally:174 targeted backend tests passed/1 skipped/1,622 assertions; the
separate built live SSR run passed28/383 including the skipped case.243 frontend
tests, client+SSR build,25-entry frontsite budgets and whitespace checks pass.
Synthetic100-booking inbox returns25 with at most3 message-bearing SELECTs. Array
mail/SES mocks verify logo MIME, sender/PDF/text continuity and conservative retries.
No real email was sent, and SQLite does not certify production lock contention.
Browser/desktop/mobile and real inbox visuals remain pending: CUA returned
“Local browser use is disabled in Work settings”. No deployment or indexation gate
changed. [Audit, samples and operator recovery](audits/2026-11-09-marketplace-messages-email/README.md).

### 2026-11-11 Automatic store discovery and MySQL migration repair

Published, qualified online-booking stores now enter Marketplace search automatically.
Publication/resume refreshes supply after commit before returning when available,
with durable queued/scheduled recovery. Existing stores are refreshed by the scheduler.
Individual SEO profile status/hash follows the public description, address and bookable
services. Profile geography approval, manual SEO requests and per-store pilot IDs
are retired. Curated hubs retain editorial review. The owner page has one optional
visibility form. Discovery is enabled internally. The normal environment example
contains MARKETPLACE_GROWTH_INDEXATION=false and MARKETPLACE_MESSAGE_EMAIL_ENABLED=true.
Canonical-host checks reuse BRAND_WEBSITE_URL. The four retired rollout variables
are ignored. Private-page protections remain verified on index enable/rollback.

The reported MySQL1059 failure was reproduced against native MySQL. A short explicit
attribution tenant FK name fixes the identifier limit. The growth migration now
resumes partial table creation and restores missing constraints, uniqueness and
lookup indexes while retaining existing rows. Fresh, partial-recovery and repeated
runs passed in an isolated MySQL database. The actual local migration completed the
pending growth, lineage and photo migrations. Rechecking reports Nothing to migrate.
Local reconciliation processed23 businesses with0 failures. Indexing remains false.

Verified locally,221 targeted backend tests passed with2 live-renderer cases skipped
in that run,2,066 assertions. The separate live SSR run passed35/510, including those
cases and the normal automatic publication/profile/owner-settings journey.244 frontend
tests, client+SSR build,25-entry frontsite budgets, scoped formatting and whitespace
checks pass. The100-business/1,000-offer fixture retains4 retrieval/suggestion SELECTs
and0 live availability calls. Browser visual checks remain pending because CUA returned
Local browser use is disabled in Work settings. Production deployment and Google
indexing/ranking/customer-outcome verification remain pending.

[Implementation, migration recovery and evidence](audits/2026-11-11-marketplace-automatic-publication/README.md).
