# Public booking, self-service, and waitlist journey

Status: Booking flow refined and locally verified (2026-10-10); paid public launch gates remain open.

Requirements: FR-06, FR-07, FR-09, FR-10, FR-19, and FR-20.

## Public links and client journey

Requirements: FR-06/07/09/10/19/20; ADR-055. Primary links use
`BookingUrl` and `config/booking.php`: `https://book.clipperdesk.com/{slug}`.
The public `/book/{slug}` fallback renders the same component and controller,
without redirecting a current slug. Both carry the primary canonical URL and the
existing tenant-booking noindex policy. Historical aliases redirect to the
current primary link. Unpublished, paused, deleted and unknown businesses return
a generic unavailable page. [Deployment contract](deployment/public-booking.md).

1. **Services.** Show public business/location information and the online catalog
   with price/duration, useful categories/search and explicit add-ons. Hide a
   single-location selector. Restriction badges explain returning/new-client
   services without an upfront previous-visit question. Continue works on mobile.
2. **Staff & time.** Offer any available staff, optional preference or required
   preference according to current business rules. Show location-local today,
   bounded dates, a nearby-date rail and morning/afternoon/evening time groups.
   Availability uses an accessible skeleton; requests are debounced/aborted and
   stale responses ignored. A selected
   time reserves capacity for ten minutes; replacing it retires the previous
   hold in the same transaction, with rollback restoring the old hold on failure.
3. **Details & inline review.** Required fields are name, mobile and email.
   The phone control shows a compact flag/dialing code with a wider searchable
   full-country menu; international pasted numbers infer their country.
   Date of birth, referral, request and marketing preferences are disclosed only
   on demand. Review privately resolves an unambiguous active same-business
   normalized name/contact match, rejects contradictory contacts and checks
   service/new-client restrictions and actual client-specific deposit rules.
   No saved profile or history is returned, and no customer contacts are stored
   in browser session storage or flow state. Editing essentials requires review
   again. Terms, privacy, frozen cancellation policy and explicit optional SMS
   consent remain distinct; marketing never gates booking.
4. **Confirmation.** The customer accepts the displayed policy and submits once.
   Confirmation locks the business/flow, binds the reviewed essentials, checks
   current eligibility/deposit, flow/hold expiry, policy/configuration and atomic
   capacity. Concurrent requests converge on one appointment. An ambiguous
   response can retry the same frozen request/key. Success shows reference,
   appointment time, location/address, service and staff with calendar/private
   management links in a centered card; it does not claim that a provider message
   was delivered. Flow restoration and GET page navigation use appointment
   skeletons with status text and reduced-motion support.

The browser stores only flow credentials, expiry and public selections in
session storage. Resume validates the digest, business and expiry; it restores a
hold or an existing confirmation without resubmitting a booking. Customers
re-enter contacts after refresh. Availability responses contain public times,
price and currency only, excluding engine plans, database IDs, resources and
private configuration. Search remains advisory; confirmation revalidates.

Required deposits still stop confirmation until verified paid evidence exists.
OPEN-16 retains the missing payment element/return/status journey; the visible
contact path is accurate, but it is not a completed paid online-booking flow.

## Secure self-service

ADR-074 adds optional salon gallery/team portraits and completed-visit reviews.
The [presentation specification](modules/booking-presentation.md) retains the
same booking engine and staff preference/qualification rules; no-photo booking
has no extra setup requirement. The [reviews specification](modules/client-reviews.md)
defines secure completed-visit feedback, explicit public-display consent and
withdrawal, plus operator copy-link/read access. No automated outreach or payment
collection is introduced. Terminal visits no longer advertise reschedule/cancel
actions on the management page; completed visits offer feedback and rebooking.

The view link displays Appointment time in its governing Location time zone,
Location, lines, price/deposit state, policy snapshot, and status. It issues
short-lived independent links for:

- reschedule by choosing actual available location-local times, excluding the
  original appointment from advisory capacity, grouped by time of day and loaded
  with a skeleton, then committing a linked, revalidated replacement;
- cancellation subject to the frozen cutoff and waitlist matching;
- rebook through the current catalog and policy;
- contact update with versioned change evidence and no sensitive audit values;
- Appointment-bound waitlist join and versioned leave;
- payment-status display without accepting card data.

The raw token is never stored. Links are purpose-bound and UTC-expiring. Action
links are consumed once; material Appointment/contact changes revoke older
links, then redirect to a fresh view link. A booking reference cannot retrieve
an Appointment.

View/action headings are centered; form labels and editable information retain
their reading alignment. Reschedule/cancel enforce the accepted policy snapshot's
cutoff rather than retroactively applying a changed business default; legacy
appointments without a snapshot use the configured fallback.

## Waitlist lifecycle

An active request records Location, Service, optional preferred Staff, client
contact, acceptable date/time range, notification method, notes, expiry, and
version. An active fingerprint converges exact duplicates. A cancellation or
other opening is checked at its exact instant with the authoritative availability
engine, without truncating the day to its earliest available times. Matching
requests are offered in configured batches and retain `offered`, `claimed`,
`lost`, `revoked`, or expired evidence.

Claim locks all siblings in one batch before booking. The first valid claim
commits a normal `waitlist`-source Appointment through `BookingCommitCommand`;
every sibling becomes `lost`. An expired, revoked, already-claimed, or newly
unavailable offer fails without a partial Appointment.

## Safe failures and recovery

| Condition | Client result | Capacity/history result |
| --- | --- | --- |
| Flow or Hold expired | Return to current times while retaining in-memory details | Expired Hold consumes no capacity |
| Public policy changed | Review the current policy again | No Appointment is created |
| Slot/configuration changed | Choose another current slot | Commit transaction rolls back |
| Required deposit, provider not connected | Contact the Business; no payment fields are shown | Hold is not confirmed; Prompt 10 owns provider coordination |
| Invalid/unknown/wrong-purpose token | Generic not-found response | No tenant or Appointment detail leaks |
| Expired/used/revoked action link | Request a fresh link from the Business | Existing Appointment is unchanged |
| Duplicate waitlist request | Existing active request is returned | No duplicate notification demand |
| Waitlist race | Loser sees the opening is no longer available | Exactly one normal Appointment exists |

## Conversion and privacy evidence

`PublicBookingEvent` records started, availability/time-selection, Hold, and
completed milestones using a session digest and low-cardinality counts/source
metadata. Names, email, mobile, raw tokens, free text, and exact private
schedule reasons are excluded. Public creation and mutation endpoints are
rate-limited. Provider-backed communication now extends the same privacy and
idempotency rules through one
Business/event/channel/recipient message key, encrypted destinations, signed
short-lived email action links, compact random-token SMS capabilities (ADR-081),
and content-minimized support history. Both link forms preserve expiry,
revocation, tenant/purpose and consumption checks. SMS links open the existing
appointment page with its captured address/arrival/directions; they do not expose
a public booking identifier as authentication. Provider-backed
payment events in Prompt 10 must reuse the deposit/receipt intents.

## Receipt notification actions (2026-10-04, FR-13/14)

Signed receipt links display the existing issued sale receipt, with its immutable
recorded financial values, until link expiry. Legacy appointment-target links
resolve the appointment's issued receipt. Viewing creates no payment/receipt and
uses private no-store/no-referrer/noindex headers. Future notification action-link
expiry is based on intended delivery time; existing revocation/tenant checks and
single-use mutation actions remain. See [Communications](modules/communications.md).

## Location intelligence (2026-10-12; ADR-064)

[Locations](modules/location-intelligence.md) specifies the shared owner-confirmed entrance, inline branch picker, optional memory-only nearby sort and snapshot-based arrival card. Single eligible branches skip selection; common services survive branch switching. Maps load on request. Held location changes require a fresh address review; confirmed and same-branch rescheduled visits keep their original location details.


## Confirmation snapshot comparison (2026-10-14; ADR-066)

The held address is compared with the current branch by sorted keys and strict
values. MySQL JSON key ordering can no longer reject an otherwise unchanged
address as `POLICY_CHANGED`. The existing exclusions for derived direction links
and business-primary selection remain. Actual address/entrance/arrival changes
and policy-version changes still block confirmation; contacts, deposits, capacity,
expiry and idempotency are revalidated. The regression reviews client details,
confirms a reordered snapshot and repeats the same request to prove one appointment.

## Marketplace entry and customer ownership — 2026-11-08

Marketplace salon profiles hand services/location/date into the same Welcome
component and canonical availability/hold/commit engine via scoped marketplace
routes. Customer sign-in is optional; a signed-in flow records its customer and
links successful matching-email appointments transactionally. Duplicate confirms
remain one appointment; replacement lifecycle writes preserve account linkage.
Direct booking paths and guest secure-link management remain available. Manual
payments do not bypass required-deposit policy. See [Marketplace](modules/marketplace.md).

### Single Marketplace booking page — 2026-11-08

Marketplace salon URLs now render this existing `Booking/Welcome` journey directly;
the separate service/time preview screen is removed. Legacy Marketplace `/book`
entries redirect with validated service/location/date. The same location, services,
professional/time, hold, review and confirmation steps remain authoritative. Account
prefill/favourite and Marketplace source/linkage stay scoped to Marketplace routes;
ordinary direct links remain available independently of Marketplace listing pause.

## Discovery provenance (MPG-08/09)

Entry route, owner shared-link label and first/last discovery observation are
separate. Entry remains operational; optional acquisition needs explicit consent.
Flow evidence is frozen at start, preserved across ordinary login/redirect/resume
and exact confirmation replay, and linked inside confirmation’s transaction.
Rescheduling copies its root lineage, so it cannot manufacture another acquisition.
Withdrawal/retention may remove optional evidence without deleting visits or ledger
facts. A missing/expired browsing session remains unknown; no cross-device identity
or guaranteed 30-day browser persistence is inferred.


Marketplace visual continuity: all existing Marketplace booking steps now share
the real MarketplaceLayout header, logo, navigation/account menu, ivory background
and footer. PublicBookingLayout keeps its canonical progress/main content within
that shell, with business accents scoped to the booking body. Business identity,
media, catalogue, rules and hold/confirm/resume behavior remain intact. Direct
owner booking/private preview retain the existing public-booking presentation.

### Private customer branding continuity — 2026-11-09

Secure Manage booking and existing reschedule, cancel, rebook, contact, waitlist,
payment-status and review views now use the Marketplace shell in self-service mode.
Existing waitlist offers and client forms/completion use it too. Invalid/expired
customer links show Marketplace recovery with their real error status and a support
reference. The customer receipt's HTML branding is Marketplace; its issued financial
snapshot and owner/PDF rendering remain unchanged. Guest secure-link access,
ownership, expiry, action purpose, timezone, hold/commit, manual payment and
no-store/noindex rules are unchanged. No extra selection or login step is introduced.
See [follow-up evidence](audits/2026-11-09-marketplace-messages-email/README.md).
